#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
调用 lv_font_conv 生成 LVGL 中文字体 C 文件。

用 Python 而非 PowerShell 驱动, 是为了避免 PowerShell 调用外部程序时
把参数转成系统 ANSI(GBK) 导致 node 侧 UTF-8 解析失败。

用法:
    python gen_font.py            # 生成 16px 与 24px
    python gen_font.py 16 20 24   # 指定字号
"""
import os
import sys
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))

NODE = r'C:\Users\matebookxpro\.workbuddy\binaries\node\versions\22.22.2\node.exe'
CONV = r'C:\Users\matebookxpro\.workbuddy\binaries\node\workspace\node_modules\lv_font_conv\lv_font_conv.js'
FONT = r'C:\Windows\Fonts\simhei.ttf'          # 黑体: 小字号屏显清晰
CHARS = os.path.join(HERE, 'cn_chars.txt')
OUTDIR = os.path.join(os.path.dirname(HERE), 'main', 'fonts')


def gen(size, bpp=4):
    with open(CHARS, encoding='utf-8') as f:
        symbols = f.read().strip()

    os.makedirs(OUTDIR, exist_ok=True)
    out = os.path.join(OUTDIR, 'lv_font_cn_%d.c' % size)

    cmd = [
        NODE, CONV,
        '--font', FONT,
        '--symbols', symbols,
        '--size', str(size),
        '--format', 'lvgl',
        '--bpp', str(bpp),
        '--no-compress',
        '-o', out,
    ]
    print('>> generating %dpx ...' % size)
    r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    if r.returncode != 0:
        print('FAILED size=%d' % size)
        print(r.stdout[-2000:])
        print(r.stderr[-2000:])
        return None
    if r.stdout.strip():
        print(r.stdout.strip())
    if os.path.isfile(out):
        print('   -> %s  (%.0f KB)' % (out, os.path.getsize(out) / 1024.0))
        return out
    return None


if __name__ == '__main__':
    sizes = [int(x) for x in sys.argv[1:]] or [16, 24]
    for s in sizes:
        gen(s)
    print('done.')
