#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 LVGL 中文字库所需的字符集。

策略: GB2312 一级汉字(3755 个常用字) + ASCII + 中文标点 + 常用符号。
一级字库已覆盖日常阅读、UI 文案、时辰/天干地支/数字等全部需求。
电子书若遇到生僻字会显示为缺省字形, 后续可扩到二级字库。
"""
import sys

def build():
    chars = []
    seen = set()

    def add(c):
        if c and c not in seen:
            seen.add(c)
            chars.append(c)

    # 1) ASCII 可见字符 (0x20 - 0x7E)
    for code in range(0x20, 0x7F):
        add(chr(code))

    # 2) GB2312 一级汉字: 区 0xB0-0xD7 (16-55 区), 位 0xA1-0xFE
    for hi in range(0xB0, 0xD8):
        for lo in range(0xA1, 0xFF):
            try:
                add(bytes([hi, lo]).decode('gb2312'))
            except UnicodeDecodeError:
                continue

    # 3) 中文标点与常用符号
    extra = (
        '，。、；：？！""'
        "''（）《》【】〔〕～—…·"
        '°℃￥±×÷‰㎡㈱①②③'
        '年月日时分秒星期周'
        # GB2312 二级字库里的字, 源码用到但一级未收录
        '渲'
    )
    for c in extra:
        add(c)

    return ''.join(chars)

if __name__ == '__main__':
    s = build()
    out = sys.argv[1] if len(sys.argv) > 1 else 'cn_chars.txt'
    with open(out, 'w', encoding='utf-8') as f:
        f.write(s)
    # 统计
    han = sum(1 for c in s if '一' <= c <= '鿿')
    print('total=%d, hanzi=%d -> %s' % (len(s), han, out))
