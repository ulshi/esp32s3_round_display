#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读取 ESP32-S3 串口日志一段时间, 用于验证启动与运行状态。

用法:
    python read_serial.py COM8          # 默认读 12 秒
    python read_serial.py COM8 20       # 读 20 秒
    python read_serial.py COM8 15 reset # 先触发一次复位再读(可抓完整启动日志)
"""
import sys
import time

try:
    import serial
except ImportError:
    print('需要 pyserial: pip install pyserial')
    sys.exit(1)

port = sys.argv[1] if len(sys.argv) > 1 else 'COM8'
secs = float(sys.argv[2]) if len(sys.argv) > 2 else 12.0
do_reset = len(sys.argv) > 3 and sys.argv[3].lower() == 'reset'

s = serial.Serial(port, 115200, timeout=0.5)

if do_reset:
    # 大多数 ESP32 开发板: RTS -> EN(经反相), DTR -> IO0
    s.setDTR(False)
    s.setRTS(True)
    time.sleep(0.2)
    s.setRTS(False)
    time.sleep(0.1)
    s.setDTR(False)

print('--- reading %s for %.0fs ---' % (port, secs))
end = time.time() + secs
while time.time() < end:
    line = s.readline()
    if line:
        print(line.decode('utf-8', 'replace').rstrip())
s.close()
print('--- done ---')
