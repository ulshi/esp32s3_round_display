#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
校验工程源码里出现的中文字符是否都被字库字符集覆盖。
用法: python check_coverage.py
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.dirname(HERE)
CHARS = os.path.join(HERE, 'cn_chars.txt')

with open(CHARS, encoding='utf-8') as f:
    charset = set(f.read().strip())

used = {}
pat = re.compile(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]')

for root, dirs, files in os.walk(os.path.join(PROJ, 'main')):
    dirs[:] = [d for d in dirs if d != 'fonts']
    for fn in files:
        if not fn.endswith(('.c', '.h')):
            continue
        p = os.path.join(root, fn)
        with open(p, encoding='utf-8', errors='replace') as f:
            txt = f.read()
        for c in pat.findall(txt):
            used.setdefault(c, set()).add(os.path.relpath(p, PROJ))

missing = {c: f for c, f in used.items() if c not in charset}

print('源码中出现的中文/全角字符: %d 个' % len(used))
print('字库覆盖: %d 个' % (len(used) - len(missing)))
if missing:
    print('\n!! 字库缺失以下字符 (%d 个):' % len(missing))
    for c, files in sorted(missing.items()):
        print('   %s  (U+%04X)  出现在: %s' % (c, ord(c), ', '.join(sorted(files))))
    print('\n把这些字符加进 tools/gen_charset.py 的 extra 后重新生成字库。')
    sys.exit(1)
else:
    print('全部覆盖, 无需补充。')
