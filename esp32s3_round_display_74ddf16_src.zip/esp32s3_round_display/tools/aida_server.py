#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AIDA PC 监控服务端
====================
监听 TCP 8888, 收到任意数据(建议发 "GET\\n")后, 返回一行行 "label:value",
然后关闭连接。ESP32 圆屏的「电脑(AIDA)」页面会连接本机并展示这些数据。

用法:
    1) pip install psutil
    2) python aida_server.py
    3) 在圆屏 设置 -> 电脑地址 里填本机局域网 IP (脚本启动时会打印)
    4) 圆屏需与电脑在同一 WiFi 下

可通过环境变量覆盖端口:  AIDA_PORT=9000 python aida_server.py
"""
import socket
import threading
import time
import platform
import os
import sys

PORT = int(os.environ.get("AIDA_PORT", "8888"))


def get_stats():
    lines = []
    try:
        import psutil
        lines.append("CPU %.0f%%" % psutil.cpu_percent(interval=0.2))
        mem = psutil.virtual_memory()
        lines.append("MEM %.0f%% %dMB" % (mem.percent, mem.used // 1024 // 1024))
        try:
            f = psutil.cpu_freq()
            if f:
                lines.append("FREQ %.2fGHz" % (f.current / 1000.0))
        except Exception:
            pass
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for dev, entries in temps.items():
                    if entries:
                        lines.append("%s %.0fC" % (dev, entries[0].current))
                        break
        except Exception:
            pass
        du = psutil.disk_usage("/" if platform.system() != "Windows" else "C:\\")
        lines.append("DISK %.0f%%" % du.percent)
        try:
            net = psutil.net_io_counters()
            lines.append("NET %dMB up / %dMB dn" % (
                net.bytes_sent // 1024 // 1024, net.bytes_recv // 1024 // 1024))
        except Exception:
            pass
        lines.append("UP %dh" % (int(time.time() - psutil.boot_time()) // 3600))
    except ImportError:
        lines.append("psutil missing")
        lines.append("pip install psutil")
    except Exception as e:
        lines.append("err: %s" % e)
    return lines


def handle_client(conn, addr):
    try:
        conn.settimeout(3)
        try:
            conn.recv(64)  # 读掉请求
        except Exception:
            pass
        payload = "\n".join(get_stats()) + "\n"
        conn.sendall(payload.encode("utf-8", "replace"))
    except Exception as e:
        sys.stderr.write("client err %s: %s\n" % (addr, e))
    finally:
        try:
            conn.close()
        except Exception:
            pass


def print_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        print("本机局域网 IP: %s  (在圆屏 设置->电脑地址 填入此值)" % ip)
    except Exception:
        print("无法自动获取本机 IP, 请手动用 ipconfig/ifconfig 查看")


def main():
    print_local_ip()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", PORT))
    server.listen(8)
    print("AIDA server listening on TCP :%d  (Ctrl+C 退出)" % PORT)
    try:
        while True:
            conn, addr = server.accept()
            t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            t.start()
    except KeyboardInterrupt:
        print("\nbye")
    finally:
        server.close()


if __name__ == "__main__":
    main()
