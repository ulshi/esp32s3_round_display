﻿# 烧录固件到 ESP32-S3 (自动探测串口)
#
# 用法:
#   .\flash.ps1                 # 自动探测 COM 口并烧录全部固件
#   .\flash.ps1 -Port COM6      # 指定串口
#   .\flash.ps1 -Baud 921600    # 指定烧录波特率(默认 460800)
#   .\flash.ps1 -Erase          # 先整片擦除(首次烧录或分区表改过时用)
#   .\flash.ps1 -Monitor        # 烧完直接打开串口监视器

param(
    [string]$Port = '',
    [int]$Baud = 460800,
    [switch]$Erase,
    [switch]$Monitor
)

$ErrorActionPreference = 'Continue'
$proj  = Split-Path -Parent $MyInvocation.MyCommand.Path
$esp   = 'C:\Espressif\tools\python\v6.1\venv\Scripts\esptool.exe'
$venvPy= 'C:\Espressif\tools\python\v6.1\venv\Scripts\python.exe'
$monitorPy = 'C:\esp\v6.1\esp-idf\tools\idf_monitor.py'   # 不能叫 $monitor: 与 -Monitor 开关冲突

Set-Location $proj

# ---- 校验产物存在 ----
$appBin = 'build\esp32s3_round_display.bin'
foreach ($f in @('build\bootloader\bootloader.bin', 'build\partition_table\partition-table.bin', $appBin)) {
    if (-not (Test-Path $f)) {
        Write-Host "缺少产物 $f —— 请先运行 .\build.ps1" -ForegroundColor Red
        exit 1
    }
}

# ---- 自动探测串口 ----
if (-not $Port) {
    # 只探测系统真实存在的串口, 避免对不存在的 COM 逐个等待超时
    $existing = Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty DeviceID | Sort-Object
    if (-not $existing) { $existing = 1..20 | ForEach-Object { "COM$_" } }
    Write-Host ("未指定串口, 探测候选: " + ($existing -join ', '))
    foreach ($p in $existing) {
        $r = & $esp -p $p chip-id 2>&1 | Out-String
        if ($r -match 'Chip is|Detected|Chip ID') {
            $Port = $p
            Write-Host "  在 $p 上发现芯片:" -ForegroundColor Green
            Write-Host ($r -split "`n" | Where-Object { $_ -match 'Chip|Detected|MAC' } | Out-String)
            break
        }
    }
    if (-not $Port) {
        Write-Host '未探测到 ESP32 芯片。请检查:' -ForegroundColor Yellow
        Write-Host '  1. USB 线已接, 且是数据线(不是纯充电线)' -ForegroundColor Yellow
        Write-Host '  2. 板子已上电' -ForegroundColor Yellow
        Write-Host '  3. 驱动已装: ESP32-S3 原生 USB 口显示为 USB JTAG/serial debug unit' -ForegroundColor Yellow
        Write-Host '     (Win10 需用 Zadig 装 WinUSB 驱动); 板载 CP210x/CH340 则装对应 VCP 驱动' -ForegroundColor Yellow
        Write-Host '  4. 手动进下载模式: 按住 BOOT -> 点一下 RESET -> 松开 BOOT' -ForegroundColor Yellow
        Write-Host '' 
        Write-Host '确认后可用 .\flash.ps1 -Port COMx 指定端口重试。' -ForegroundColor Yellow
        exit 1
    }
}

Write-Host "烧录端口: $Port  波特率: $Baud"

# ---- 烧录 ----
$args = @('-p', $Port, '-b', "$Baud", '--before', 'default-reset', '--after', 'hard-reset',
          # 不写死 --flash-size: 交给 esptool 自动探测, 换不同容量板子无需改脚本
          'write-flash', '--flash-mode', 'dio', '--flash-freq', '80m',
          '0x0',       'build\bootloader\bootloader.bin',
          '0x8000',    'build\partition_table\partition-table.bin',
          '0x10000',   $appBin)

if ($Erase) {
    Write-Host "擦除整片 flash..."
    & $esp -p $Port erase_flash
    if ($LASTEXITCODE -ne 0) { Write-Host "擦除失败" -ForegroundColor Red; exit 1 }
}

Write-Host "写入固件..."
& $esp @args
if ($LASTEXITCODE -ne 0) {
    Write-Host "烧录失败 (exit=$LASTEXITCODE)" -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "烧录完成, 芯片已复位启动。" -ForegroundColor Green

if ($Monitor) {
    Write-Host "打开串口监视器 (Ctrl+] 退出)..."
    & $venvPy $monitorPy -p $Port -b 115200 $appBin
}
