#include "lvgl_helper.h"

#include <stdio.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_log.h"

#include "display.h"
#include "ui_manager.h"
#include "board_config.h"

static const char *TAG = "lvgl_helper";

/* LVGL 自带 POSIX 文件系统驱动(需 CONFIG_LV_USE_FS_POSIX=y),
 * 把 "/" 直接映射到 ESP-IDF VFS(已挂载的 /sdcard), 供图片/文件解码器读卡。 */
extern void lv_fs_posix_init(void);

static SemaphoreHandle_t g_lvgl_mux = NULL;
static lv_disp_drv_t g_disp_drv;
static esp_lcd_touch_handle_t g_touch = NULL;

/* ---------------- 刷新 ---------------- */
static bool lvgl_flush_ready_cb(esp_lcd_panel_io_handle_t io, esp_lcd_panel_io_event_data_t *edata, void *user_ctx)
{
    lv_disp_drv_t *drv = (lv_disp_drv_t *)user_ctx;
    lv_disp_flush_ready(drv);
    return false;
}

static void disp_flush_cb(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_map)
{
    esp_lcd_panel_handle_t panel = (esp_lcd_panel_handle_t)drv->user_data;

    /* 成功时由 on_color_trans_done 回调(lvgl_flush_ready_cb)放行;
     * 失败/句柄无效时必须在这里放行, 否则 LVGL 会永久等待刷新完成,
     * 表现为 lv_timer_handler() 一直返回小值 -> 任务看门狗触发。 */
    if (!panel) {
        lv_disp_flush_ready(drv);
        return;
    }
    esp_err_t r = esp_lcd_panel_draw_bitmap(panel,
                                            area->x1, area->y1,
                                            area->x2 + 1, area->y2 + 1,
                                            color_map);
    if (r != ESP_OK) {
        lv_disp_flush_ready(drv);
    }
}

/* ST77916 QSPI 以 4 字节(2 像素@16bit) 为单位, x 需 4 对齐 */
static void disp_rounder_cb(lv_disp_drv_t *drv, lv_area_t *area)
{
    (void)drv;
    int x1 = area->x1;
    int x2 = area->x2;
    area->x1 = (x1 >> 2) << 2;
    area->x2 = ((x2 >> 2) << 2) + 3;
}

static void disp_update_cb(lv_disp_drv_t *drv)
{
    esp_lcd_panel_handle_t panel = (esp_lcd_panel_handle_t)drv->user_data;
    switch (drv->rotated) {
    case LV_DISP_ROT_NONE:
        esp_lcd_panel_swap_xy(panel, false);
        esp_lcd_panel_mirror(panel, true, false);
        break;
    case LV_DISP_ROT_90:
        esp_lcd_panel_swap_xy(panel, true);
        esp_lcd_panel_mirror(panel, true, true);
        break;
    case LV_DISP_ROT_180:
        esp_lcd_panel_swap_xy(panel, false);
        esp_lcd_panel_mirror(panel, false, true);
        break;
    case LV_DISP_ROT_270:
        esp_lcd_panel_swap_xy(panel, true);
        esp_lcd_panel_mirror(panel, false, false);
        break;
    }
}

/* ---------------- 触摸 + 滑动手势 ---------------- */
static int16_t g_down_x = 0, g_down_y = 0;
static int16_t g_last_x = 0, g_last_y = 0;   /* 按下期间最后一次有效坐标 */
static int16_t g_tap_x = 0;
static bool g_was_pressed = false;
static bool g_on_brightness = false;   /* 本次手势是否从亮度控件上起始 */
static bool g_suppress_release = false; /* 长按导航后抑制"松手"手势, 避免再触发返回主页 */
static bool g_gesture_blocked = false;  /* 浮层(如二维码)打开时屏蔽所有导航手势 */

/* 亮度控件对象: 若一次手势从它上面按下, 则视为"正在调亮度",
 * 即便产生左右/上下滑动也不触发导航(避免误触返回主页)。
 * 由设置页在创建亮度控件时登记, 切换页面时清空。 */
static lv_obj_t *g_bl_obj = NULL;

void lvgl_set_brightness_obj(lv_obj_t *obj)
{
    g_bl_obj = obj;
}

/** 长按导航后调用: 抑制紧随其后的"松手"手势, 防止松手被误判为滑动而返回主页。 */
void lvgl_consume_release_gesture(void)
{
    g_suppress_release = true;
}

/** 临时屏蔽所有导航手势(如弹出二维码浮层时), 防止滑动误触切换页面。
 *  不影响 LVGL 自身的点击(浮层关闭)事件。 */
void lvgl_set_gesture_blocked(bool blocked)
{
    g_gesture_blocked = blocked;
}

static void touch_read_cb(lv_indev_drv_t *drv, lv_indev_data_t *data)
{
    esp_lcd_touch_handle_t tp = (esp_lcd_touch_handle_t)drv->user_data;
    uint16_t x = 0, y = 0;
    uint8_t cnt = 0;

    esp_lcd_touch_read_data(tp);
    bool pressed = esp_lcd_touch_get_coordinates(tp, &x, &y, NULL, &cnt, 1);

    if (pressed && cnt > 0) {
        if (!g_was_pressed) {
            g_down_x = (int16_t)x;
            g_down_y = (int16_t)y;
            /* 记录本次手势是否从亮度控件上起始 */
            if (g_bl_obj && lv_obj_is_visible(g_bl_obj)) {
                lv_area_t a;
                lv_obj_get_coords(g_bl_obj, &a);
                if (x >= a.x1 && x <= a.x2 && y >= a.y1 && y <= a.y2) {
                    g_on_brightness = true;
                }
            }
        }
        /* 记住最后一个有效坐标: 松手时芯片往往已停止上报, 此刻读到的 x/y
         * 可能是 0 或残留值, 直接用来算位移会产生巨大的伪滑动。 */
        g_last_x = (int16_t)x;
        g_last_y = (int16_t)y;
        data->point.x = x;
        data->point.y = y;
        data->state = LV_INDEV_STATE_PRESSED;
        g_was_pressed = true;
        return;
    }

    /* ---------------- 释放 ----------------
     * 关键: 必须回填最后一次按下坐标。LVGL 每个周期会把 data 清零, 若这里不设置
     * point, LVGL 收到的释放点就是 (0,0) —— 它会判定"松手位置已离开按钮",
     * 于是不派发 LV_EVENT_CLICKED, 表现为设置页所有按钮(文件服务器开关、
     * 亮度 +/-、语言切换)点了都没反应。 */
    data->point.x = g_last_x;
    data->point.y = g_last_y;
    data->state = LV_INDEV_STATE_RELEASED;

    if (!g_was_pressed) {
        g_on_brightness = false;
        return;
    }

    if (g_suppress_release) {
        /* 长按导航刚切页, 松手手势直接吞掉, 不触发任何导航 */
        g_suppress_release = false;
        g_on_brightness = false;
        g_was_pressed = false;
        return;
    }

    /* 用最后一次有效坐标计算位移, 而不是松手瞬间可能失效的读数 */
    int dx = g_last_x - g_down_x;
    int dy = g_last_y - g_down_y;

    /* 灵敏度: 设置页左右滑动阈值更低(更灵敏), 其余页面用默认阈值。
     * 竖向阈值保持较高, 避免轻微抖动被误判为上下滑。 */
    int th_h = (ui_current_page() == UI_PAGE_SETTINGS) ? 18 : 30;
    int th_v = 30;

    ui_gesture_t g;
    if (abs(dy) > abs(dx) && abs(dy) > th_v) {
        g = (dy < 0) ? UI_GESTURE_UP : UI_GESTURE_DOWN;
    } else if (abs(dx) > abs(dy) && abs(dx) > th_h) {
        g = (dx < 0) ? UI_GESTURE_LEFT : UI_GESTURE_RIGHT;
    } else {
        /* 位移很小: 视为轻触(TAP) */
        g_tap_x = g_last_x;
        if (!g_gesture_blocked) ui_handle_gesture(UI_GESTURE_TAP, g_last_x);
        g_was_pressed = false;
        g_on_brightness = false;
        return;
    }

    /* 浮层打开或(从亮度控件起始的)滑动: 不触发导航 */
    if (!g_gesture_blocked && !g_on_brightness) {
        ui_handle_gesture(g, g_last_x);
    }
    g_was_pressed = false;
    g_on_brightness = false;
}

/* ---------------- tick + 任务 ---------------- */
static void increase_tick(void *arg)
{
    (void)arg;
    lv_tick_inc(2);
}

static void lvgl_task(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "LVGL task started");
    uint32_t delay_ms = 500;
    while (1) {
        if (lvgl_lock(-1)) {
            delay_ms = lv_timer_handler();
            lvgl_unlock();
        }
        if (delay_ms > 500) delay_ms = 500;
        else if (delay_ms < 2) delay_ms = 2;
        vTaskDelay(pdMS_TO_TICKS(delay_ms));
    }
}

bool lvgl_lock(int timeout_ms)
{
    if (!g_lvgl_mux) return false;
    TickType_t t = (timeout_ms == -1) ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);
    /* 递归锁: LVGL 任务在处理输入/事件回调时已持有锁,
     * 此时回调里触发的 ui_show_page 会再次请求锁 —— 必须用递归锁, 否则死锁。 */
    return xSemaphoreTakeRecursive(g_lvgl_mux, t) == pdTRUE;
}

void lvgl_unlock(void)
{
    if (g_lvgl_mux) xSemaphoreGiveRecursive(g_lvgl_mux);
}

void lvgl_init(void)
{
    lv_init();

    /* 注册 POSIX 文件系统驱动: 图片/字库等可从 /sdcard 读取
     * (LVGL 内部路径形如 "S:/sdcard/..." , 驱动会自动去掉盘符)。 */
    lv_fs_posix_init();

    /* 必须先在 board_display_init() 之后取句柄:
     * 之前在这里提前调用 board_panel_get() 拿到的是 NULL,
     * 导致 disp_flush_cb 里 draw_bitmap 报 "invalid panel handle"。 */
    ESP_ERROR_CHECK(board_display_init(lvgl_flush_ready_cb, &g_disp_drv));

    esp_lcd_panel_handle_t panel = board_panel_get();
    g_touch = board_touch_get();
    if (!panel) {
        ESP_LOGE(TAG, "panel handle is NULL after display init!");
    }

    static lv_disp_draw_buf_t draw_buf;
    int buf_size = BOARD_LCD_H_RES * 20;   /* 部分缓冲: 20 行 */
    lv_color_t *buf1 = heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_DMA);
    lv_color_t *buf2 = heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_DMA);
    assert(buf1 && buf2);
    lv_disp_draw_buf_init(&draw_buf, buf1, buf2, buf_size);

    lv_disp_drv_init(&g_disp_drv);
    g_disp_drv.hor_res = BOARD_LCD_H_RES;
    g_disp_drv.ver_res = BOARD_LCD_V_RES;
    g_disp_drv.flush_cb = disp_flush_cb;
    g_disp_drv.rounder_cb = disp_rounder_cb;
    g_disp_drv.drv_update_cb = disp_update_cb;
    g_disp_drv.draw_buf = &draw_buf;
    g_disp_drv.user_data = panel;
    lv_disp_t *disp = lv_disp_drv_register(&g_disp_drv);

    /* 全局深色背景: 各页面根容器透明时透出此底色, 形成统一的深色系基调 */
    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, lv_color_make(0x0B, 0x0E, 0x14), 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);

    /* LVGL tick: 2ms 周期 */
    const esp_timer_create_args_t tick_args = {
        .callback = &increase_tick,
        .name = "lvgl_tick",
    };
    esp_timer_handle_t tick_timer = NULL;
    ESP_ERROR_CHECK(esp_timer_create(&tick_args, &tick_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(tick_timer, 2000));

    /* 触摸输入 */
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.disp = disp;
    indev_drv.read_cb = touch_read_cb;
    indev_drv.user_data = g_touch;
    lv_indev_drv_register(&indev_drv);

    g_lvgl_mux = xSemaphoreCreateRecursiveMutex();
    assert(g_lvgl_mux);
    xTaskCreate(lvgl_task, "lvgl_task", 8 * 1024, NULL, 2, NULL);
}
