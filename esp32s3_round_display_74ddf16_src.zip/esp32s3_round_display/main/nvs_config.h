#pragma once
#include "esp_err.h"
#ifdef __cplusplus
extern "C" {
#endif

/** 初始化 NVS (必要时擦除重建)。 */
esp_err_t nvs_config_init(void);

int nvs_config_get_int(const char *key, int def);
void nvs_config_set_int(const char *key, int v);

esp_err_t nvs_config_get_str(const char *key, char *buf, size_t n);
void nvs_config_set_str(const char *key, const char *v);

/** 根据 NVS 的 tz_offset(分钟, 东为正) 设置系统时区, 默认 +8。 */
void app_set_timezone(void);

/** NVS 键名常量 (字符串上限 15 字符)。 */
#define NVS_BRIGHTNESS  "brightness"   /* 背光亮度 0..100 */
#define NVS_LR_MODE     "lr_mode"      /* 小六壬模式: 0=时间 1=随机 2=手工 */
#define NVS_LR_M        "lr_m"         /* 手工模式 月 1..12 */
#define NVS_LR_D        "lr_d"         /* 手工模式 日 1..31 */
#define NVS_LR_S        "lr_s"         /* 手工模式 时辰 1..12 */
#define NVS_FILE_SERVER "fs_enable"    /* 文件服务器开关: 0=关(默认) 1=开 */
#define NVS_TIME_YEAR   "t_year"       /* 手工/同步时间: 年 (默认 2026) */
#define NVS_TIME_MON    "t_mon"        /* 月 1..12 (默认 10) */
#define NVS_TIME_DAY    "t_day"        /* 日 1..31 (默认 1) */
#define NVS_TIME_HOUR   "t_hour"       /* 时 0..23 (默认 12) */
#define NVS_TIME_MIN    "t_min"        /* 分 0..59 (默认 0) */
#define NVS_TIME_MANUAL "t_manual"     /* 1=用户手工设过时间, 禁用 SNTP 自动校时 */

/** 启动时钟: 用户手工设过则套用手工时间; 否则套用默认 2026-10-01 12:00
 *  (若 SNTP 曾同步过且分量有效, 也会采用)。须在 app_set_timezone() 之后调用。 */
void app_apply_clock_time(void);

/** 设定并立即生效手工时间(同时写 NVS 并标记 manual=1, 此后禁用 SNTP)。 */
void app_set_manual_time(int year, int mon, int day, int hour, int min);

/** 是否已手工设过时间(禁用 SNTP)。 */
bool app_time_is_manual(void);

#ifdef __cplusplus
}
#endif
