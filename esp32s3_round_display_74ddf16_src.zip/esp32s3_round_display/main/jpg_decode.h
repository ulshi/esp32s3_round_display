#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 用 LVGL 自带的 tjpgd(编译于 LV_USE_SJPG)解码一个标准 .jpg/.jpeg 文件,
 * 输出 RGB565 的 lv_img_dsc_t。数据分配在 PSRAM。
 * 成功返回 dsc(需调用 jpg_decode_free_dsc 释放), 失败返回 NULL。
 */
lv_img_dsc_t *jpg_decode_file(const char *path);

/** 释放 jpg_decode_file 的结果(先释放数据缓冲再释放 dsc 本身)。 */
void jpg_decode_free_dsc(lv_img_dsc_t *dsc);

#ifdef __cplusplus
}
#endif
