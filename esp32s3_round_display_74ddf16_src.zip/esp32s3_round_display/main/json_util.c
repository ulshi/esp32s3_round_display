#include "json_util.h"

#include <string.h>
#include <stdlib.h>

/* 找到作为"键"出现的 key: 其前一个字符为 '"', 其后跳过空白是 ':'。
 * 返回指向 ':' 之后的指针, 找不到返回 NULL。 */
static const char *find_field(const char *json, const char *key)
{
    size_t kl = strlen(key);
    const char *p = json;
    while ((p = strstr(p, key)) != NULL) {
        if (p > json && p[-1] == '"') {
            const char *q = p + kl;
            while (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r') q++;
            if (*q == ':') return q + 1;
        }
        p += kl;   /* 继续往后找, 避免死循环 */
    }
    return NULL;
}

static const char *skip_ws(const char *p)
{
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    return p;
}

static bool extract_str(const char *v, char *out, size_t outlen)
{
    v = skip_ws(v);
    if (*v != '"') return false;
    v++;
    size_t i = 0;
    while (*v && *v != '"' && i < outlen - 1) {
        if (*v == '\\') {
            char n = *(v + 1);
            if (n == 'n')      out[i++] = '\n';
            else if (n == 't') out[i++] = '\t';
            else if (n == '"') out[i++] = '"';
            else if (n == '\\') out[i++] = '\\';
            else if (n == '/') out[i++] = '/';
            else if (n == 'r') out[i++] = '\r';
            else { out[i++] = *v; }   /* 未知转义, 原样 */
            v += 2;
            continue;
        }
        out[i++] = *v++;
    }
    out[i] = '\0';
    return true;
}

static const char *from_anchor(const char *json, const char *anchor)
{
    if (!anchor) return json;
    const char *a = strstr(json, anchor);
    return a ? a : json;
}

bool json_get_str(const char *json, const char *key, char *out, size_t outlen)
{
    const char *v = find_field(json, key);
    return v ? extract_str(v, out, outlen) : false;
}

bool json_get_str_after(const char *json, const char *anchor, const char *key,
                        char *out, size_t outlen)
{
    const char *v = find_field(from_anchor(json, anchor), key);
    return v ? extract_str(v, out, outlen) : false;
}

double json_get_num(const char *json, const char *key)
{
    const char *v = find_field(json, key);
    if (!v) return 0;
    return strtod(skip_ws(v), NULL);
}

double json_get_num_after(const char *json, const char *anchor, const char *key)
{
    const char *v = find_field(from_anchor(json, anchor), key);
    if (!v) return 0;
    return strtod(skip_ws(v), NULL);
}
