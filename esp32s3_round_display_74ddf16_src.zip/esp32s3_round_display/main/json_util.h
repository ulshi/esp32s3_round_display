#pragma once

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 极简 JSON 取值(无需 cJSON 组件): 仅按 "key":value 文本匹配提取。
 * 适用于 Open-Meteo / OpenAI 这类结构固定的响应。复杂嵌套请用带 anchor 的版本。
 */

/* 取字符串值: 找到第一个作为键出现的 key, 把其后的 "value" 拷出(处理基础转义)。 */
bool json_get_str(const char *json, const char *key, char *out, size_t outlen);

/* 从 anchor 之后开始找 key(用于嵌套, 如对话里 assistant 的 content)。 */
bool json_get_str_after(const char *json, const char *anchor, const char *key,
                        char *out, size_t outlen);

/* 取数值(找不到返回 0)。 */
double json_get_num(const char *json, const char *key);

/* 从 anchor 之后开始找数值。 */
double json_get_num_after(const char *json, const char *anchor, const char *key);

#ifdef __cplusplus
}
#endif
