#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 圆形屏布局工具: 以面板尺寸(360)为基准, 圆心在中心。 */

/** 给定 y(0..H-1), 返回该行圆的半弦长(像素), 已扣边距 margin。 */
int ui_half_width_at_y(int y, int margin);

/** 给定 y 与单字宽度 char_w(px), 返回该行可容纳字符数。 */
int ui_chars_per_line(int y, int char_w, int margin);

/** 点 (x,y) 是否在圆内(含 margin 收缩)。 */
bool ui_point_in_circle(int x, int y, int margin);

#ifdef __cplusplus
}
#endif
