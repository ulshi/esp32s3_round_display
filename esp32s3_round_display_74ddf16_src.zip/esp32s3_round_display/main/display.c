#include "display.h"

#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_st77916.h"
#include "esp_lcd_touch_cst816s.h"
#include "esp_err.h"
#include "esp_log.h"

#include "board_config.h"

static const char *TAG = "board_display";

static esp_lcd_panel_handle_t g_panel = NULL;
static esp_lcd_touch_handle_t g_touch = NULL;

/* ---------------- 背光 PWM (LEDC) ---------------- */
static void backlight_pwm_init(void)
{
    ledc_timer_config_t timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = LEDC_TIMER_10_BIT,   /* 0..1023 */
        .timer_num = LEDC_TIMER_0,
        .freq_hz = 5000,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&timer);

    ledc_channel_config_t ch = {
        .gpio_num = BOARD_LCD_BL,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    ledc_channel_config(&ch);
}

void board_backlight_set(int percent)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    uint32_t duty = (percent * 1023) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

/* ---------------- 显示 + 触摸 ---------------- */
esp_err_t board_display_init(esp_lcd_panel_io_color_trans_done_cb_t trans_done_cb, void *user_ctx)
{
    /* 背光先关, 初始化完成后开 */
    gpio_config_t bk = {
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = 1ULL << BOARD_LCD_BL,
    };
    gpio_config(&bk);
    gpio_set_level(BOARD_LCD_BL, BOARD_LCD_BL_OFF_LEVEL);
    backlight_pwm_init();

    ESP_LOGI(TAG, "Initialize SPI bus (QSPI ST77916)");
    spi_bus_config_t buscfg = {
        .sclk_io_num = BOARD_LCD_PCLK,
        .data0_io_num = BOARD_LCD_DATA0,
        .data1_io_num = BOARD_LCD_DATA1,
        .data2_io_num = BOARD_LCD_DATA2,
        .data3_io_num = BOARD_LCD_DATA3,
        .max_transfer_sz = BOARD_LCD_H_RES * BOARD_LCD_V_RES * BOARD_LCD_BIT_PER_PIXEL / 8,
        .flags = SPICOMMON_BUSFLAG_MASTER,
    };
    ESP_ERROR_CHECK(spi_bus_initialize(BOARD_LCD_HOST, &buscfg, SPI_DMA_CH_AUTO));

    ESP_LOGI(TAG, "Install panel IO (QSPI, quad_mode)");
    esp_lcd_panel_io_handle_t io_handle = NULL;
    esp_lcd_panel_io_spi_config_t io_config = {
        .cs_gpio_num = BOARD_LCD_CS,
        .dc_gpio_num = -1,                 /* QSPI 无 DC 线 */
        .spi_mode = 0,
        .pclk_hz = 50 * 1000 * 1000,       /* 与 Arduino 示例 50MHz 对齐 */
        .lcd_cmd_bits = 32,                /* ST77916 命令 32 位 */
        .lcd_param_bits = 8,
        .trans_queue_depth = 10,
        .on_color_trans_done = trans_done_cb,
        .user_ctx = user_ctx,
        .flags = {
            .quad_mode = 1,                /* 关键: 开启四线 QSPI */
        },
    };
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)BOARD_LCD_HOST,
                                            &io_config, &io_handle));

    st77916_vendor_config_t vendor_config = {
        .flags = {
            .use_qspi_interface = 1,       /* 必填: 走 QSPI */
        },
    };
    esp_lcd_panel_dev_config_t panel_config = {
        .reset_gpio_num = BOARD_LCD_RST,
        .rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB,
        .bits_per_pixel = BOARD_LCD_BIT_PER_PIXEL,
        .vendor_config = &vendor_config,
    };
    ESP_LOGI(TAG, "Install ST77916 driver");
    ESP_ERROR_CHECK(esp_lcd_new_panel_st77916(io_handle, &panel_config, &g_panel));
    ESP_ERROR_CHECK(esp_lcd_panel_reset(g_panel));
    ESP_ERROR_CHECK(esp_lcd_panel_init(g_panel));
    ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(g_panel, true));

    /* ---- 触摸 CST816S (I2C) ---- */
    /* 先把触摸 RST 拉高, 让芯片退出复位态。
     * 否则 GPIO 默认电平可能把它按在复位里, I2C 完全不应答
     * (表现为总线扫描不到任何设备 + read_id 失败)。 */
    gpio_config_t tp_rst_cfg = {
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = 1ULL << BOARD_TOUCH_RST,
    };
    gpio_config(&tp_rst_cfg);
    gpio_set_level(BOARD_TOUCH_RST, 1);
    vTaskDelay(pdMS_TO_TICKS(20));

    ESP_LOGI(TAG, "Initialize I2C bus for touch");
    i2c_master_bus_config_t i2c_bus_conf = {
        .i2c_port = BOARD_TOUCH_I2C_PORT,
        .sda_io_num = BOARD_TOUCH_SDA,
        .scl_io_num = BOARD_TOUCH_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags = { .enable_internal_pullup = true },
    };
    i2c_master_bus_handle_t i2c_bus = NULL;
    ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_conf, &i2c_bus));

    /* 诊断: 扫描 I2C 总线, 确认触摸芯片(期望 0x15)是否真的应答 */
    ESP_LOGI(TAG, "I2C scan (expect CST816S @ 0x15):");
    for (uint8_t addr = 0x08; addr < 0x78; addr++) {
        if (i2c_master_probe(i2c_bus, addr, 50) == ESP_OK) {
            ESP_LOGI(TAG, "   device ACK at 0x%02X", addr);
        }
    }

    esp_lcd_panel_io_handle_t tp_io_handle = NULL;
    esp_lcd_panel_io_i2c_config_t tp_io_config = ESP_LCD_TOUCH_IO_I2C_CST816S_CONFIG();
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c(i2c_bus, &tp_io_config, &tp_io_handle));

    const esp_lcd_touch_config_t tp_cfg = {
        .x_max = BOARD_LCD_H_RES,
        .y_max = BOARD_LCD_V_RES,
        .rst_gpio_num = BOARD_TOUCH_RST,
        .int_gpio_num = BOARD_TOUCH_INT,
        .levels = { .reset = 0, .interrupt = 0 },
        .flags = { .swap_xy = 0, .mirror_x = 0, .mirror_y = 0 },
    };
    ESP_LOGI(TAG, "Initialize CST816S touch");
    /* 触摸失败不应拖垮整机: 降级为"无触摸", 屏幕仍可正常显示 */
    esp_err_t tp_err = esp_lcd_touch_new_i2c_cst816s(tp_io_handle, &tp_cfg, &g_touch);
    if (tp_err != ESP_OK) {
        ESP_LOGW(TAG, "CST816S init failed: %s - 触摸不可用, 屏幕继续工作", esp_err_to_name(tp_err));
        g_touch = NULL;
    } else {
        ESP_LOGI(TAG, "CST816S touch ready");
    }

    ESP_LOGI(TAG, "Turn on backlight (80%)");
    board_backlight_set(80);

    return ESP_OK;
}

esp_lcd_panel_handle_t board_panel_get(void)
{
    return g_panel;
}

esp_lcd_touch_handle_t board_touch_get(void)
{
    return g_touch;
}
