#include "qr_ui.h"

#include <stdlib.h>
#include <string.h>

#include "qrcode/qrcodegen.h"
#include "esp_heap_caps.h"

/* 复用的像素缓冲(PSRAM); 重复调用会释放旧缓冲再分配, 避免泄漏。 */
static lv_color_t *g_qr_buf = NULL;

/* qrcodegen 要求调用方提供两块最大尺寸缓冲; 放在静态区而非栈上,
 * 避免占用 LVGL 任务(仅 6KB 栈)导致溢出。QR 生成是单线程 UI 操作, 静态安全。 */
static uint8_t g_qr_temp[qrcodegen_BUFFER_LEN_MAX];
static uint8_t g_qr_code[qrcodegen_BUFFER_LEN_MAX];

bool qr_draw_text(lv_obj_t *canvas, int csize, const char *text)
{
    if (!canvas || !text || !*text) return false;
    if (csize < 21) return false;

    bool ok = qrcodegen_encodeText(text, g_qr_temp, g_qr_code,
                                   qrcodegen_Ecc_MEDIUM,
                                   qrcodegen_VERSION_MIN, qrcodegen_VERSION_MAX,
                                   qrcodegen_Mask_AUTO, true);
    if (!ok) return false;

    int size  = qrcodegen_getSize(g_qr_code);   /* 模块边长, 如 21..177 */
    int quiet = 2;                            /* 静区(模块) */
    int total = size + quiet * 2;
    int scale = csize / total;
    if (scale < 1) scale = 1;

    if (g_qr_buf) { heap_caps_free(g_qr_buf); g_qr_buf = NULL; }
    g_qr_buf = (lv_color_t *)heap_caps_malloc(
        (size_t)csize * csize * sizeof(lv_color_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!g_qr_buf) return false;

    lv_canvas_set_buffer(canvas, g_qr_buf, csize, csize, LV_IMG_CF_TRUE_COLOR);
    lv_canvas_fill_bg(canvas, lv_color_white(), LV_OPA_COVER);

    lv_color_t dark = lv_color_black();
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            if (qrcodegen_getModule(g_qr_code, x, y)) {
                int px = (x + quiet) * scale;
                int py = (y + quiet) * scale;
                for (int sy = 0; sy < scale; sy++) {
                    for (int sx = 0; sx < scale; sx++) {
                        lv_canvas_set_px(canvas, px + sx, py + sy, dark);
                    }
                }
            }
        }
    }
    return true;
}
