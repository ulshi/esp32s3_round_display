#include "circular_layout.h"
#include "board_config.h"
#include <math.h>

int ui_half_width_at_y(int y, int margin)
{
    int dy = y - BOARD_SCREEN_CENTER;
    int r = BOARD_SCREEN_RADIUS - margin;
    if (abs(dy) >= r) return 0;
    int hw = (int)sqrtf((float)(r * r - dy * dy));
    return hw;
}

int ui_chars_per_line(int y, int char_w, int margin)
{
    if (char_w <= 0) return 0;
    int hw = ui_half_width_at_y(y, margin);
    int total = 2 * hw;
    if (total <= 0) return 0;
    return total / char_w;
}

bool ui_point_in_circle(int x, int y, int margin)
{
    int dx = x - BOARD_SCREEN_CENTER;
    int dy = y - BOARD_SCREEN_CENTER;
    int r = BOARD_SCREEN_RADIUS - margin;
    return (dx * dx + dy * dy) <= r * r;
}
