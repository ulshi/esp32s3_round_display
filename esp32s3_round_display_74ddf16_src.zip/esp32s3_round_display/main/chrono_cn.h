#pragma once

#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 天干地支 / 小六壬 计算。
 *
 * 说明: 干支"月柱"采用"以公历月近似"的简化算法(子月=1月 ... 丑月=12月),
 *       未引入二十四节气精确分界(立春/惊蛰等), 因此节气附近一两天的月柱可能与
 *       传统历法有一柱之差。年/日/时柱为精确算法。
 */

/* 由本地时间 tm 计算四柱干支 + 时辰。
 * tm 应为已 localtime 的结果(年 = tm_year + 1900)。
 * 各 out 缓冲至少 8 字节。
 * 返回: 时辰索引 0..11 (子=0 ... 亥=11), 供小六壬使用。 */
int ganzhi_from_tm(const struct tm *tm,
                   char *year_gz, char *month_gz, char *day_gz,
                   char *hour_gz, char *shichen_out);

/* 小六壬起课 (李淳风六壬时课)。
 * month: 1..12, day: 1..31, shichen: 1..12 (子时=1 ... 亥时=12)。
 * 返回三次推导的六神索引 (0..5, 大安=0 ... 空亡=5):
 *   step1 = 月推结果, step2 = 日推结果, step3 = 时推结果 (= 最终)。 */
typedef struct {
    int step1;   /* 月推结果索引 */
    int step2;   /* 日推结果索引 */
    int step3;   /* 时推结果索引 (= 最终) */
} xiaoliuren_result_t;

void xiaoliuren_cast_full(int month, int day, int shichen, xiaoliuren_result_t *out);

/* 六神名称 / 占辞 (idx 0..5, 越界返回空串)。 */
const char *xiaoliuren_name(int idx);
const char *xiaoliuren_desc(int idx);

#ifdef __cplusplus
}
#endif
