#include "sd_card.h"

#include <sys/stat.h>

#include "board_config.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "driver/sdmmc_host.h"   /* SDMMC_HOST_DEFAULT() / sdmmc_slot_config_t */
#include "esp_log.h"

static const char *TAG = "sd_card";

/* 上一次挂载的错误码, 供 sd_card_last_error() 翻译成人话。
 * ESP_OK 表示成功或尚未尝试。 */
static esp_err_t g_last_err = ESP_OK;

esp_err_t sd_card_mount(void)
{
    /* 幂等: 开机时 main.c 已调用过一次, 之后每次开关文件服务器都会再调用。
     * 已挂载就直接返回, 避免重复 mount 产生 "已注册" 之类的干扰性错误。 */
    if (sd_card_is_mounted()) {
        g_last_err = ESP_OK;
        return ESP_OK;
    }

    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.clk = BOARD_SD_CLK;
    slot.cmd = BOARD_SD_CMD;
    slot.d0 = BOARD_SD_D0;
    slot.d1 = BOARD_SD_D1;
    slot.d2 = BOARD_SD_D2;
    slot.d3 = BOARD_SD_D3;
    slot.width = 4;
    slot.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;

    esp_vfs_fat_sdmmc_mount_config_t mount_cfg = {
        .format_if_mount_failed = false,
        .max_files = 8,
        .allocation_unit_size = 16 * 1024,
    };

    sdmmc_card_t *card = NULL;
    esp_err_t r = esp_vfs_fat_sdmmc_mount("/sdcard", &host, &slot, &mount_cfg, &card);
    if (r != ESP_OK) {
        ESP_LOGE(TAG, "SD mount failed: %s (无卡将跳过, 非致命)", esp_err_to_name(r));
        g_last_err = r;
        return r;
    }

    /* 创建统一资源目录 */
    static const char *dirs[] = {
        "/sdcard/books", "/sdcard/images", "/sdcard/video",
        "/sdcard/music", "/sdcard/fonts", "/sdcard/aida",
        "/sdcard/weather", "/sdcard/config",
    };
    for (int i = 0; i < (int)(sizeof(dirs) / sizeof(dirs[0])); i++) {
        mkdir(dirs[i], 0755);
    }
    ESP_LOGI(TAG, "SD mounted, dirs ready");
    g_last_err = ESP_OK;
    return ESP_OK;
}

bool sd_card_is_mounted(void)
{
    struct stat st;
    return (stat("/sdcard", &st) == 0 && S_ISDIR(st.st_mode));
}

const char *sd_card_last_error(void)
{
    if (sd_card_is_mounted()) return NULL;   /* 已挂载, 无错误 */

    switch (g_last_err) {
    case ESP_OK:
        return "SD 卡未插入";
    case ESP_ERR_NOT_FOUND:
    case ESP_ERR_TIMEOUT:
        return "SD 卡未插入或接触不良";
    case ESP_ERR_NO_MEM:
        return "内存不足, 无法挂载";
    case ESP_ERR_INVALID_STATE:
        return "SD 卡挂载状态异常(请重启设备)";
    case ESP_ERR_NOT_SUPPORTED:
    case ESP_ERR_INVALID_RESPONSE:
        return "SD 卡不识别(卡片损坏或不兼容)";
    default:
        /* ESP_FAIL 等多为 f_mount 失败: 卡已被识别, 但文件系统读不出来。
         * 本工程 FatFs 关闭了 exFAT(FF_FS_EXFAT=0), 卡片必须是 FAT32/FAT16。 */
        return "卡已识别但文件系统不支持(需 FAT32)";
    }
}
