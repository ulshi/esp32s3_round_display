#include "chrono_cn.h"

#include <string.h>
#include <stdio.h>

static const char *TIANGAN[] = {"甲","乙","丙","丁","戊","己","庚","辛","壬","癸"};
static const char *DIZHI[]   = {"子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥"};
static const char *SHICHEN[] = {"子时","丑时","寅时","卯时","辰时","巳时",
                                "午时","未时","申时","酉时","戌时","亥时"};

/* 计算公历日期的儒略日 (Fliegel & Van Flandern 公式)。 */
static int jdn(int y, int m, int d)
{
    int a = (14 - m) / 12;
    int yy = y + 4800 - a;
    int mm = m + 12 * a - 3;
    return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045;
}

int ganzhi_from_tm(const struct tm *tm,
                   char *year_gz, char *month_gz, char *day_gz,
                   char *hour_gz, char *shichen_out)
{
    int y = tm->tm_year + 1900;
    int m = tm->tm_mon + 1;
    int d = tm->tm_mday;
    int h = tm->tm_hour;

    /* ---- 年柱 ---- */
    int y_stem   = ((y - 4) % 10 + 10) % 10;
    int y_branch = ((y - 4) % 12 + 12) % 12;

    /* ---- 月柱 (正月建寅: 寅月≈公历2月, 丑月≈1月 ... 子月≈12月) ---- */
    int m_branch = ((m % 12) + 12) % 12;
    /* 五虎遁: 甲己之年丙作首, 乙庚之岁戊为头, 丙辛必定寻庚起,
     *         丁壬壬位顺行流, 戊癸之年甲好求。正月(寅月)天干表。 */
    static const int first_month_stem[5] = {2, 4, 6, 8, 0};
    int m_stem = (first_month_stem[y_stem % 5] + (((m - 2) % 10) + 10) % 10) % 10;

    /* ---- 日柱 (以 1900-01-01 = 甲戌 为基准, 干支序号 10) ---- */
    int days = jdn(y, m, d) - jdn(1900, 1, 1);
    int day_idx = ((10 + days) % 60 + 60) % 60;
    int d_stem   = day_idx % 10;
    int d_branch = day_idx % 12;

    /* ---- 时柱 + 时辰 ---- */
    int shichen_idx = (h + 1) / 2 % 12;   /* 23-1->子 ... */
    /* 五鼠遁: 甲己还加甲, 乙庚丙作初, 丙辛从戊起,
     *         丁壬庚子居, 戊癸壬子出。子时天干表。 */
    static const int first_hour_stem[5] = {0, 2, 4, 6, 8};
    int h_stem = (first_hour_stem[d_stem % 5] + shichen_idx) % 10;
    int h_branch = shichen_idx;

    snprintf(year_gz,  8, "%s%s", TIANGAN[y_stem],   DIZHI[y_branch]);
    snprintf(month_gz, 8, "%s%s", TIANGAN[m_stem],   DIZHI[m_branch]);
    snprintf(day_gz,   8, "%s%s", TIANGAN[d_stem],   DIZHI[d_branch]);
    snprintf(hour_gz,  8, "%s%s", TIANGAN[h_stem],   DIZHI[h_branch]);
    snprintf(shichen_out, 8, "%s", SHICHEN[shichen_idx]);

    return shichen_idx;
}

/* 六神: 1.大安 2.留连 3.速喜 4.赤口 5.小吉 6.空亡 */
static const char *LIUREN_NAME[6] = {
    "大安", "留连", "速喜", "赤口", "小吉", "空亡"
};
static const char *LIUREN_DESC[6] = {
    "安稳吉祥 诸事顺遂",
    "事多纠缠 宜守迟疑",
    "喜讯将至 谋事可成",
    "口舌是非 言行须慎",
    "和合小顺 平稳有喜",
    "谋望落空 静待时机"
};

void xiaoliuren_cast_full(int month, int day, int shichen, xiaoliuren_result_t *out)
{
    /* 寅上起月, 月上起日, 日上起时: 从大安(位置1)依次计数, 记录每步落点。 */
    int pos = 1;
    pos = ((pos - 1 + (month   - 1)) % 6 + 6) % 6 + 1;
    out->step1 = pos - 1;
    pos = ((pos - 1 + (day     - 1)) % 6 + 6) % 6 + 1;
    out->step2 = pos - 1;
    pos = ((pos - 1 + (shichen - 1)) % 6 + 6) % 6 + 1;
    out->step3 = pos - 1;
}

const char *xiaoliuren_name(int idx)
{
    if (idx < 0 || idx > 5) return "";
    return LIUREN_NAME[idx];
}

const char *xiaoliuren_desc(int idx)
{
    if (idx < 0 || idx > 5) return "";
    return LIUREN_DESC[idx];
}
