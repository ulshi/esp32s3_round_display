#pragma once

#include "driver/gpio.h"
#include "driver/spi_common.h"
#include "driver/i2c_master.h"   /* IDF v6.x 新 I2C master 驱动 (旧 driver/i2c.h 已弃用) */

#ifdef __cplusplus
extern "C" {
#endif

/* =========================================================================
 * 第一款硬件引脚定义 (ESP32-S3 + ST77916 360x360 圆屏 QSPI + CST816S 触摸)
 * 来源: Demo_Arduino/ST77916_LVGL_DEMO/pincfg.h
 * ========================================================================= */

/* ---- 显示屏 ST77916 (QSPI) ---- */
#define BOARD_LCD_HOST            SPI2_HOST
#define BOARD_LCD_CS              GPIO_NUM_10
#define BOARD_LCD_PCLK            GPIO_NUM_9
#define BOARD_LCD_DATA0           GPIO_NUM_11
#define BOARD_LCD_DATA1           GPIO_NUM_12
#define BOARD_LCD_DATA2           GPIO_NUM_13
#define BOARD_LCD_DATA3           GPIO_NUM_14
#define BOARD_LCD_RST             GPIO_NUM_47
#define BOARD_LCD_BL              GPIO_NUM_15   /* 背光: LEDC PWM 调光 */
#define BOARD_LCD_H_RES           360
#define BOARD_LCD_V_RES           360
#define BOARD_LCD_BIT_PER_PIXEL   16

#define BOARD_LCD_BL_ON_LEVEL     1
#define BOARD_LCD_BL_OFF_LEVEL    (!BOARD_LCD_BL_ON_LEVEL)

/* ---- 触摸 CST816S (I2C) ---- */
#define BOARD_TOUCH_I2C_PORT      0        /* I2C 端口号 (新驱动使用 i2c_port_num_t) */
#define BOARD_TOUCH_SCL           GPIO_NUM_8
#define BOARD_TOUCH_SDA           GPIO_NUM_7
#define BOARD_TOUCH_RST           GPIO_NUM_40
#define BOARD_TOUCH_INT           GPIO_NUM_41

/* ---- SD 卡 (SDMMC 4-bit) ---- */
#define BOARD_SD_CLK              GPIO_NUM_3
#define BOARD_SD_CMD              GPIO_NUM_4
#define BOARD_SD_D0               GPIO_NUM_2
#define BOARD_SD_D1               GPIO_NUM_1
#define BOARD_SD_D2               GPIO_NUM_6
#define BOARD_SD_D3               GPIO_NUM_5

/* 屏为圆形, 半径与圆心(以像素坐标计) */
#define BOARD_SCREEN_RADIUS       (BOARD_LCD_H_RES / 2)   /* 180 */
#define BOARD_SCREEN_CENTER       (BOARD_LCD_H_RES / 2)   /* 180 */

#ifdef __cplusplus
}
#endif
