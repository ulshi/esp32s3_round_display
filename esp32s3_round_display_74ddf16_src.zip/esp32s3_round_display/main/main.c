#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_system.h"

#include "nvs_config.h"
#include "sd_card.h"
#include "display.h"
#include "lvgl_helper.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "wifi_prov.h"
#include "file_server.h"
#include "fw_version.h"   /* 构建时由 gen_version.cmake 生成, 含 FW_VERSION_STR 等宏 */

static const char *TAG = "app";

/**
 * 心跳任务: 每 5 秒打印一次, 用来确认固件真的在持续运行
 * (而不只是启动一次就卡死)。在没有屏幕的开发板上尤其有用。
 */
static void heartbeat_task(void *arg)
{
    (void)arg;
    int n = 0;
    while (1) {
        ESP_LOGI(TAG, "alive %ds | free heap=%lu | min free heap=%lu",
                 (n + 1) * 5,
                 (unsigned long)esp_get_free_heap_size(),
                 (unsigned long)esp_get_minimum_free_heap_size());
        n++;
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "Firmware version: %s", FW_VERSION_STR);

    nvs_config_init();
    app_set_timezone();          /* 默认东八区 */
    app_apply_clock_time();      /* 套用默认/手工时间 (须在时区之后) */
    ui_i18n_init();              /* 读 NVS 语言 (必须在 ui_manager_init 前) */
    sd_card_mount();             /* 无卡不致命 */

    lvgl_init();                 /* 内部完成 board_display_init + LVGL 驱动 + 任务 */
    board_backlight_set(nvs_config_get_int(NVS_BRIGHTNESS, 50));  /* 套用记忆的亮度, 缺省 50% */
    app_wifi_init();              /* netif + 事件循环 + 默认 STA/AP 接口 */
    app_wifi_start();             /* 已配网则 STA 连接, 否则 SoftAP 配网 */
    if (nvs_config_get_int(NVS_FILE_SERVER, 0) == 1) {
        file_server_set_enabled(true);   /* 若上次开启了文件服务器, 重启后恢复 */
    }
    ui_manager_init();           /* 进入主菜单, 启动 12 页框架 */

    xTaskCreate(heartbeat_task, "heartbeat", 3 * 1024, NULL, 1, NULL);
}
