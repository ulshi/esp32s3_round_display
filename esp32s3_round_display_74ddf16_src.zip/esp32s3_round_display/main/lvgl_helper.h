#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

/** 初始化 LVGL: 显示驱动 + 刷新任务 + 触摸输入 + 滑动手势 + 互斥量。 */
void lvgl_init(void);

/** 进入 LVGL 临界区 (线程安全)。timeout_ms = -1 表示一直等。返回 true 表示拿到锁。 */
bool lvgl_lock(int timeout_ms);

/** 离开 LVGL 临界区。 */
void lvgl_unlock(void);

/**
 * 登记"亮度控件"对象。若一次手势从该控件上按下, 即使产生滑动也不触发页面导航,
 * 从而避免调节亮度时误触返回主页。传 NULL 表示清空(切换页面时调用)。
 */
void lvgl_set_brightness_obj(lv_obj_t *obj);

/** 长按导航后调用: 抑制紧随其后的"松手"手势, 防止松手被误判为滑动而返回主页。 */
void lvgl_consume_release_gesture(void);

/** 临时屏蔽所有导航手势(如弹出二维码浮层时), 防止滑动误触切换页面。 */
void lvgl_set_gesture_blocked(bool blocked);

#ifdef __cplusplus
}
#endif
