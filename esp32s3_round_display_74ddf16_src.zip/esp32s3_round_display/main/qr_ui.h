#pragma once

#include "lvgl.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 把文本编码为二维码并绘制到 canvas 上。
 * canvas 须先用 lv_obj_set_size 设为 csize×csize 正方形。
 * 内部自动分配 PSRAM 像素缓冲(重复调用会复用/释放), 调用方无需管理。
 * 返回 true 表示成功生成并绘制。 */
bool qr_draw_text(lv_obj_t *canvas, int csize, const char *text);

#ifdef __cplusplus
}
#endif
