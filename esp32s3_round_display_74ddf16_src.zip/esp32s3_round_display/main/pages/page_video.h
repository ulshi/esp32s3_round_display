#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_video_create(void);
#ifdef __cplusplus
}
#endif
