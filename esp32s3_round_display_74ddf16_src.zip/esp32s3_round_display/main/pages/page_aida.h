#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_aida_create(void);
#ifdef __cplusplus
}
#endif
