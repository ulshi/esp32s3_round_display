#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_settings_create(void);
#ifdef __cplusplus
}
#endif
