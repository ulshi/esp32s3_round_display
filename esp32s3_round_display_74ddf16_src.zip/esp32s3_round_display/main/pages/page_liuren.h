#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_liuren_create(void);

/* 切换占卜模式 (dir>0 正向循环, dir<0 反向), 供左右滑手势调用。 */
void page_liuren_cycle_mode(int dir);
#ifdef __cplusplus
}
#endif
