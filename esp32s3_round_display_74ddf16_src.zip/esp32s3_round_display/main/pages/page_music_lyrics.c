#include "page_music_lyrics.h"
#include "ui_manager.h"
#include "board_config.h"
#include "music_shared.h"

static int g_idx = 0;                 /* 当前播放行 (M1 demo 独立维护) */
static lv_obj_t *g_cont = NULL;

static void lyric_tap_cb(lv_event_t *e);   /* 前向声明 */

/* 重建列表: 显示 g_idx 前后各 3 行, 当前行高亮并居中 */
static void rebuild_lyrics(void)
{
    lv_obj_clean(g_cont);
    lv_obj_t *cur_label = NULL;

    for (int i = g_idx - 3; i <= g_idx + 3; i++) {
        if (i < 0 || i >= SAMPLE_COUNT) continue;
        lv_obj_t *l = lv_label_create(g_cont);
        lv_label_set_text(l, SAMPLE_LYRICS[i]);
        lv_obj_set_style_text_font(l, ui_font(14), 0);
        lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
        if (i == g_idx) {
            lv_obj_set_style_text_color(l, lv_color_make(0xB7, 0x9B, 0xFF), 0);
            lv_obj_set_style_text_font(l, ui_font(16), 0);
            cur_label = l;
        } else {
            lv_obj_set_style_text_color(l, lv_color_make(0x6B, 0x70, 0x80), 0);
        }
        lv_obj_set_user_data(l, (void *)(intptr_t)i);
        lv_obj_add_event_cb(l, lyric_tap_cb, LV_EVENT_CLICKED, NULL);
    }

    if (cur_label) {
        lv_obj_scroll_to_view(cur_label, LV_ANIM_OFF);
    }
}

static void lyric_tap_cb(lv_event_t *e)
{
    int i = (int)(intptr_t)lv_obj_get_user_data(lv_event_get_target(e));
    g_idx = i;                      /* 点哪行快进到哪行 (M1 为占位, 仅移动高亮) */
    rebuild_lyrics();
}

static void back_to_cur_cb(lv_event_t *e)
{
    (void)e;
    rebuild_lyrics();               /* 滚回当前播放行 */
}

void page_music_lyrics_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    lv_obj_set_style_bg_color(root, lv_color_make(0x1B, 0x1F, 0x27), 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    ui_page_title(root, "Lyrics");

    g_cont = lv_obj_create(root);
    lv_obj_set_size(g_cont, 320, 300);
    lv_obj_align(g_cont, LV_ALIGN_TOP_MID, 0, 40);
    lv_obj_set_style_bg_opa(g_cont, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(g_cont, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(g_cont, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(g_cont, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(g_cont, 10, 0);
    lv_obj_add_flag(g_cont, LV_OBJ_FLAG_SCROLLABLE);

    rebuild_lyrics();

    lv_obj_t *back = ui_label_create(root, "back to current", ui_font(12), lv_color_make(0xB7, 0x9B, 0xFF));
    lv_obj_align(back, LV_ALIGN_BOTTOM_MID, 0, -36);
    lv_obj_add_flag(back, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(back, back_to_cur_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *hint = ui_label_create(root, "swipe up->home | right->player", ui_font(11), lv_color_make(0x5B, 0x61, 0x70));
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -16);
}
