#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_ebook_create(void);

/* 翻页: dir<0 上一页, dir>0 下一页。供手势回调调用。 */
void ebook_turn(int dir);
#ifdef __cplusplus
}
#endif
