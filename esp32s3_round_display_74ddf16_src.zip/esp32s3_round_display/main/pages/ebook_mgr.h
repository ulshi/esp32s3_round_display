#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define EBOOK_DIR      "/sdcard/books"
#define EBOOK_MAX_FILES 32
#define EBOOK_NAME_LEN  64   /* 含路径的短文件名缓存 (不含目录前缀) */

/** 扫描 books 目录, 填充文件列表。返回找到的 .txt 数量。 */
int ebook_scan(void);

/** 当前书籍数量。 */
int ebook_count(void);

/** 取第 i 本书的文件名(不含目录, 用于显示标题)。 */
const char *ebook_name(int i);

/** 取第 i 本书的完整路径。 */
const char *ebook_path(int i);

/** 设置/读取当前阅读的书索引 (持久化到 NVS 的 "ebook_idx")。 */
void ebook_set_current(int i);
int  ebook_current(void);

/** 打开当前书, 构建行偏移表 (流式, 不载入全文)。
 *  幂等: 若当前书已打开且未切换, 直接返回 true, 不重复扫描。
 *  返回是否成功。 */
bool ebook_open_current(void);

/** 关闭当前书, 释放偏移表。 */
void ebook_close(void);

/** 当前书总行数。 */
int ebook_lines(void);

/** 一次性把 [start_line, start_line+num_lines) 范围内的原始文本读入 out,
 *  返回读到的字节数 (含 '\0' 结尾, 不含行号)。调用方自行按 '\n' 切行。
 *  比逐行 fseek+fgetc 快得多, 翻页渲染专用。 */
int ebook_read_page(int start_line, int num_lines, char *out, int out_cap);

/** 翻页: 返回新的起始行号 (step 为负=上一页)。会按可见区域估算每页行数。 */
int ebook_page_turn(int start_line, int step);

#ifdef __cplusplus
}
#endif
