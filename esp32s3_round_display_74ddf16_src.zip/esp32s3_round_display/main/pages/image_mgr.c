#include "image_mgr.h"

#include <stdio.h>
#include <string.h>
#include <dirent.h>

#include "nvs_config.h"
#include "esp_log.h"

static const char *TAG = "images";

static char g_names[IMG_MAX_FILES][IMG_NAME_LEN];
static char g_paths[IMG_MAX_FILES][IMG_NAME_LEN + 32];
static img_type_t g_types[IMG_MAX_FILES];
static int  g_count = 0;
static int  g_current = 0;

/* 把真实路径转成 LVGL 文件系统路径(S 盘符), 返回指向静态缓冲的指针 */
static char g_fsbuf[IMG_NAME_LEN + 40];
static const char *to_fs(const char *real)
{
    snprintf(g_fsbuf, sizeof(g_fsbuf), "S:%s", real);
    return g_fsbuf;
}

static img_type_t ext_type(const char *name)
{
    int n = (int)strlen(name);
    if (n < 4) return IMG_UNKNOWN;
    const char *ext = name + n - 4;
    if (strcasecmp(ext, ".png") == 0) return IMG_PNG;
    if (strcasecmp(ext, ".bmp") == 0) return IMG_BMP;
    if (strcasecmp(ext, ".gif") == 0) return IMG_GIF;
    if (strcasecmp(ext, ".jpg") == 0) return IMG_JPG;
    if (strcasecmp(ext, ".jpeg") == 0) return IMG_JPEG;
    if (strcasecmp(ext, ".sjpg") == 0) return IMG_SJPG;
    /* 也允许 .JPG 等大写(上面 strcasecmp 已覆盖); 5 字符的 .jpeg 已处理 */
    if (n >= 5 && strcasecmp(name + n - 5, ".jpeg") == 0) return IMG_JPEG;
    return IMG_UNKNOWN;
}

int img_scan(void)
{
    g_count = 0;
    DIR *d = opendir(IMG_DIR);
    if (!d) {
        ESP_LOGW(TAG, "opendir %s failed (SD 未挂载?)", IMG_DIR);
        return 0;
    }
    struct dirent *e;
    while ((e = readdir(d)) != NULL && g_count < IMG_MAX_FILES) {
        img_type_t t = ext_type(e->d_name);
        if (t == IMG_UNKNOWN) continue;
        strncpy(g_names[g_count], e->d_name, IMG_NAME_LEN - 1);
        g_names[g_count][IMG_NAME_LEN - 1] = '\0';
        snprintf(g_paths[g_count], sizeof(g_paths[0]), "%s/%s", IMG_DIR, e->d_name);
        g_types[g_count] = t;
        g_count++;
    }
    closedir(d);
    ESP_LOGI(TAG, "scanned %d images", g_count);
    return g_count;
}

int img_count(void) { return g_count; }

const char *img_name(int i)
{
    if (i < 0 || i >= g_count) return "";
    return g_names[i];
}

const char *img_path(int i)
{
    if (i < 0 || i >= g_count) return "";
    return g_paths[i];
}

const char *img_path_fs(int i)
{
    if (i < 0 || i >= g_count) return "";
    return to_fs(g_paths[i]);
}

img_type_t img_type(int i)
{
    if (i < 0 || i >= g_count) return IMG_UNKNOWN;
    return g_types[i];
}

void img_set_current(int i)
{
    if (i < 0 || i >= g_count) return;
    g_current = i;
    nvs_config_set_int("img_idx", i);
}

int img_current(void) { return g_current; }
