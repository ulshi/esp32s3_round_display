#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_music_create(void);
#ifdef __cplusplus
}
#endif
