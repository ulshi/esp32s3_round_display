#include "page_video.h"
#include "ui_manager.h"
#include "board_config.h"

void page_video_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, "Video");
    ui_label_create(root, "TODO (M5: GIF / seq frames)", ui_font(14), lv_color_white());
}
