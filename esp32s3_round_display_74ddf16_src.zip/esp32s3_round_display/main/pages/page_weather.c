#include "page_weather.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "nvs_config.h"
#include "wifi_prov.h"
#include "net_http.h"
#include "json_util.h"
#include "lvgl_helper.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define WX_BUF 1024

static lv_obj_t *g_temp  = NULL;
static lv_obj_t *g_cond  = NULL;
static lv_obj_t *g_hum   = NULL;
static lv_obj_t *g_wind  = NULL;
static lv_obj_t *g_city  = NULL;
static lv_obj_t *g_status= NULL;
static bool      g_fetching = false;

static const char *wx_desc(int code, bool zh)
{
    switch (code) {
        case 0:  return zh ? "晴"        : "Clear";
        case 1:  return zh ? "晴间多云"  : "Mainly clear";
        case 2:  return zh ? "局部多云"  : "Partly cloudy";
        case 3:  return zh ? "阴"        : "Overcast";
        case 45: case 48: return zh ? "雾" : "Fog";
        case 51: case 53: case 55: return zh ? "毛毛雨" : "Drizzle";
        case 56: case 57: return zh ? "冻毛毛雨" : "Freezing drizzle";
        case 61: case 63: case 65: return zh ? "雨" : "Rain";
        case 66: case 67: return zh ? "冻雨" : "Freezing rain";
        case 71: case 73: case 75: case 77: return zh ? "雪" : "Snow";
        case 80: case 81: case 82: return zh ? "阵雨" : "Rain showers";
        case 85: case 86: return zh ? "阵雪" : "Snow showers";
        case 95: return zh ? "雷阵雨" : "Thunderstorm";
        case 96: case 99: return zh ? "雷阵雨伴冰雹" : "Thunderstorm w/ hail";
        default: return zh ? "未知" : "Unknown";
    }
}

static void wx_update(const char *temp, const char *cond, const char *hum, const char *wind)
{
    if (!lvgl_lock(-1)) return;
    if (g_temp)  lv_label_set_text(g_temp, temp);
    if (g_cond)  lv_label_set_text(g_cond, cond);
    if (g_hum)   lv_label_set_text(g_hum, hum);
    if (g_wind)  lv_label_set_text(g_wind, wind);
    if (g_status)lv_label_set_text(g_status, ui_str(UI_STR_WIFI_CONNECTED));
    lvgl_unlock();
}

static void fetch_task(void *arg)
{
    (void)arg;
    char lat_s[16] = "", lon_s[16] = "", city[32] = "";
    nvs_config_get_str("wx_lat", lat_s, sizeof(lat_s));
    nvs_config_get_str("wx_lon", lon_s, sizeof(lon_s));
    nvs_config_get_str("wx_city", city, sizeof(city));
    if (lat_s[0] == '\0') strcpy(lat_s, "39.9042");
    if (lon_s[0] == '\0') strcpy(lon_s, "116.4074");
    if (city[0] == '\0')  strcpy(city, "Beijing");

    char url[196];
    snprintf(url, sizeof(url),
             "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
             "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
             lat_s, lon_s);

    char buf[WX_BUF];
    int status = 0;
    esp_err_t r = http_get(url, buf, sizeof(buf), &status);
    if (r != ESP_OK || status != 200) {
        if (lvgl_lock(-1)) {
            if (g_status) lv_label_set_text(g_status, "fetch failed");
            lvgl_unlock();
        }
        g_fetching = false;
        vTaskDelete(NULL);
    }

    bool zh = (ui_lang_get() == UI_LANG_ZH);
    double t = json_get_num(buf, "temperature_2m");
    double h = json_get_num(buf, "relative_humidity_2m");
    double w = json_get_num(buf, "wind_speed_10m");
    int    code = (int)json_get_num(buf, "weather_code");

    char s_temp[24], s_cond[40], s_hum[40], s_wind[40];
    snprintf(s_temp, sizeof(s_temp), "%.1f°", t);
    snprintf(s_cond, sizeof(s_cond), "%s", wx_desc(code, zh));
    snprintf(s_hum,  sizeof(s_hum),  "%s %.0f%%", ui_str(UI_STR_HUMIDITY), h);
    snprintf(s_wind, sizeof(s_wind), "%s %.1f", ui_str(UI_STR_WIND), w);

    if (lvgl_lock(-1)) {
        if (g_city) lv_label_set_text(g_city, city);
        lvgl_unlock();
    }
    wx_update(s_temp, s_cond, s_hum, s_wind);
    g_fetching = false;
    vTaskDelete(NULL);
}

static void wx_refresh(void)
{
    if (g_fetching) return;
    if (!app_wifi_is_connected()) {
        if (lvgl_lock(-1)) {
            if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_NO_NET));
            lvgl_unlock();
        }
        return;
    }
    g_fetching = true;
    if (lvgl_lock(-1)) {
        if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_WIFI_PROVISIONING)); /* 借用: 拉取中 */
        lvgl_unlock();
    }
    xTaskCreate(fetch_task, "wx_fetch", 6 * 1024, NULL, 3, NULL);
}

static void wx_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_WEATHER) return;
    wx_refresh();
}

void page_weather_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, ui_str(UI_STR_WEATHER));

    g_city = ui_label_create(root, "—", ui_font(16), lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(g_city, LV_ALIGN_TOP_MID, 0, 60);

    g_temp = ui_label_create(root, "--°", ui_font(52), lv_color_white());
    lv_obj_center(g_temp);

    g_cond = ui_label_create(root, "—", ui_font(18), lv_color_make(0x90, 0xE0, 0xA0));
    lv_obj_align_to(g_cond, g_temp, LV_ALIGN_OUT_BOTTOM_MID, 0, 6);

    g_hum = ui_label_create(root, "—", ui_font(14), lv_color_make(0xB0, 0xC4, 0xD8));
    lv_obj_align(g_hum, LV_ALIGN_TOP_MID, -60, 250);

    g_wind = ui_label_create(root, "—", ui_font(14), lv_color_make(0xB0, 0xC4, 0xD8));
    lv_obj_align(g_wind, LV_ALIGN_TOP_MID, 60, 250);

    g_status = ui_label_create(root, ui_str(UI_STR_WIFI_NOT_CONNECTED), ui_font(12),
                               lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(g_status, LV_ALIGN_BOTTOM_MID, 0, -14);

    wx_refresh();
    lv_timer_create(wx_timer_cb, 600000, NULL);   /* 每 10 分钟刷新 */
}
