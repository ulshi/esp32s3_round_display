#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_clock_create(void);
#ifdef __cplusplus
}
#endif
