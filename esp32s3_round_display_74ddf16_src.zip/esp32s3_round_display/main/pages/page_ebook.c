#include "page_ebook.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "circular_layout.h"
#include "ebook_mgr.h"
#include "nvs_config.h"

#include <string.h>

#define EBOOK_LINES_PER_PAGE 12
static int g_page_start = 0;       /* 当前页起始行 */
static bool g_scanned = false;     /* 书籍列表是否已扫描 */

/* 读取 NVS 上次阅读的书索引 */
static int nvs_ebook_idx(void)
{
    int i = nvs_config_get_int("ebook_idx", 0);
    if (i < 0 || i >= ebook_count()) i = 0;
    return i;
}

void ebook_turn(int dir)
{
    int lines = ebook_lines();
    if (lines <= 0) return;
    g_page_start = ebook_page_turn(g_page_start, dir * EBOOK_LINES_PER_PAGE);
    if (g_page_start < 0) g_page_start = 0;
    ui_show_page(UI_PAGE_EBOOK);   /* 重建当前页 (递归锁安全) */
}

void page_ebook_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    lv_obj_set_style_bg_color(root, lv_color_make(0xF5, 0xF2, 0xE9), 0);   /* 纸色护眼 */
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    if (!g_scanned) {
        ebook_scan();
        g_scanned = true;
        ebook_set_current(nvs_ebook_idx());   /* 恢复上次书 */
    }

    int cnt = ebook_count();
    if (cnt == 0) {
        ui_page_title(root, ui_str(UI_STR_BOOK));
        lv_obj_t *hint = ui_label_create(root, "未找到书籍\n请将 .txt 放入 /sdcard/books",
                                        ui_font(14), lv_color_make(0x88, 0x80, 0x70));
        lv_obj_align(hint, LV_ALIGN_CENTER, 0, 0);
        lv_label_set_long_mode(hint, LV_LABEL_LONG_WRAP);
        return;
    }

    if (!ebook_open_current()) {
        ui_page_title(root, ui_str(UI_STR_BOOK));
        lv_obj_t *err = ui_label_create(root, "打开书籍失败", ui_font(14), lv_color_make(0xAA, 0x40, 0x40));
        lv_obj_align(err, LV_ALIGN_CENTER, 0, 0);
        return;
    }

    ui_page_title(root, ebook_name(ebook_current()));

    /* 渲染当前页: 一次性读入整页原始文本, 再按 '\n' 切行。
     * 一次 fread 替代逐行 fseek+fgetc, 翻页几乎瞬时完成。 */
    int lines = ebook_lines();
    char pagebuf[4096];
    int got = ebook_read_page(g_page_start, EBOOK_LINES_PER_PAGE, pagebuf, sizeof(pagebuf));

    int y = 66;
    int lh = 22;
    int shown = 0;
    const char *p = pagebuf;
    const char *pend = pagebuf + got;
    while (y < 320 && shown < EBOOK_LINES_PER_PAGE && p < pend) {
        const char *nl = p;
        while (nl < pend && *nl != '\n') nl++;

        char buf[160];
        int k = 0;
        for (const char *q = p; q < nl && k < 159; q++) {
            if (*q == '\r') continue;          /* 跳过 CR (CRLF) */
            buf[k++] = *q;
        }
        buf[k] = '\0';

        int cpl = ui_chars_per_line(y, 16, 18);   /* 16px 中文字, 边距 18 */
        if (cpl > 0) {
            if ((int)strlen(buf) > cpl) buf[cpl] = '\0';   /* 超长行简单截断 */
            lv_obj_t *l = ui_label_create(root, buf, ui_font(16), lv_color_make(0x33, 0x33, 0x33));
            lv_obj_align(l, LV_ALIGN_TOP_MID, 0, y);
        }
        y += lh;
        shown++;
        p = (nl < pend) ? nl + 1 : pend;
    }

    /* 页码 + 翻页提示 (底部) */
    char pg[48];
    int total_pages = (lines + EBOOK_LINES_PER_PAGE - 1) / EBOOK_LINES_PER_PAGE;
    int cur_page = g_page_start / EBOOK_LINES_PER_PAGE + 1;
    snprintf(pg, sizeof(pg), "%d/%d", cur_page, total_pages);
    lv_obj_t *hint = ui_label_create(root, pg, ui_font(12), lv_color_make(0x88, 0x80, 0x70));
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -10);

    /* 轻触左右翻页提示 */
    lv_obj_t *turn = ui_label_create(root, ui_str(UI_STR_EBOOK_TURN), ui_font(11), lv_color_make(0x88, 0x80, 0x70));
    lv_obj_align(turn, LV_ALIGN_BOTTOM_MID, 0, -28);
}
