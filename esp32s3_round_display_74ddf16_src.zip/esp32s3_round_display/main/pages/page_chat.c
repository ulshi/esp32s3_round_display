#include "page_chat.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "nvs_config.h"
#include "wifi_prov.h"
#include "net_http.h"
#include "json_util.h"
#include "lvgl_helper.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define CHAT_BUF   1536
#define CHAT_TRANS 2048
#define CHAT_LINE  320

static lv_obj_t *g_msg_cont = NULL;
static lv_obj_t *g_msg_label= NULL;
static lv_obj_t *g_ta       = NULL;
static lv_obj_t *g_kb       = NULL;
static lv_obj_t *g_status   = NULL;
static char      g_transcript[CHAT_TRANS] = "";
static bool      g_busy = false;

/* 把 who:text 追加到对话记录并刷新滚动 */
static void chat_append(const char *who, const char *text)
{
    if (!lvgl_lock(-1)) return;
    int len = (int)strlen(g_transcript);
    snprintf(g_transcript + len, sizeof(g_transcript) - len, "%s%s\n", who, text);
    if (strlen(g_transcript) > CHAT_TRANS - 256) {
        memmove(g_transcript, g_transcript + 256, strlen(g_transcript) - 256 + 1);
    }
    if (g_msg_label) lv_label_set_text(g_msg_label, g_transcript);
    if (g_msg_cont)  lv_obj_scroll_to_y(g_msg_cont, LV_COORD_MAX, LV_ANIM_OFF);
    lvgl_unlock();
}

/* 简易 JSON 字符串转义 */
static void json_escape(const char *src, char *dst, size_t dstlen)
{
    size_t j = 0;
    for (size_t i = 0; src[i] && j < dstlen - 2; i++) {
        char c = src[i];
        if (c == '"' || c == '\\') {
            if (j < dstlen - 3) { dst[j++] = '\\'; dst[j++] = c; }
        } else if (c == '\n') {
            if (j < dstlen - 3) { dst[j++] = '\\'; dst[j++] = 'n'; }
        } else if (c != '\r') {
            dst[j++] = c;
        }
    }
    dst[j] = '\0';
}

/* 工作线程: 发送一条消息并取回回复。arg 为 malloc 的 prompt, 用完释放。 */
static void chat_worker(void *arg)
{
    char *prompt = (char *)arg;
    char base[96] = "", key[160] = "", model[48] = "";
    nvs_config_get_str("ai_base", base, sizeof(base));
    nvs_config_get_str("ai_key",  key,  sizeof(key));
    nvs_config_get_str("ai_model",model,sizeof(model));
    if (base[0]  == '\0') strcpy(base, "https://api.openai.com/v1");
    if (model[0] == '\0') strcpy(model, "gpt-3.5-turbo");

    if (key[0] == '\0') {
        chat_append("⚠ ", ui_str(UI_STR_NO_KEY));
        free(prompt); g_busy = false; vTaskDelete(NULL);
    }
    if (!app_wifi_is_connected()) {
        chat_append("⚠ ", ui_str(UI_STR_NO_NET));
        free(prompt); g_busy = false; vTaskDelete(NULL);
    }

    char esc[CHAT_LINE * 2];
    json_escape(prompt, esc, sizeof(esc));

    char body[CHAT_BUF];
    snprintf(body, sizeof(body),
             "{\"model\":\"%s\",\"messages\":[{\"role\":\"system\","
             "\"content\":\"You are a concise assistant. Reply briefly.\"},"
             "{\"role\":\"user\",\"content\":\"%s\"}]}",
             model, esc);

    char url[160];
    snprintf(url, sizeof(url), "%s/chat/completions", base);

    char resp[CHAT_BUF];
    int status = 0;
    if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_THINKING)); lvgl_unlock(); }
    esp_err_t r = http_post(url, key, body, resp, sizeof(resp), &status);

    if (r != ESP_OK || status != 200) {
        chat_append("⚠ ", "HTTP err");
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, "err"); lvgl_unlock(); }
        free(prompt); g_busy = false; vTaskDelete(NULL);
    }

    char reply[CHAT_LINE * 2];
    if (!json_get_str_after(resp, "\"role\":\"assistant\"", "content", reply, sizeof(reply)))
        json_get_str(resp, "content", reply, sizeof(reply));

    chat_append("🤖 ", reply);
    if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_WIFI_CONNECTED)); lvgl_unlock(); }
    free(prompt);
    g_busy = false;
    vTaskDelete(NULL);
}

static void send_cb(lv_event_t *e)
{
    (void)e;
    if (g_busy) return;
    const char *txt = lv_textarea_get_text(g_ta);
    if (!txt || txt[0] == '\0') return;

    char *prompt = malloc(CHAT_LINE);
    if (!prompt) return;
    strncpy(prompt, txt, CHAT_LINE - 1);
    prompt[CHAT_LINE - 1] = '\0';

    chat_append("🗨 ", prompt);
    lv_textarea_set_text(g_ta, "");
    if (g_kb) lv_obj_add_flag(g_kb, LV_OBJ_FLAG_HIDDEN);

    g_busy = true;
    xTaskCreate(chat_worker, "chat", 8 * 1024, prompt, 3, NULL);
}

static void ta_focus_cb(lv_event_t *e)
{
    (void)e;
    if (g_kb) lv_obj_clear_flag(g_kb, LV_OBJ_FLAG_HIDDEN);
}

void page_chat_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, ui_str(UI_STR_CHAT));

    g_msg_cont = lv_obj_create(root);
    lv_obj_set_size(g_msg_cont, 330, 180);
    lv_obj_align(g_msg_cont, LV_ALIGN_TOP_MID, 0, 70);
    lv_obj_set_style_bg_opa(g_msg_cont, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(g_msg_cont, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(g_msg_cont, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(g_msg_cont, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);
    lv_obj_set_scroll_dir(g_msg_cont, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(g_msg_cont, LV_SCROLLBAR_MODE_AUTO);

    g_msg_label = lv_label_create(g_msg_cont);
    lv_label_set_long_mode(g_msg_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(g_msg_label, 310);
    lv_label_set_text(g_msg_label, "");

    g_ta = lv_textarea_create(root);
    lv_obj_set_size(g_ta, 240, 34);
    lv_obj_align(g_ta, LV_ALIGN_TOP_MID, -45, 268);
    lv_textarea_set_placeholder_text(g_ta, ui_str(UI_STR_INPUT_HINT));
    lv_obj_add_event_cb(g_ta, ta_focus_cb, LV_EVENT_FOCUSED, NULL);
    lv_obj_set_style_text_font(g_ta, ui_font(14), 0);

    lv_obj_t *send = lv_btn_create(root);
    lv_obj_set_size(send, 80, 34);
    lv_obj_align(send, LV_ALIGN_TOP_MID, 135, 268);
    lv_obj_t *sl = lv_label_create(send);
    lv_label_set_text(sl, ui_str(UI_STR_SEND));
    lv_obj_center(sl);
    lv_obj_add_event_cb(send, send_cb, LV_EVENT_CLICKED, NULL);

    g_kb = lv_keyboard_create(root);
    lv_obj_add_flag(g_kb, LV_OBJ_FLAG_HIDDEN);
    lv_keyboard_set_textarea(g_kb, g_ta);

    g_status = ui_label_create(root, "", ui_font(12), lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(g_status, LV_ALIGN_BOTTOM_MID, 0, -12);

    g_transcript[0] = '\0';
}
