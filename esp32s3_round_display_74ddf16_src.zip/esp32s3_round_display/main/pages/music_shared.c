#include "music_shared.h"

const char *SAMPLE_LYRICS[] = {
    "Silent night, holy night",
    "All is calm, all is bright",
    "Round yon virgin mother and child",
    "Holy infant so tender and mild",
    "Sleep in heavenly peace",
    "Shepherds quake at the view",
    "Glories stream from heaven afar",
    "Heavenly hosts sing Alleluia",
    "Christ the Savior is born",
};
const int SAMPLE_COUNT = sizeof(SAMPLE_LYRICS) / sizeof(SAMPLE_LYRICS[0]);
