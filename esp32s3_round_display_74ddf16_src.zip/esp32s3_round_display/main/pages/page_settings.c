#include "page_settings.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "display.h"
#include "nvs_config.h"
#include "wifi_prov.h"
#include "lvgl_helper.h"
#include "file_server.h"
#include "sd_card.h"
#include "qr_ui.h"
#include "fw_version.h"   /* 构建时生成, 含 FW_VERSION_STR */

#include <stdio.h>
#include <time.h>

#define BRIGHTNESS_DEFAULT  50   /* 默认亮度 50% */

static lv_obj_t *g_bl_label = NULL;   /* 亮度百分比文本, 步进时刷新 */
static const char *g_fs_msg = NULL;   /* 文件服务器开启失败时的提示(红色) */
static lv_obj_t *g_qr_overlay = NULL; /* 二维码浮层 */

/* 套用并记忆亮度 (0..100, 步进 10) */
static void bl_apply(int v)
{
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    nvs_config_set_int(NVS_BRIGHTNESS, v);
    board_backlight_set(v);
    if (g_bl_label) {
        char b[16];
        snprintf(b, sizeof(b), "%d%%", v);
        lv_label_set_text(g_bl_label, b);
    }
}

static void bl_dec_cb(lv_event_t *e)
{
    (void)e;
    bl_apply(nvs_config_get_int(NVS_BRIGHTNESS, BRIGHTNESS_DEFAULT) - 10);
}

static void bl_inc_cb(lv_event_t *e)
{
    (void)e;
    bl_apply(nvs_config_get_int(NVS_BRIGHTNESS, BRIGHTNESS_DEFAULT) + 10);
}

static void lang_toggle_cb(lv_event_t *e)
{
    (void)e;
    ui_lang_set(ui_lang_get() == UI_LANG_ZH ? UI_LANG_EN : UI_LANG_ZH);
    ui_rebuild_settings();   /* 延迟重建以刷新语言(避免在事件回调里删自身控件) */
}

/* 文件服务器开关: 切换 NVS 标志并启停 HTTP 文件服务, 然后安全重建本页。
 * 若开启失败(如未插 SD 卡), 不翻转状态并给出红色提示。 */
static void fs_toggle_cb(lv_event_t *e)
{
    (void)e;
    bool cur = (nvs_config_get_int(NVS_FILE_SERVER, 0) == 1);
    if (!cur) {
        file_server_set_enabled(true);
        if (file_server_is_enabled()) {
            nvs_config_set_int(NVS_FILE_SERVER, 1);
            g_fs_msg = NULL;
        } else {
            nvs_config_set_int(NVS_FILE_SERVER, 0);   /* 启动失败, 保持关闭 */
            /* 给出具体原因(未插卡 / 接触不良 / 文件系统不支持),
             * 而不是笼统的"未找到 SD 卡" —— 否则无法判断该换卡还是该重新格式化 */
            const char *why = sd_card_last_error();
            g_fs_msg = (why && why[0]) ? why : ui_str(UI_STR_FS_NO_SD);
        }
    } else {
        file_server_set_enabled(false);
        nvs_config_set_int(NVS_FILE_SERVER, 0);
        g_fs_msg = NULL;
    }
    ui_rebuild_settings();
}

static void wifi_status_text(char *buf, size_t n)
{
    switch (app_wifi_state()) {
    case WIFI_STATE_CONNECTED:
        snprintf(buf, n, "%s %s", ui_str(UI_STR_WIFI_CONNECTED), app_wifi_ip_str());
        break;
    case WIFI_STATE_PROVISIONING:
        snprintf(buf, n, "%s: %s", ui_str(UI_STR_WIFI_PROVISIONING), app_wifi_prov_ssid());
        break;
    case WIFI_STATE_CONNECTING:
        snprintf(buf, n, "...");
        break;
    default:
        snprintf(buf, n, ui_str(UI_STR_WIFI_NOT_CONNECTED));
    }
}

/* ---------------- 时间手工设定 ---------------- */
typedef struct {
    int  id;          /* 0=年 1=月 2=日 3=时 4=分 */
    int  lo, hi, def;
    lv_obj_t *val;    /* 该分量的值标签(步进时刷新) */
} time_steer_t;

static time_steer_t g_steer[5];
static lv_obj_t    *g_time_hdr = NULL;   /* 折叠头部的时间文本 */
static lv_obj_t    *g_time_ind = NULL;   /* 折叠指示(展开/收起) */
static lv_obj_t    *g_time_panel = NULL; /* 步进面板(可折叠) */

static int days_in_month(int m, int y)
{
    static const int d[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) return 29;
    if (m < 1 || m > 12) return 30;
    return d[m - 1];
}

/* 读回当前 5 个分量(以 NVS 为准), 套用某分量新值并写系统时钟 + NVS。 */
static void time_apply(int id, int newval)
{
    int yr  = nvs_config_get_int(NVS_TIME_YEAR, 2026);
    int mon = nvs_config_get_int(NVS_TIME_MON, 10);
    int day = nvs_config_get_int(NVS_TIME_DAY, 1);
    int hr  = nvs_config_get_int(NVS_TIME_HOUR, 12);
    int mi  = nvs_config_get_int(NVS_TIME_MIN, 0);

    switch (id) {
    case 0: yr  = newval; break;
    case 1: mon = newval; break;
    case 2: day = newval; break;
    case 3: hr  = newval; break;
    case 4: mi  = newval; break;
    }
    /* 日期随月/年合法化 */
    int dim = days_in_month(mon, yr);
    if (day > dim) day = dim;
    if (day < 1)   day = 1;

    app_set_manual_time(yr, mon, day, hr, mi);

    char b[16];
    if (g_steer[0].val) { snprintf(b, sizeof(b), "%d", yr);  lv_label_set_text(g_steer[0].val, b); }
    if (g_steer[1].val) { snprintf(b, sizeof(b), "%d", mon); lv_label_set_text(g_steer[1].val, b); }
    if (g_steer[2].val) { snprintf(b, sizeof(b), "%d", day); lv_label_set_text(g_steer[2].val, b); }
    if (g_steer[3].val) { snprintf(b, sizeof(b), "%d", hr);  lv_label_set_text(g_steer[3].val, b); }
    if (g_steer[4].val) { snprintf(b, sizeof(b), "%d", mi);  lv_label_set_text(g_steer[4].val, b); }
    if (g_time_hdr) {
        snprintf(b, sizeof(b), "%04d-%02d-%02d %02d:%02d", yr, mon, day, hr, mi);
        lv_label_set_text(g_time_hdr, b);
    }
}

static void time_dec_cb(lv_event_t *e)
{
    time_steer_t *st = (time_steer_t *)lv_event_get_user_data(e);
    int cur = nvs_config_get_int(st->id == 0 ? NVS_TIME_YEAR :
                                 st->id == 1 ? NVS_TIME_MON  :
                                 st->id == 2 ? NVS_TIME_DAY  :
                                 st->id == 3 ? NVS_TIME_HOUR : NVS_TIME_MIN, st->def);
    cur -= 1;
    if (cur < st->lo) cur = st->lo;
    if (cur > st->hi) cur = st->hi;
    time_apply(st->id, cur);
}

static void time_inc_cb(lv_event_t *e)
{
    time_steer_t *st = (time_steer_t *)lv_event_get_user_data(e);
    int cur = nvs_config_get_int(st->id == 0 ? NVS_TIME_YEAR :
                                 st->id == 1 ? NVS_TIME_MON  :
                                 st->id == 2 ? NVS_TIME_DAY  :
                                 st->id == 3 ? NVS_TIME_HOUR : NVS_TIME_MIN, st->def);
    cur += 1;
    if (cur < st->lo) cur = st->lo;
    if (cur > st->hi) cur = st->hi;
    time_apply(st->id, cur);
}

/* 单个分量步进器: [标签] [-] 值 [+] */
static void time_stepper(lv_obj_t *parent, const char *label, int id, int lo, int hi, int def)
{
    time_steer_t *st = &g_steer[id];
    st->id = id; st->lo = lo; st->hi = hi; st->def = def;

    lv_obj_t *row = lv_obj_create(parent);
    lv_obj_set_size(row, 150, 36);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(row, 4, 0);

    ui_label_create(row, label, ui_font(13), lv_color_make(0xCB, 0xD2, 0xDE));

    lv_obj_t *minus = lv_btn_create(row);
    lv_obj_set_size(minus, 24, 24);
    lv_obj_t *ml = ui_label_create(minus, "-", ui_font(16), lv_color_white());
    lv_obj_center(ml);
    lv_obj_add_event_cb(minus, time_dec_cb, LV_EVENT_CLICKED, st);

    char buf[12];
    snprintf(buf, sizeof(buf), "%d", nvs_config_get_int(
                 id == 0 ? NVS_TIME_YEAR : id == 1 ? NVS_TIME_MON :
                 id == 2 ? NVS_TIME_DAY  : id == 3 ? NVS_TIME_HOUR : NVS_TIME_MIN, def));
    st->val = ui_label_create(row, buf, ui_font(14), lv_color_make(0x7C, 0xB3, 0xFF));

    lv_obj_t *plus = lv_btn_create(row);
    lv_obj_set_size(plus, 24, 24);
    lv_obj_t *pl = ui_label_create(plus, "+", ui_font(16), lv_color_white());
    lv_obj_center(pl);
    lv_obj_add_event_cb(plus, time_inc_cb, LV_EVENT_CLICKED, st);
}

/* 折叠头部点击: 展开/收起步进面板 */
static void time_toggle_cb(lv_event_t *e)
{
    (void)e;
    if (!g_time_panel) return;
    if (lv_obj_has_flag(g_time_panel, LV_OBJ_FLAG_HIDDEN)) {
        lv_obj_clear_flag(g_time_panel, LV_OBJ_FLAG_HIDDEN);
        if (g_time_ind) lv_label_set_text(g_time_ind, "收起");
    } else {
        lv_obj_add_flag(g_time_panel, LV_OBJ_FLAG_HIDDEN);
        if (g_time_ind) lv_label_set_text(g_time_ind, "展开");
    }
}

/* 一行: 名称(左) + 值(右, 蓝) */
static void info_row(lv_obj_t *parent, const char *name, const char *val)
{
    lv_obj_t *row = lv_obj_create(parent);
    lv_obj_set_size(row, 320, 40);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    ui_label_create(row, name, ui_font(14), lv_color_white());
    ui_label_create(row, val, ui_font(13), lv_color_make(0x7C, 0xB3, 0xFF));
}

/* 关闭二维码浮层 */
static void fs_qr_close_cb(lv_event_t *e)
{
    (void)e;
    lvgl_set_gesture_blocked(false);   /* 恢复导航手势 */
    if (g_qr_overlay) {
        lv_obj_del(g_qr_overlay);
        g_qr_overlay = NULL;
    }
}

/* 弹出全屏二维码浮层: 编码 WiFi 连接串(扫码即连 AP),
 * 配合 captive portal, 手机连上后会自动跳转文件服务器页面。 */
static void fs_qr_open(lv_event_t *e)
{
    (void)e;
    if (!lvgl_lock(-1)) return;
    if (g_qr_overlay) { lvgl_unlock(); return; }   /* 已打开则忽略 */

    lv_obj_t *scr = lv_scr_act();
    lv_obj_t *ov = lv_obj_create(scr);
    lv_obj_set_size(ov, BOARD_LCD_H_RES, BOARD_LCD_V_RES);
    lv_obj_center(ov);
    lv_obj_set_style_bg_color(ov, lv_color_make(0x0B, 0x0E, 0x14), 0);
    lv_obj_set_style_bg_opa(ov, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(ov, BOARD_SCREEN_RADIUS, 0);
    lv_obj_set_style_clip_corner(ov, true, 0);
    lv_obj_clear_flag(ov, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(ov, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(ov, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_all(ov, 12, 0);
    lv_obj_set_style_pad_row(ov, 8, 0);
    g_qr_overlay = ov;

    ui_label_create(ov, ui_str(UI_STR_FS_QR), ui_font(18), lv_color_white());

    /* 二维码: WIFI:S:<ssid>;T:nopass;H:false;; (扫码即连开放 AP) */
    lv_obj_t *canvas = lv_canvas_create(ov);
    lv_obj_set_size(canvas, 200, 200);
    const char *ssid = app_wifi_ap_ssid();
    char qrtext[96];
    snprintf(qrtext, sizeof(qrtext), "WIFI:S:%s;T:nopass;H:false;;",
             (ssid && ssid[0]) ? ssid : "ROUND_DISP_FS");
    if (!qr_draw_text(canvas, 200, qrtext)) {
        ui_label_create(ov, "QR 生成失败", ui_font(13), lv_color_make(0xE0, 0x70, 0x70));
    }

    ui_label_create(ov, ui_str(UI_STR_FS_SCAN_HINT), ui_font(12),
                    lv_color_make(0x90, 0x96, 0xA2));

    char apinfo[64];
    snprintf(apinfo, sizeof(apinfo), "WiFi: %s",
             (ssid && ssid[0]) ? ssid : "ROUND_DISP_FS");
    ui_label_create(ov, apinfo, ui_font(13), lv_color_make(0x7C, 0xB3, 0xFF));

    ui_label_create(ov, ui_str(UI_STR_FS_URL_HINT), ui_font(12),
                    lv_color_make(0x90, 0x96, 0xA2));
    ui_label_create(ov, "http://192.168.4.1:8080/", ui_font(13),
                    lv_color_make(0x7C, 0xB3, 0xFF));

    ui_label_create(ov, ui_str(UI_STR_FS_TAP_CLOSE), ui_font(11),
                    lv_color_make(0x6A, 0x70, 0x7C));

    lv_obj_add_flag(ov, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(ov, fs_qr_close_cb, LV_EVENT_CLICKED, NULL);
    lvgl_set_gesture_blocked(true);   /* 浮层期间屏蔽滑动导航 */

    lvgl_unlock();
}

void page_settings_create(void)
{
    g_qr_overlay = NULL;   /* 重建页面时旧浮层已被 lv_obj_clean 删除, 避免悬空指针 */
    g_time_hdr = NULL;
    g_time_ind = NULL;
    g_time_panel = NULL;
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, ui_str(UI_STR_SETTINGS));

    lv_obj_t *list = lv_obj_create(root);
    lv_obj_set_size(list, 340, 300);
    lv_obj_align(list, LV_ALIGN_TOP_MID, 0, 50);
    lv_obj_add_flag(list, LV_OBJ_FLAG_SCROLLABLE);   /* 内容超出时允许滚动 */
    lv_obj_set_style_bg_opa(list, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(list, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(list, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(list, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);
    lv_obj_set_style_pad_row(list, 8, 0);

    /* 语言切换 */
    lv_obj_t *lrow = lv_obj_create(list);
    lv_obj_set_size(lrow, 320, 44);
    lv_obj_set_style_bg_opa(lrow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(lrow, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(lrow, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(lrow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    ui_label_create(lrow, ui_str(UI_STR_LANGUAGE), ui_font(16), lv_color_white());
    lv_obj_t *sw = ui_label_create(lrow, ui_str(UI_STR_LANG_SWITCH), ui_font(15),
                                   lv_color_make(0x7C, 0xB3, 0xFF));
    lv_obj_add_flag(sw, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_bg_opa(sw, LV_OPA_20, 0);
    lv_obj_set_style_pad_hor(sw, 10, 0);
    lv_obj_add_event_cb(sw, lang_toggle_cb, LV_EVENT_CLICKED, NULL);

    /* 亮度调节 (−/+ 步进, 改动即套用并记忆到 NVS) */
    lv_obj_t *brow = lv_obj_create(list);
    lv_obj_set_size(brow, 320, 44);
    lv_obj_set_style_bg_opa(brow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(brow, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(brow, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(brow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    ui_label_create(brow, ui_str(UI_STR_BRIGHTNESS), ui_font(16), lv_color_white());

    lv_obj_t *ctr = lv_obj_create(brow);
    lv_obj_set_size(ctr, 150, 40);
    lv_obj_set_style_bg_opa(ctr, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(ctr, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(ctr, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(ctr, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(ctr, 6, 0);

    lv_obj_t *minus = lv_btn_create(ctr);
    lv_obj_set_size(minus, 36, 32);
    lv_obj_t *ml = ui_label_create(minus, "-", ui_font(20), lv_color_white());
    lv_obj_center(ml);
    lv_obj_add_event_cb(minus, bl_dec_cb, LV_EVENT_CLICKED, NULL);

    char btxt[16];
    snprintf(btxt, sizeof(btxt), "%d%%", nvs_config_get_int(NVS_BRIGHTNESS, BRIGHTNESS_DEFAULT));
    g_bl_label = ui_label_create(ctr, btxt, ui_font(15), lv_color_make(0x7C, 0xB3, 0xFF));

    lv_obj_t *plus = lv_btn_create(ctr);
    lv_obj_set_size(plus, 36, 32);
    lv_obj_t *pl = ui_label_create(plus, "+", ui_font(20), lv_color_white());
    lv_obj_center(pl);
    lv_obj_add_event_cb(plus, bl_inc_cb, LV_EVENT_CLICKED, NULL);

    /* 登记亮度控件: 从其上起始的滑动不触发导航, 避免调亮度时误触返回主页 */
    lvgl_set_brightness_obj(ctr);

    /* 文件服务器开关 (默认关闭) */
    bool fs_on = nvs_config_get_int(NVS_FILE_SERVER, 0) == 1;
    lv_obj_t *frow = lv_obj_create(list);
    lv_obj_set_size(frow, 320, 44);
    lv_obj_set_style_bg_opa(frow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(frow, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(frow, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(frow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    ui_label_create(frow, ui_str(UI_STR_FS_TITLE), ui_font(16), lv_color_white());
    lv_obj_t *fsw = ui_label_create(frow, fs_on ? ui_str(UI_STR_FS_ON) : ui_str(UI_STR_FS_OFF),
                                    ui_font(15), lv_color_make(0x7C, 0xB3, 0xFF));
    lv_obj_add_flag(fsw, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_bg_opa(fsw, LV_OPA_20, 0);
    lv_obj_set_style_pad_hor(fsw, 10, 0);
    lv_obj_add_event_cb(fsw, fs_toggle_cb, LV_EVENT_CLICKED, NULL);

    /* 开启失败的红色提示(如未插 SD 卡) */
    if (g_fs_msg) {
        ui_label_create(list, g_fs_msg, ui_font(12), lv_color_make(0xE0, 0x70, 0x70));
    }

    if (fs_on) {
        /* 二维码按钮: 点击弹出扫码连 WiFi 的浮层 */
        lv_obj_t *qrow = lv_obj_create(list);
        lv_obj_set_size(qrow, 320, 44);
        lv_obj_set_style_bg_opa(qrow, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_opa(qrow, LV_OPA_TRANSP, 0);
        lv_obj_set_flex_flow(qrow, LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(qrow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        ui_label_create(qrow, ui_str(UI_STR_FS_QR), ui_font(16), lv_color_white());
        lv_obj_t *qbtn = ui_label_create(qrow, ui_str(UI_STR_FS_QR_BTN), ui_font(15),
                                         lv_color_make(0x7C, 0xB3, 0xFF));
        lv_obj_add_flag(qbtn, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_set_style_bg_opa(qbtn, LV_OPA_20, 0);
        lv_obj_set_style_pad_hor(qbtn, 10, 0);
        lv_obj_add_event_cb(qbtn, fs_qr_open, LV_EVENT_CLICKED, NULL);

        if (file_server_sd_missing()) {
            const char *why = sd_card_last_error();
            ui_label_create(list, (why && why[0]) ? why : ui_str(UI_STR_FS_NO_SD),
                            ui_font(12), lv_color_make(0xE0, 0x70, 0x70));
        } else {
            info_row(list, ui_str(UI_STR_FS_AP),   app_wifi_ap_ssid());
            info_row(list, ui_str(UI_STR_FS_ADDR), "192.168.4.1:8080");
        }
    }

    /* ---------------- 时间手工设定(可折叠) ---------------- */
    /* 折叠头部: 标题 + 当前时间 + 点击展开 */
    lv_obj_t *trow = lv_obj_create(list);
    lv_obj_set_size(trow, 320, 44);
    lv_obj_set_style_bg_opa(trow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(trow, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(trow, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(trow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    ui_label_create(trow, ui_str(UI_STR_TIME_TITLE), ui_font(16), lv_color_white());

    /* 当前时间文本(来自系统时钟, 与时钟页一致) */
    char tbuf[24];
    time_t tnow = time(NULL);
    struct tm *tt = localtime(&tnow);
    if (tt) snprintf(tbuf, sizeof(tbuf), "%04d-%02d-%02d %02d:%02d",
                     tt->tm_year + 1900, tt->tm_mon + 1, tt->tm_mday, tt->tm_hour, tt->tm_min);
    else    snprintf(tbuf, sizeof(tbuf), "2026-10-01 12:00");
    g_time_hdr = ui_label_create(trow, tbuf, ui_font(13), lv_color_make(0x7C, 0xB3, 0xFF));
    g_time_ind = ui_label_create(trow, "展开", ui_font(13), lv_color_make(0x90, 0x96, 0xA2));
    lv_obj_add_flag(trow, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_bg_opa(trow, LV_OPA_10, 0);
    lv_obj_add_event_cb(trow, time_toggle_cb, LV_EVENT_CLICKED, NULL);

    /* 步进面板(初始隐藏): 年/月/日/时/分 各一个步进器 */
    g_time_panel = lv_obj_create(list);
    lv_obj_set_size(g_time_panel, 320, 130);
    lv_obj_set_style_bg_opa(g_time_panel, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(g_time_panel, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(g_time_panel, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_flex_align(g_time_panel, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(g_time_panel, 6, 0);
    lv_obj_set_style_pad_column(g_time_panel, 8, 0);
    lv_obj_add_flag(g_time_panel, LV_OBJ_FLAG_HIDDEN);

    time_stepper(g_time_panel, "年", 0, 2000, 2099, 2026);
    time_stepper(g_time_panel, "月", 1, 1, 12, 10);
    time_stepper(g_time_panel, "日", 2, 1, 31, 1);
    time_stepper(g_time_panel, "时", 3, 0, 23, 12);
    time_stepper(g_time_panel, "分", 4, 0, 59, 0);

    ui_label_create(g_time_panel, ui_str(UI_STR_TIME_HINT), ui_font(11),
                    lv_color_make(0x70, 0x76, 0x82));

    /* WiFi 状态(只读) */
    char wst[48];
    wifi_status_text(wst, sizeof(wst));
    info_row(list, ui_str(UI_STR_WIFI), wst);

    if (app_wifi_state() == WIFI_STATE_PROVISIONING) {
        ui_label_create(list, ui_str(UI_STR_PROV_HINT), ui_font(12), lv_color_make(0x90, 0x96, 0xA2));
        ui_label_create(list, ui_str(UI_STR_PROV_ADDR), ui_font(12), lv_color_make(0x90, 0x96, 0xA2));
    }

    /* 固件版本(只读) */
    info_row(list, ui_str(UI_STR_FIRMWARE), FW_VERSION_STR);
}
