#include "page_clock.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "lvgl_helper.h"
#include "chrono_cn.h"

#include <time.h>
#include <stdio.h>
#include <stdint.h>

/* 阳历 24 时计时 + 四柱干支 */
static lv_obj_t *g_time = NULL;   /* 阳历 24 时计时 */
static lv_obj_t *g_date = NULL;   /* 年-月-日 周X */
static lv_obj_t *g_y = NULL, *g_m = NULL, *g_d = NULL, *g_h = NULL;  /* 四柱 + 时辰 */

static bool g_timer_created = false;

static const char *WD[] = {"日", "一", "二", "三", "四", "五", "六"};

/* 时钟主页长按 -> 进入小六壬占卜界面 */
static void clock_long_press_cb(lv_event_t *e)
{
    (void)e;
    lvgl_consume_release_gesture();   /* 吞掉松手手势, 避免长按导航后松手被误判为滑动返回主页 */
    ui_show_page(UI_PAGE_LIUREN);
}

static void clock_refresh(void)
{
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    if (!tm) return;

    char buf[48];

    /* 阳历 24 时计时 */
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);
    lv_label_set_text(g_time, buf);
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d 周%s",
             tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, WD[tm->tm_wday]);
    lv_label_set_text(g_date, buf);

    /* 天干地支四柱计时 */
    char yg[8], mg[8], dg[8], hg[8], sc[8];
    ganzhi_from_tm(tm, yg, mg, dg, hg, sc);
    snprintf(buf, sizeof(buf), "年 %s", yg); lv_label_set_text(g_y, buf);
    snprintf(buf, sizeof(buf), "月 %s", mg); lv_label_set_text(g_m, buf);
    snprintf(buf, sizeof(buf), "日 %s", dg); lv_label_set_text(g_d, buf);
    snprintf(buf, sizeof(buf), "时 %s%s", hg, sc); lv_label_set_text(g_h, buf);
}

static void clock_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_CLOCK) return;   /* 不在本页则跳过 */
    clock_refresh();
}

void page_clock_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    lv_obj_add_flag(root, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(root, clock_long_press_cb, LV_EVENT_LONG_PRESSED, NULL);

    /* 深色系背景: 深色面板铺满圆形裁切区 */
    lv_obj_set_style_bg_color(root, lv_color_make(0x0E, 0x12, 0x1A), 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    /* 主页不再显示"时钟"标题, 让时分秒成为绝对主角 */

    lv_obj_t *col = lv_obj_create(root);
    lv_obj_set_size(col, 320, 320);
    lv_obj_set_style_bg_opa(col, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(col, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(col, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(col, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(col, 4, 0);

    /* 阳历 24 时计时 (字号放大一倍, 作为主页视觉主体) */
    ui_label_create(col, ui_str(UI_STR_SOLAR), ui_font(14), lv_color_make(0x7C, 0x88, 0x9C));
    g_time = ui_label_create(col, "00:00:00", ui_font(64), lv_color_make(0xDE, 0xF2, 0xF7));
    g_date = ui_label_create(col, "2026-01-01 周一", ui_font(15), lv_color_make(0x8A, 0x93, 0xA6));

    /* 天干地支四柱 (干支标题用琥珀色高亮, 与深色背景形成对比) */
    ui_label_create(col, ui_str(UI_STR_GANZHI), ui_font(14), lv_color_make(0xE0, 0xA0, 0x40));
    g_y = ui_label_create(col, "年 甲子", ui_font(16), lv_color_make(0xCB, 0xD2, 0xDE));
    g_m = ui_label_create(col, "月 甲子", ui_font(16), lv_color_make(0xCB, 0xD2, 0xDE));
    g_d = ui_label_create(col, "日 甲子", ui_font(16), lv_color_make(0xCB, 0xD2, 0xDE));
    g_h = ui_label_create(col, "时 甲子子时", ui_font(16), lv_color_make(0xCB, 0xD2, 0xDE));

    /* 底部提示: 长按进入占卜; 右滑切换应用
     * (原来 0x5A6270 在深色底上对比度仅约 2.3:1 几乎看不见, 提亮到与日期一致的灰度) */
    ui_label_create(root, ui_str(UI_STR_HOLD_DIVINE), ui_font(12), lv_color_make(0x8A, 0x93, 0xA6));

    clock_refresh();
    if (!g_timer_created) {
        lv_timer_create(clock_timer_cb, 1000, NULL);
        g_timer_created = true;
    }
}
