#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_images_create(void);

/** 切换上一张/下一张图片(dir=-1 上一张, +1 下一张), 循环。 */
void images_turn(int dir);
#ifdef __cplusplus
}
#endif
