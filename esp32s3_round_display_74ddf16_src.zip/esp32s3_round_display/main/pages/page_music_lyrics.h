#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_music_lyrics_create(void);
#ifdef __cplusplus
}
#endif
