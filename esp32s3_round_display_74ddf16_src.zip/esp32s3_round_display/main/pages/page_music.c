#include "page_music.h"
#include "ui_manager.h"
#include "board_config.h"
#include "music_shared.h"

static lv_obj_t *g_l1 = NULL;
static lv_obj_t *g_l2 = NULL;
static lv_obj_t *g_bar = NULL;
static lv_obj_t *g_tcur = NULL;
static lv_obj_t *g_play_btn = NULL;
static bool g_playing = false;
static int g_idx = 0;
static int g_sec = 0;
static const int g_dur = 258;

static void update_music_ui(void)
{
    lv_label_set_text(g_l1, SAMPLE_LYRICS[g_idx]);
    lv_label_set_text(g_l2, (g_idx + 1 < SAMPLE_COUNT) ? SAMPLE_LYRICS[g_idx + 1] : "");
    lv_label_set_text(g_play_btn, g_playing ? LV_SYMBOL_PAUSE : LV_SYMBOL_PLAY);

    int prog = g_dur ? (g_sec * 100 / g_dur) : 0;
    lv_bar_set_value(g_bar, prog, LV_ANIM_OFF);

    char buf[8];
    snprintf(buf, sizeof(buf), "%02d:%02d", g_sec / 60, g_sec % 60);
    lv_label_set_text(g_tcur, buf);
}

static void ctrl_cb(lv_event_t *e)
{
    const char *act = (const char *)lv_event_get_user_data(e);
    if (act[0] == 'p') {            /* prev */
        if (g_idx > 0) g_idx--;
    } else if (act[0] == 'n') {     /* next */
        if (g_idx + 1 < SAMPLE_COUNT) g_idx++;
    } else if (act[0] == 'P') {     /* play/pause */
        g_playing = !g_playing;
    }
    update_music_ui();
}

static void open_lyrics_cb(lv_event_t *e)
{
    (void)e;
    ui_show_page(UI_PAGE_MUSIC_LYRICS);
}

static void music_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_MUSIC) return;   /* 不在本页跳过 */
    if (g_playing) {
        g_sec = (g_sec + 1) % (g_dur + 1);
        update_music_ui();
    }
}

void page_music_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    lv_obj_set_style_bg_color(root, lv_color_make(0x1B, 0x1F, 0x27), 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    /* 封面 */
    lv_obj_t *cover = lv_obj_create(root);
    lv_obj_set_size(cover, 84, 84);
    lv_obj_align(cover, LV_ALIGN_TOP_MID, 0, 38);
    lv_obj_set_style_radius(cover, 42, 0);
    lv_obj_set_style_bg_color(cover, lv_color_make(0x4A, 0x3A, 0x8A), 0);
    lv_obj_t *cov_lab = lv_label_create(cover);
    lv_label_set_text(cov_lab, "M");
    lv_obj_set_style_text_font(cov_lab, ui_font(32), 0);
    lv_obj_center(cov_lab);

    lv_obj_t *title = ui_label_create(root, "Demo Song", ui_font(20), lv_color_white());
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 138);

    lv_obj_t *artist = ui_label_create(root, "Unknown Artist", ui_font(13), lv_color_make(0x90, 0x96, 0xA2));
    lv_obj_align(artist, LV_ALIGN_TOP_MID, 0, 162);

    g_l1 = ui_label_create(root, SAMPLE_LYRICS[0], ui_font(16), lv_color_make(0xB7, 0x9B, 0xFF));
    lv_obj_align(g_l1, LV_ALIGN_TOP_MID, 0, 195);
    g_l2 = ui_label_create(root, SAMPLE_LYRICS[1], ui_font(16), lv_color_make(0x70, 0x76, 0x86));
    lv_obj_align(g_l2, LV_ALIGN_TOP_MID, 0, 219);

    g_bar = lv_bar_create(root);
    lv_obj_set_size(g_bar, 200, 6);
    lv_obj_align(g_bar, LV_ALIGN_TOP_MID, 0, 256);
    lv_bar_set_range(g_bar, 0, 100);
    lv_bar_set_value(g_bar, 0, LV_ANIM_OFF);

    g_tcur = ui_label_create(root, "00:00", ui_font(12), lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(g_tcur, LV_ALIGN_TOP_MID, -90, 270);

    /* 控制按钮行 */
    lv_obj_t *row = lv_obj_create(root);
    lv_obj_set_size(row, 220, 44);
    lv_obj_align(row, LV_ALIGN_TOP_MID, 0, 305);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

    static lv_obj_t *b_prev, *b_play, *b_next;
    b_prev = lv_btn_create(row);  lv_obj_set_size(b_prev, 44, 44);
    b_play = lv_btn_create(row);  lv_obj_set_size(b_play, 52, 44);
    b_next = lv_btn_create(row);  lv_obj_set_size(b_next, 44, 44);
    lv_obj_t *l_prev = lv_label_create(b_prev); lv_label_set_text(l_prev, LV_SYMBOL_PREV); lv_obj_center(l_prev);
    g_play_btn = lv_label_create(b_play); lv_label_set_text(g_play_btn, LV_SYMBOL_PLAY); lv_obj_center(g_play_btn);
    lv_obj_t *l_next = lv_label_create(b_next); lv_label_set_text(l_next, LV_SYMBOL_NEXT); lv_obj_center(l_next);
    lv_obj_add_event_cb(b_prev, ctrl_cb, LV_EVENT_CLICKED, (void *)"prev");
    lv_obj_add_event_cb(b_play, ctrl_cb, LV_EVENT_CLICKED, (void *)"Play");
    lv_obj_add_event_cb(b_next, ctrl_cb, LV_EVENT_CLICKED, (void *)"next");

    lv_obj_t *lyrics_btn = ui_label_create(root, "Lyrics >", ui_font(13), lv_color_make(0xB7, 0x9B, 0xFF));
    lv_obj_align(lyrics_btn, LV_ALIGN_TOP_MID, 0, 348);
    lv_obj_add_flag(lyrics_btn, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(lyrics_btn, open_lyrics_cb, LV_EVENT_CLICKED, NULL);

    update_music_ui();
    lv_timer_create(music_timer_cb, 1000, NULL);
}
