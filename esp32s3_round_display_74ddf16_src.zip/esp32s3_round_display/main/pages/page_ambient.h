#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_ambient_create(void);
#ifdef __cplusplus
}
#endif
