#include "page_aida.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "nvs_config.h"
#include "wifi_prov.h"
#include "lvgl_helper.h"

#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define AIDA_BUF 1024
#define AIDA_MAXLINES 10

static lv_obj_t *g_status = NULL;
static lv_obj_t *g_lines[AIDA_MAXLINES] = {NULL};
static bool      g_busy = false;

static void aida_update(const char *lines[], int n)
{
    if (!lvgl_lock(-1)) return;
    for (int i = 0; i < AIDA_MAXLINES; i++) {
        if (i < n && lines[i] && g_lines[i]) lv_label_set_text(g_lines[i], lines[i]);
        else if (g_lines[i]) lv_label_set_text(g_lines[i], "");
    }
    lvgl_unlock();
}

static void aida_task(void *arg)
{
    (void)arg;
    char ip[40] = "";
    nvs_config_get_str("aida_ip", ip, sizeof(ip));
    int port = nvs_config_get_int("aida_port", 8888);

    if (ip[0] == '\0') {
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, "Settings -> PC Addr"); lvgl_unlock(); }
        g_busy = false; vTaskDelete(NULL);
    }
    if (!app_wifi_is_connected()) {
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_NO_NET)); lvgl_unlock(); }
        g_busy = false; vTaskDelete(NULL);
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, "socket err"); lvgl_unlock(); }
        g_busy = false; vTaskDelete(NULL);
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, ip, &addr.sin_addr) != 1) {
        close(sock);
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, "bad IP"); lvgl_unlock(); }
        g_busy = false; vTaskDelete(NULL);
    }

    struct timeval tv = { .tv_sec = 3, .tv_usec = 0 };
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(sock, SO_SNDTIMEO, SOL_SOCKET, &tv, sizeof(tv));

    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        close(sock);
        if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_PC_DISCONNECTED)); lvgl_unlock(); }
        g_busy = false; vTaskDelete(NULL);
    }

    send(sock, "GET\n", 4, 0);

    char buf[AIDA_BUF];
    int total = 0;
    while (total < (int)sizeof(buf) - 1) {
        int r = recv(sock, buf + total, sizeof(buf) - 1 - total, 0);
        if (r <= 0) break;
        total += r;
    }
    buf[total] = '\0';
    close(sock);

    const char *lines[AIDA_MAXLINES];
    int n = 0;
    char *save = buf;
    char *tok = strtok_r(buf, "\n", &save);
    while (tok && n < AIDA_MAXLINES) {
        size_t L = strlen(tok);
        if (L && tok[L - 1] == '\r') tok[L - 1] = '\0';
        lines[n++] = tok;
        tok = strtok_r(NULL, "\n", &save);
    }

    aida_update(lines, n);
    if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, ui_str(UI_STR_WIFI_CONNECTED)); lvgl_unlock(); }
    g_busy = false;
    vTaskDelete(NULL);
}

static void aida_refresh(void)
{
    if (g_busy) return;
    g_busy = true;
    if (lvgl_lock(-1)) { if (g_status) lv_label_set_text(g_status, "..."); lvgl_unlock(); }
    xTaskCreate(aida_task, "aida", 5 * 1024, NULL, 3, NULL);
}

static void aida_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_AIDA) return;
    aida_refresh();
}

void page_aida_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, ui_str(UI_STR_PC));

    g_status = ui_label_create(root, ui_str(UI_STR_PC_DISCONNECTED), ui_font(13),
                              lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(g_status, LV_ALIGN_TOP_MID, 0, 58);

    for (int i = 0; i < AIDA_MAXLINES; i++) {
        g_lines[i] = ui_label_create(root, "", ui_font(14), lv_color_make(0xD8, 0xE8, 0xF0));
        lv_obj_align(g_lines[i], LV_ALIGN_TOP_MID, 0, 84 + i * 22);
    }

    lv_obj_t *hint = ui_label_create(root, ui_str(UI_STR_TAP_SWITCH), ui_font(12),
                                    lv_color_make(0x80, 0x86, 0x92));
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -14);
    lv_obj_add_event_cb(root, (lv_event_cb_t)aida_refresh, LV_EVENT_CLICKED, NULL);

    aida_refresh();
    lv_timer_create(aida_timer_cb, 3000, NULL);
}
