#pragma once
#ifdef __cplusplus
extern "C" {
#endif

/* M1 demo 歌词样本 (英文占位, 真中文需 CJK 字体). 由 music_shared.c 定义。 */
extern const char *SAMPLE_LYRICS[];
extern const int SAMPLE_COUNT;

#ifdef __cplusplus
}
#endif
