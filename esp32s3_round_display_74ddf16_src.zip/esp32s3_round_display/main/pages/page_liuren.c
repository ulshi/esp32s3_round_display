#include "page_liuren.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "lvgl_helper.h"
#include "chrono_cn.h"
#include "nvs_config.h"
#include "esp_random.h"

#include <time.h>
#include <stdio.h>
#include <stdint.h>

/* 小六壬占卜: 时间 / 随机 / 手工 三种起课模式 */
typedef enum { LR_TIME = 0, LR_RANDOM, LR_MANUAL } lr_mode_t;

/* 深色系配色 */
#define C_DIM    lv_color_make(0x9A, 0xA0, 0xAC)
#define C_TEXT   lv_color_make(0xCB, 0xD2, 0xDE)
#define C_SUB    lv_color_make(0x7C, 0x88, 0x9C)
#define C_BLUE   lv_color_make(0x7C, 0xB3, 0xFF)
#define C_AMBER  lv_color_make(0xE0, 0xC0, 0x60)
#define C_HINT   lv_color_make(0x5A, 0x62, 0x70)
#define C_BG     lv_color_make(0x0E, 0x12, 0x1A)

static lv_obj_t *g_lr_mode   = NULL;   /* 模式标签 (点击切换) */
static lv_obj_t *g_lr_counts = NULL;   /* 月/日/时 三数 (时间/随机模式) */
static lv_obj_t *g_lr_steps  = NULL;   /* 手工模式步进器容器 */
static lv_obj_t *g_lr_steps_lbl[3] = {NULL, NULL, NULL};
static lv_obj_t *g_s1 = NULL, *g_s2 = NULL;   /* 月推/日推 小字 */
static lv_obj_t *g_s3_val = NULL;      /* 时推(最终)结果 大字 */
static lv_obj_t *g_lr_desc  = NULL;    /* 占辞 */

static lr_mode_t g_mode = LR_TIME;
static int  g_manual[3] = {1, 1, 1};   /* 手工三数值: 月/日/时辰 (1..12 / 1..31 / 1..12) */
static bool g_timer_created = false;

static void persist_lr(void)
{
    nvs_config_set_int(NVS_LR_MODE, (int)g_mode);
    nvs_config_set_int(NVS_LR_M, g_manual[0]);
    nvs_config_set_int(NVS_LR_D, g_manual[1]);
    nvs_config_set_int(NVS_LR_S, g_manual[2]);
}

static void liuren_refresh(void)
{
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    if (!tm) return;

    /* 月/日/时辰三数 (时间模式=当前; 随机/手工=保存值) */
    char _yg[8], _mg[8], _dg[8], _hg[8], _sc[8];
    int shichen = ganzhi_from_tm(tm, _yg, _mg, _dg, _hg, _sc);
    int m = tm->tm_mon + 1;
    int d = tm->tm_mday;
    int h = shichen + 1;            /* 时辰 1..12 */
    if (g_mode != LR_TIME) { m = g_manual[0]; d = g_manual[1]; h = g_manual[2]; }

    xiaoliuren_result_t r;
    xiaoliuren_cast_full(m, d, h, &r);

    if (g_mode != LR_MANUAL) {
        char buf[48];
        snprintf(buf, sizeof(buf), "月%d  日%d  时%d", m, d, h);
        lv_label_set_text(g_lr_counts, buf);
    }

    /* 三次推导: 月推 / 日推 / 时推(最终) */
    char b1[32], b2[32];
    snprintf(b1, sizeof(b1), "%s  %s", ui_str(UI_STR_LR_M_PUSH), xiaoliuren_name(r.step1));
    snprintf(b2, sizeof(b2), "%s  %s", ui_str(UI_STR_LR_D_PUSH), xiaoliuren_name(r.step2));
    lv_label_set_text(g_s1, b1);
    lv_label_set_text(g_s2, b2);
    lv_label_set_text(g_s3_val, xiaoliuren_name(r.step3));
    lv_label_set_text(g_lr_desc, xiaoliuren_desc(r.step3));
}

/* 切换占卜模式 (dir=+1 正向循环, dir=-1 反向)。点击模式标签或左右滑手势均走这里。 */
static void liuren_do_cycle(int dir)
{
    g_mode = (lr_mode_t)((g_mode + dir + 3) % 3);
    if (g_mode == LR_RANDOM) {
        uint32_t r = esp_random();
        g_manual[0] = (int)(r % 12) + 1;          /* 月 1..12 */
        g_manual[1] = (int)((r >> 8) % 31) + 1;   /* 日 1..31 */
        g_manual[2] = (int)((r >> 16) % 12) + 1;  /* 时辰 1..12 */
    }

    const char *mode_str = (g_mode == LR_TIME)   ? ui_str(UI_STR_LR_TIME)
                         : (g_mode == LR_RANDOM) ? ui_str(UI_STR_LR_RANDOM)
                                                 : ui_str(UI_STR_LR_MANUAL);
    char b[32];
    snprintf(b, sizeof(b), "%s: %s", ui_str(UI_STR_MODE), mode_str);
    lv_label_set_text(g_lr_mode, b);

    bool manual = (g_mode == LR_MANUAL);
    if (manual) {
        lv_obj_add_flag(g_lr_counts, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(g_lr_steps, LV_OBJ_FLAG_HIDDEN);
        for (int i = 0; i < 3; i++) {
            snprintf(b, sizeof(b), "%d", g_manual[i]);
            lv_label_set_text(g_lr_steps_lbl[i], b);
        }
    } else {
        lv_obj_clear_flag(g_lr_counts, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_lr_steps, LV_OBJ_FLAG_HIDDEN);
    }
    persist_lr();
    liuren_refresh();
}

/* 模式标签点击: 正向切换一种模式 */
static void mode_tap_cb(lv_event_t *e)
{
    (void)e;
    liuren_do_cycle(+1);
}

/* 供导航手势调用: 右滑正向、左滑反向切换占卜模式 */
void page_liuren_cycle_mode(int dir)
{
    liuren_do_cycle(dir >= 0 ? +1 : -1);
}

/* 手工模式步进器: idx=0月 1日 2时; dir=-1/+1 */
static void step_adj_cb(lv_event_t *e)
{
    int idx = (int)(intptr_t)lv_event_get_user_data(e);
    int dir = (int)(intptr_t)lv_obj_get_user_data(lv_event_get_target(e));
    int lo = 1, hi = (idx == 1) ? 31 : 12;
    int v = g_manual[idx] + dir;
    if (v < lo) v = hi;
    if (v > hi) v = lo;
    g_manual[idx] = v;
    char b[8];
    snprintf(b, sizeof(b), "%d", v);
    lv_label_set_text(g_lr_steps_lbl[idx], b);
    persist_lr();
    liuren_refresh();
}

/* 占卜页返回主页由"左滑"触发 (见 ui_handle_gesture), 不再使用长按 */

static void liuren_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_LIUREN) return;
    liuren_refresh();
}

void page_liuren_create(void)
{
    /* 进入页面时读回记忆的小六壬模式与手工三数值 */
    g_mode = (lr_mode_t)nvs_config_get_int(NVS_LR_MODE, 0);
    if (g_mode < 0 || g_mode > 2) g_mode = LR_TIME;
    g_manual[0] = nvs_config_get_int(NVS_LR_M, 1);
    g_manual[1] = nvs_config_get_int(NVS_LR_D, 1);
    g_manual[2] = nvs_config_get_int(NVS_LR_S, 1);

    lv_obj_t *root = ui_page_root_create();
    lv_obj_set_style_bg_color(root, C_BG, 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    ui_page_title(root, ui_str(UI_STR_LIUREN));

    lv_obj_t *col = lv_obj_create(root);
    lv_obj_set_size(col, 300, 300);
    lv_obj_set_style_bg_opa(col, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(col, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(col, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(col, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(col, 5, 0);

    /* 模式标签: 点击在 时间/随机/手工 间切换 */
    char mb[32];
    const char *mode_str = (g_mode == LR_TIME)   ? ui_str(UI_STR_LR_TIME)
                         : (g_mode == LR_RANDOM) ? ui_str(UI_STR_LR_RANDOM)
                                                 : ui_str(UI_STR_LR_MANUAL);
    snprintf(mb, sizeof(mb), "%s: %s", ui_str(UI_STR_MODE), mode_str);
    g_lr_mode = ui_label_create(col, mb, ui_font(13), C_BLUE);
    lv_obj_add_flag(g_lr_mode, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_bg_opa(g_lr_mode, LV_OPA_20, 0);
    lv_obj_set_style_pad_hor(g_lr_mode, 8, 0);
    lv_obj_add_event_cb(g_lr_mode, mode_tap_cb, LV_EVENT_CLICKED, NULL);

    /* 起课三数 */
    ui_label_create(col, ui_str(UI_STR_LR_TRIPLE), ui_font(13), C_SUB);
    g_lr_counts = ui_label_create(col, "月1  日1  时1", ui_font(15), C_TEXT);

    /* 手工模式: 月/日/时 三个步进器 */
    g_lr_steps = lv_obj_create(col);
    lv_obj_set_size(g_lr_steps, 200, 100);
    lv_obj_set_style_bg_opa(g_lr_steps, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(g_lr_steps, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(g_lr_steps, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(g_lr_steps, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(g_lr_steps, 3, 0);

    const char *step_name[3] = {"月", "日", "时"};
    for (int i = 0; i < 3; i++) {
        lv_obj_t *srow = lv_obj_create(g_lr_steps);
        lv_obj_set_size(srow, 180, 28);
        lv_obj_set_style_bg_opa(srow, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_opa(srow, LV_OPA_TRANSP, 0);
        lv_obj_set_flex_flow(srow, LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(srow, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

        ui_label_create(srow, step_name[i], ui_font(15), lv_color_white());

        lv_obj_t *minus = lv_btn_create(srow);
        lv_obj_set_size(minus, 32, 24);
        lv_obj_t *ml = ui_label_create(minus, "-", ui_font(18), lv_color_white());
        lv_obj_center(ml);
        lv_obj_set_user_data(minus, (void *)(intptr_t)-1);
        lv_obj_add_event_cb(minus, step_adj_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);

        char vb[8];
        snprintf(vb, sizeof(vb), "%d", g_manual[i]);
        g_lr_steps_lbl[i] = ui_label_create(srow, vb, ui_font(15), C_BLUE);

        lv_obj_t *plus = lv_btn_create(srow);
        lv_obj_set_size(plus, 32, 24);
        lv_obj_t *pl = ui_label_create(plus, "+", ui_font(18), lv_color_white());
        lv_obj_center(pl);
        lv_obj_set_user_data(plus, (void *)(intptr_t)1);
        lv_obj_add_event_cb(plus, step_adj_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);
    }

    /* 三次推导 */
    ui_label_create(col, ui_str(UI_STR_LR_STEPS), ui_font(13), C_AMBER);
    g_s1 = ui_label_create(col, "月推  大安", ui_font(16), C_DIM);
    g_s2 = ui_label_create(col, "日推  留连", ui_font(16), C_DIM);

    lv_obj_t *s3_row = lv_obj_create(col);
    lv_obj_set_size(s3_row, 220, 46);
    lv_obj_set_style_bg_opa(s3_row, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(s3_row, LV_OPA_TRANSP, 0);
    lv_obj_set_flex_flow(s3_row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(s3_row, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(s3_row, 12, 0);
    ui_label_create(s3_row, ui_str(UI_STR_LR_H_PUSH), ui_font(16), C_DIM);
    g_s3_val = ui_label_create(s3_row, "速喜", ui_font(36), C_AMBER);  /* 最终结果: 大字号 */

    g_lr_desc = ui_label_create(col, "安稳吉祥 诸事顺遂", ui_font(13), lv_color_make(0xC8, 0xCC, 0xD4));
    lv_label_set_long_mode(g_lr_desc, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(g_lr_desc, 280);

    /* 初始可见性: 非手工显示计数, 手工显示步进器 */
    bool manual = (g_mode == LR_MANUAL);
    if (manual) {
        lv_obj_add_flag(g_lr_counts, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(g_lr_steps, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_clear_flag(g_lr_counts, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_lr_steps, LV_OBJ_FLAG_HIDDEN);
    }

    /* 占卜页不再显示返回提示; 上滑返回主页时钟、左右滑切换占卜模式 */

    liuren_refresh();
    if (!g_timer_created) {
        lv_timer_create(liuren_timer_cb, 1000, NULL);
        g_timer_created = true;
    }
}
