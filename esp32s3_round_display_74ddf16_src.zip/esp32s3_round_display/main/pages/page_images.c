#include "page_images.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"
#include "circular_layout.h"
#include "image_mgr.h"
#include "jpg_decode.h"
#include "nvs_config.h"

#include <string.h>

/* gif 控件头(需 CONFIG_LV_USE_GIF=y) */
#include "extra/libs/gif/lv_gif.h"

#define IMG_BOX 320          /* 图片适配的最大显示边长 */
static bool g_scanned = false;
static lv_img_dsc_t *g_jpg_dsc = NULL;   /* 当前 jpg 解码结果, 切图时需释放 */

/* 读取 NVS 上次浏览的图片索引 */
static int nvs_img_idx(void)
{
    int i = nvs_config_get_int("img_idx", 0);
    if (i < 0 || i >= img_count()) i = 0;
    return i;
}

void images_turn(int dir)
{
    int cnt = img_count();
    if (cnt <= 0) return;
    int cur = img_current() + dir;
    if (cur < 0) cur = cnt - 1;
    if (cur >= cnt) cur = 0;
    img_set_current(cur);
    ui_show_page(UI_PAGE_IMAGES);   /* 重建当前页(递归锁安全) */
}

void page_images_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    lv_obj_set_style_bg_color(root, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);

    if (!g_scanned) {
        img_scan();
        g_scanned = true;
        img_set_current(nvs_img_idx());
    }

    int cnt = img_count();
    if (cnt == 0) {
        ui_page_title(root, ui_str(UI_STR_PHOTOS));
        lv_obj_t *hint = ui_label_create(root,
                                        "未找到图片\n请将图片放入 /sdcard/images\n(支持 png/bmp/gif/jpg)",
                                        ui_font(14), lv_color_white());
        lv_obj_align(hint, LV_ALIGN_CENTER, 0, 0);
        lv_label_set_long_mode(hint, LV_LABEL_LONG_WRAP);
        return;
    }

    /* 释放上一张 jpg 解码结果 */
    if (g_jpg_dsc) {
        jpg_decode_free_dsc(g_jpg_dsc);
        g_jpg_dsc = NULL;
    }

    int i = img_current();
    const char *name = img_name(i);
    img_type_t t = img_type(i);

    lv_obj_t *img = NULL;
    int iw = 0, ih = 0;
    if (t == IMG_GIF) {
        img = lv_gif_create(root);
        lv_gif_set_src(img, img_path_fs(i));
        lv_img_header_t hdr;
        if (lv_img_decoder_get_info(img_path_fs(i), &hdr) == LV_RES_OK) {
            iw = hdr.w;
            ih = hdr.h;
        }
    } else if (t == IMG_JPG || t == IMG_JPEG) {
        g_jpg_dsc = jpg_decode_file(img_path(i));
        if (!g_jpg_dsc) {
            ui_page_title(root, ui_str(UI_STR_PHOTOS));
            lv_obj_t *err = ui_label_create(root, "图片解码失败",
                                            ui_font(14), lv_color_make(0xAA, 0x40, 0x40));
            lv_obj_align(err, LV_ALIGN_CENTER, 0, 0);
            return;
        }
        img = lv_img_create(root);
        lv_img_set_src(img, g_jpg_dsc);
        iw = g_jpg_dsc->header.w;
        ih = g_jpg_dsc->header.h;
    } else {
        /* png / bmp / sjpg: 交给 LVGL 内置解码器 */
        lv_img_header_t hdr;
        if (lv_img_decoder_get_info(img_path_fs(i), &hdr) != LV_RES_OK) {
            ui_page_title(root, ui_str(UI_STR_PHOTOS));
            lv_obj_t *err = ui_label_create(root, "图片解码失败",
                                            ui_font(14), lv_color_make(0xAA, 0x40, 0x40));
            lv_obj_align(err, LV_ALIGN_CENTER, 0, 0);
            return;
        }
        img = lv_img_create(root);
        lv_img_set_src(img, img_path_fs(i));
        iw = hdr.w;
        ih = hdr.h;
    }

    /* 缩放适配圆形显示框(只缩小, 不放大) */
    int32_t zoom = 256;
    if (iw > IMG_BOX || ih > IMG_BOX) {
        int32_t zx = (int32_t)IMG_BOX * 256 / (iw > 0 ? iw : 1);
        int32_t zy = (int32_t)IMG_BOX * 256 / (ih > 0 ? ih : 1);
        zoom = zx < zy ? zx : zy;
    }
    lv_img_set_zoom(img, zoom);
    lv_obj_center(img);

    ui_page_title(root, name);

    char info[48];
    snprintf(info, sizeof(info), "%d/%d   ‹上一张 | 下一张›", i + 1, cnt);
    lv_obj_t *hint = ui_label_create(root, info, ui_font(12), lv_color_make(0xCC, 0xCC, 0xCC));
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -10);
}
