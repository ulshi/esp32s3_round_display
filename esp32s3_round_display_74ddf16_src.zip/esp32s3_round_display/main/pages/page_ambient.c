#include "page_ambient.h"
#include "ui_manager.h"
#include "ui_i18n.h"
#include "board_config.h"

#include "lvgl.h"

#include <string.h>

typedef enum {
    MODE_RAINBOW = 0,
    MODE_BREATHE,
    MODE_FLOW,
    MODE_COUNT
} amb_mode_t;

static amb_mode_t  g_mode  = MODE_RAINBOW;
static lv_obj_t  *g_bg    = NULL;
static lv_obj_t  *g_circle= NULL;
static lv_obj_t  *g_arc   = NULL;
static lv_obj_t  *g_label = NULL;
static lv_timer_t *g_timer = NULL;
static uint32_t   g_phase = 0;

static void apply_mode_visibility(void)
{
    if (g_mode == MODE_RAINBOW) {
        lv_obj_clear_flag(g_bg, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_circle, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_arc, LV_OBJ_FLAG_HIDDEN);
    } else if (g_mode == MODE_BREATHE) {
        lv_obj_add_flag(g_bg, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(g_circle, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_arc, LV_OBJ_FLAG_HIDDEN);
    } else { /* FLOW */
        lv_obj_add_flag(g_bg, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(g_circle, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(g_arc, LV_OBJ_FLAG_HIDDEN);
    }
    if (g_label) {
        const char *m = g_mode == MODE_RAINBOW ? ui_str(UI_STR_RAINBOW)
                      : (g_mode == MODE_BREATHE ? ui_str(UI_STR_BREATHE) : ui_str(UI_STR_FLOW));
        lv_label_set_text(g_label, m);
    }
}

static void ambient_timer_cb(lv_timer_t *t)
{
    (void)t;
    if (ui_current_page() != UI_PAGE_AMBIENT) return;
    g_phase++;

    if (g_mode == MODE_RAINBOW) {
        lv_obj_set_style_bg_color(g_bg, lv_color_hsv_to_rgb(g_phase % 360, 75, 100), 0);
    } else if (g_mode == MODE_BREATHE) {
        int p = g_phase % 240;
        int op = (p < 120) ? (25 + p) : (145 - p);
        if (op > 100) op = 100;
        lv_obj_set_style_bg_opa(g_circle, (lv_opa_t)op, 0);
    } else { /* FLOW */
        lv_color_t c = lv_color_hsv_to_rgb(g_phase % 360, 85, 100);
        lv_obj_set_style_arc_color(g_arc, c, LV_PART_INDICATOR);
        lv_arc_set_rotation(g_arc, g_phase % 360);
    }
}

static void switch_mode_cb(lv_event_t *e)
{
    (void)e;
    g_mode = (amb_mode_t)((g_mode + 1) % MODE_COUNT);
    g_phase = 0;
    apply_mode_visibility();
}

void page_ambient_create(void)
{
    lv_obj_t *root = ui_page_root_create();
    ui_page_title(root, ui_str(UI_STR_LED));

    /* 全屏背景(彩虹模式用) */
    g_bg = lv_obj_create(root);
    lv_obj_set_size(g_bg, BOARD_LCD_H_RES, BOARD_LCD_V_RES);
    lv_obj_center(g_bg);
    lv_obj_set_style_bg_color(g_bg, lv_color_black(), 0);
    lv_obj_set_style_border_opa(g_bg, LV_OPA_TRANSP, 0);
    lv_obj_set_style_radius(g_bg, 0, 0);
    lv_obj_clear_flag(g_bg, LV_OBJ_FLAG_CLICKABLE);

    /* 呼吸模式的圆 */
    g_circle = lv_obj_create(root);
    lv_obj_set_size(g_circle, 200, 200);
    lv_obj_center(g_circle);
    lv_obj_set_style_radius(g_circle, 100, 0);
    lv_obj_set_style_bg_color(g_circle, lv_color_hsv_to_rgb(205, 80, 100), 0);
    lv_obj_set_style_border_opa(g_circle, LV_OPA_TRANSP, 0);
    lv_obj_clear_flag(g_circle, LV_OBJ_FLAG_CLICKABLE);

    /* 流光模式的弧 */
    g_arc = lv_arc_create(root);
    lv_obj_center(g_arc);
    lv_obj_set_size(g_arc, 280, 280);
    lv_arc_set_range(g_arc, 0, 100);
    lv_arc_set_value(g_arc, 70);
    lv_arc_set_bg_angles(g_arc, 0, 360);
    lv_obj_set_style_arc_width(g_arc, 18, LV_PART_INDICATOR);
    lv_obj_set_style_arc_opa(g_arc, LV_OPA_COVER, LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(g_arc, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_arc_opa(g_arc, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_clear_flag(g_arc, LV_OBJ_FLAG_CLICKABLE);

    g_label = ui_label_create(root, ui_str(UI_STR_RAINBOW), ui_font(20), lv_color_white());
    lv_obj_align(g_label, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *hint = ui_label_create(root, ui_str(UI_STR_TAP_SWITCH), ui_font(12),
                                    lv_color_make(0xE0, 0xE0, 0xE0));
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -14);

    g_phase = 0;
    apply_mode_visibility();

    /* 点击任意处切换模式 */
    lv_obj_add_event_cb(root, switch_mode_cb, LV_EVENT_CLICKED, NULL);

    if (g_timer) lv_timer_del(g_timer);
    g_timer = lv_timer_create(ambient_timer_cb, 30, NULL);
}
