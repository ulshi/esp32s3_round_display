#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 图片目录 (SD 卡, 已由 sd_card.c 预创建) */
#define IMG_DIR "/sdcard/images"
#define IMG_MAX_FILES 64
#define IMG_NAME_LEN 64

/* 支持的图片类型 (按扩展名判定) */
typedef enum {
    IMG_PNG,
    IMG_BMP,
    IMG_GIF,
    IMG_JPG,
    IMG_JPEG,
    IMG_SJPG,
    IMG_UNKNOWN
} img_type_t;

/** 扫描 IMG_DIR, 收集受支持格式的图片。返回找到的数量。 */
int img_scan(void);

int img_count(void);
const char *img_name(int i);
const char *img_path(int i);      /* 真实 VFS 路径, 如 /sdcard/images/a.png */
const char *img_path_fs(int i);   /* LVGL 文件系统路径, 如 S:/sdcard/images/a.png */
img_type_t img_type(int i);

void img_set_current(int i);
int img_current(void);

#ifdef __cplusplus
}
#endif
