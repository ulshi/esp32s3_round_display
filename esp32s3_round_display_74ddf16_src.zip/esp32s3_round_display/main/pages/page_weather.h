#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_weather_create(void);
#ifdef __cplusplus
}
#endif
