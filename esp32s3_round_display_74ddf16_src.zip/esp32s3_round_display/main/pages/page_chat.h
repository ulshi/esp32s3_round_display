#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void page_chat_create(void);
#ifdef __cplusplus
}
#endif
