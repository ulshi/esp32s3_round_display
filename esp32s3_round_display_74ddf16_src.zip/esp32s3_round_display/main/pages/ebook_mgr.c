#include "ebook_mgr.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>

#include "nvs_config.h"
#include "esp_log.h"

static const char *TAG = "ebook";

static char g_names[EBOOK_MAX_FILES][EBOOK_NAME_LEN];
static char g_paths[EBOOK_MAX_FILES][EBOOK_NAME_LEN + 32];
static int  g_count = 0;
static int  g_current = 0;          /* 当前书索引 */

/* 流式读取: 仅保存"每行起始偏移表", 不把整本书载入内存。
 * 这样哪怕 14MB 的小说也不会 OOM —— 渲染时按行偏移 fseek 读当前页即可。 */
static FILE *g_f = NULL;            /* 当前书文件句柄(保持打开) */
static long  *g_line_off = NULL;    /* 各行起始文件偏移 */
static int    g_line_count = 0;     /* 总行数 */
static long   g_fsize = 0;          /* 当前书字节数 */
static int    g_open_idx = -1;      /* 已建偏移表的书索引(幂等打开用) */

int ebook_scan(void)
{
    g_count = 0;
    DIR *d = opendir(EBOOK_DIR);
    if (!d) {
        ESP_LOGW(TAG, "opendir %s failed (SD 未挂载?)", EBOOK_DIR);
        return 0;
    }
    struct dirent *e;
    while ((e = readdir(d)) != NULL && g_count < EBOOK_MAX_FILES) {
        int n = (int)strlen(e->d_name);
        if (n > 4 && strcasecmp(e->d_name + n - 4, ".txt") == 0) {
            strncpy(g_names[g_count], e->d_name, EBOOK_NAME_LEN - 1);
            g_names[g_count][EBOOK_NAME_LEN - 1] = '\0';
            snprintf(g_paths[g_count], sizeof(g_paths[0]), "%s/%s", EBOOK_DIR, e->d_name);
            g_count++;
        }
    }
    closedir(d);
    ESP_LOGI(TAG, "scanned %d books", g_count);
    return g_count;
}

int ebook_count(void) { return g_count; }

const char *ebook_name(int i)
{
    if (i < 0 || i >= g_count) return "";
    return g_names[i];
}

const char *ebook_path(int i)
{
    if (i < 0 || i >= g_count) return "";
    return g_paths[i];
}

void ebook_set_current(int i)
{
    if (i < 0 || i >= g_count) return;
    g_current = i;
    nvs_config_set_int("ebook_idx", i);
}

int ebook_current(void) { return g_current; }

bool ebook_open_current(void)
{
    /* 幂等: 同一本书已经打开建过偏移表, 直接复用, 不重复扫描 14MB 文件。
     * 这是消除"翻页卡顿"的关键 —— 翻页时 page 重建会再次调用本函数。 */
    if (g_f && g_open_idx == g_current) return true;

    ebook_close();
    if (g_count == 0) return false;
    if (g_current < 0 || g_current >= g_count) g_current = 0;

    FILE *f = fopen(g_paths[g_current], "rb");
    if (!f) {
        ESP_LOGE(TAG, "open '%s' failed: %d (%s)", g_paths[g_current], errno, strerror(errno));
        return false;
    }
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (fsize <= 0) {
        ESP_LOGE(TAG, "file '%s' empty/invalid size=%ld", g_paths[g_current], fsize);
        fclose(f);
        return false;
    }

    /* 逐块扫描, 仅记录每行起始偏移到动态数组(不再载入全文)。
     * 块大小 4KB, 减少 fread 系统调用次数, 加快首次打开。 */
    int cap = 4096;
    long *off = (long *)malloc((size_t)cap * sizeof(long));
    if (!off) {
        ESP_LOGE(TAG, "malloc line-offset table (%d) failed", cap);
        fclose(f);
        return false;
    }
    off[0] = 0;
    int  n = 1;
    long pos = 0;
    char blk[4096];
    size_t got;
    while ((got = fread(blk, 1, sizeof(blk), f)) > 0) {
        for (size_t i = 0; i < got; i++) {
            if (blk[i] == '\n') {
                if (n >= cap) {
                    int ncap = cap * 2;
                    if (ncap > 4000000) ncap = 4000000;   /* 行数上限保护 */
                    long *t = (long *)realloc(off, (size_t)ncap * sizeof(long));
                    if (!t) {
                        ESP_LOGE(TAG, "realloc offset table failed at %d lines", n);
                        free(off);
                        fclose(f);
                        return false;
                    }
                    off = t;
                    cap = ncap;
                }
                if (n < cap) off[n++] = pos + 1;   /* 下一行起点(跳过 '\n') */
            }
            pos++;
        }
    }

    g_line_count = n;
    g_line_off = off;
    g_fsize = fsize;
    g_f = f;
    g_open_idx = g_current;
    ESP_LOGI(TAG, "opened '%s' %ld bytes, %d lines (streaming)", g_names[g_current], fsize, g_line_count);
    return true;
}

void ebook_close(void)
{
    if (g_f) { fclose(g_f); g_f = NULL; }
    if (g_line_off) { free(g_line_off); g_line_off = NULL; }
    g_line_count = 0;
    g_fsize = 0;
    g_open_idx = -1;
}

int ebook_lines(void) { return g_line_count; }

/* 一次性把 [start_line, start_line+num_lines) 范围内的原始文本读入 out,
 * 返回读到的字节数。翻页渲染专用: 一次 fread 替代逐行 fseek+fgetc。 */
int ebook_read_page(int start_line, int num_lines, char *out, int out_cap)
{
    if (!g_f || out_cap <= 1) { if (out) out[0] = '\0'; return 0; }
    if (start_line < 0) start_line = 0;
    if (start_line >= g_line_count) { out[0] = '\0'; return 0; }
    if (num_lines < 1) num_lines = 1;

    long start = g_line_off[start_line];
    long end = (start_line + num_lines < g_line_count)
               ? g_line_off[start_line + num_lines]
               : g_fsize;
    long len = end - start;
    if (len > (long)out_cap - 1) len = (long)out_cap - 1;
    if (len < 0) len = 0;

    fseek(g_f, start, SEEK_SET);
    size_t got = fread(out, 1, (size_t)len, g_f);
    out[got] = '\0';
    return (int)got;
}

/* 估算每页起始行: 直接做边界约束(每页行数由 page_ebook.c 控制)。 */
int ebook_page_turn(int start_line, int step)
{
    int next = start_line + step;
    if (next < 0) next = 0;
    if (next >= g_line_count) next = g_line_count - 1;
    return next;
}
