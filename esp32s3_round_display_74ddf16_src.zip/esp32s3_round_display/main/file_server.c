#include "file_server.h"

#include <string.h>
#include <strings.h>     /* strcasecmp */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/unistd.h>
#include <dirent.h>

#include "esp_log.h"
#include "esp_http_server.h"

#include "sd_card.h"
#include "wifi_prov.h"

static const char *TAG = "file_server";

#define FS_ROOT   "/sdcard"
#define FS_PORT   8080
#define FS_BUF    1024

static httpd_handle_t g_fs_srv = NULL;
static httpd_handle_t g_cap_srv = NULL;   /* captive portal (端口 80 重定向) */
static bool           g_fs_on  = false;

/* ---------------- 工具函数 ---------------- */

/* 校验文件名: 仅允许纯文件名(无路径、无 ..), 返回拼接后的完整路径。
 * 失败返回 NULL。 */
static char *safe_path(const char *name, char *out, size_t outsz)
{
    if (!name || !*name) return NULL;
    if (strchr(name, '/') || strchr(name, '\\') || strstr(name, "..")) return NULL;
    snprintf(out, outsz, "%s/%s", FS_ROOT, name);
    return out;
}

/* 依据扩展名返回 Content-Type。 */
static const char *content_type(const char *path)
{
    const char *dot = strrchr(path, '.');
    if (!dot) return "application/octet-stream";
    if (!strcasecmp(dot, ".html")) return "text/html; charset=utf-8";
    if (!strcasecmp(dot, ".htm"))  return "text/html; charset=utf-8";
    if (!strcasecmp(dot, ".txt"))  return "text/plain; charset=utf-8";
    if (!strcasecmp(dot, ".csv"))  return "text/csv; charset=utf-8";
    if (!strcasecmp(dot, ".json")) return "application/json";
    if (!strcasecmp(dot, ".css"))  return "text/css";
    if (!strcasecmp(dot, ".js"))   return "application/javascript";
    if (!strcasecmp(dot, ".png"))  return "image/png";
    if (!strcasecmp(dot, ".jpg"))  return "image/jpeg";
    if (!strcasecmp(dot, ".jpeg")) return "image/jpeg";
    if (!strcasecmp(dot, ".gif"))  return "image/gif";
    if (!strcasecmp(dot, ".bmp"))  return "image/bmp";
    if (!strcasecmp(dot, ".webp")) return "image/webp";
    if (!strcasecmp(dot, ".mp3"))  return "audio/mpeg";
    if (!strcasecmp(dot, ".wav"))  return "audio/wav";
    if (!strcasecmp(dot, ".mp4"))  return "video/mp4";
    if (!strcasecmp(dot, ".zip"))  return "application/zip";
    if (!strcasecmp(dot, ".pdf"))  return "application/pdf";
    return "application/octet-stream";
}

/* 转义 HTML 特殊字符 (用于文件名回显)。 */
static void html_escape(const char *src, char *dst, size_t dstsz)
{
    size_t j = 0;
    for (size_t i = 0; src[i] && j + 1 < dstsz; i++) {
        char c = src[i];
        if (c == '<' || c == '>' || c == '&' || c == '"') {
            const char *ent = (c == '<') ? "&lt;" : (c == '>') ? "&gt;"
                              : (c == '&') ? "&amp;" : "&quot;";
            size_t k = 0;
            while (ent[k] && j + 1 < dstsz) dst[j++] = ent[k++];
        } else {
            dst[j++] = c;
        }
    }
    dst[j] = '\0';
}

/* ---------------- HTTP 处理函数 ---------------- */

/* GET / : 列出 /sdcard 内容, 提供下载链接与上传表单。 */
static esp_err_t fs_root_get(httpd_req_t *req)
{
    char html[2048];
    int n = snprintf(html, sizeof(html),
        "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<title>SD 文件服务器</title>"
        "<style>body{font-family:sans-serif;padding:16px;max-width:640px;margin:auto}"
        "a{text-decoration:none;color:#06c}li{margin:6px 0}"
        ".up{margin-top:20px;padding:12px;border:1px solid #ccc;border-radius:8px}</style>"
        "</head><body><h2>SD 卡文件</h2><ul>");

    DIR *d = opendir(FS_ROOT);
    if (d) {
        struct dirent *de;
        while ((de = readdir(d)) != NULL) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char full[256];
            safe_path(de->d_name, full, sizeof(full));
            struct stat st;
            const char *tag = (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) ? "[目录] " : "";
            char esc[128];
            html_escape(de->d_name, esc, sizeof(esc));
            n += snprintf(html + n, sizeof(html) - n,
                         "<li>%s<a href=\"/download?name=%s\">%s</a></li>", tag, de->d_name, esc);
        }
        closedir(d);
    } else {
        n += snprintf(html + n, sizeof(html) - n, "<li>(无法读取目录)</li>");
    }

    n += snprintf(html + n, sizeof(html) - n,
        "</ul>"
        "<div class=\"up\"><h3>上传文件</h3>"
        "<input type=\"file\" id=\"f\"><br><br>"
        "<button onclick=\"upload()\">上传到 /sdcard</button>"
        "<p id=\"msg\"></p></div>"
        "<script>"
        "async function upload(){"
        "  const f=document.getElementById('f').files[0]; if(!f){alert('请选择文件');return;}"
        "  const r=await fetch('/upload?name='+encodeURIComponent(f.name),{method:'POST',body:f});"
        "  document.getElementById('msg').textContent=r.ok?'上传成功':'上传失败';"
        "  setTimeout(()=>location.reload(),600);"
        "}</script></body></html>");

    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_send(req, html, n);
    return ESP_OK;
}

/* GET /download?name=xxx : 发送文件(附件形式, 触发浏览器下载)。 */
static esp_err_t fs_download_get(httpd_req_t *req)
{
    char q[128] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) q[0] = '\0';
    char name[128] = {0};
    if (httpd_query_key_value(q, "name", name, sizeof(name)) != ESP_OK || !name[0]) {
        httpd_resp_send(req, "缺少 name 参数", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char path[256];
    if (!safe_path(name, path, sizeof(path))) {
        httpd_resp_send(req, "非法文件名", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    FILE *f = fopen(path, "rb");
    if (!f) {
        httpd_resp_set_status(req, "404 Not Found");
        httpd_resp_send(req, "文件不存在", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    struct stat st;
    long size = (fstat(fileno(f), &st) == 0) ? (long)st.st_size : -1;

    char disp[160];
    snprintf(disp, sizeof(disp), "attachment; filename=\"%s\"", name);
    httpd_resp_set_type(req, content_type(path));
    httpd_resp_set_hdr(req, "Content-Disposition", disp);
    if (size >= 0) {
        char len[32];
        snprintf(len, sizeof(len), "%ld", size);
        httpd_resp_set_hdr(req, "Content-Length", len);
    }

    char buf[FS_BUF];
    size_t r;
    while ((r = fread(buf, 1, sizeof(buf), f)) > 0) {
        if (httpd_resp_send_chunk(req, buf, r) != ESP_OK) break;
    }
    httpd_resp_send_chunk(req, NULL, 0);   /* 结束分块 */
    fclose(f);
    return ESP_OK;
}

/* POST /upload?name=xxx : 将请求体原样写入 /sdcard/<name>。 */
static esp_err_t fs_upload_post(httpd_req_t *req)
{
    char q[128] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) q[0] = '\0';
    char name[128] = {0};
    if (httpd_query_key_value(q, "name", name, sizeof(name)) != ESP_OK || !name[0]) {
        httpd_resp_send(req, "缺少 name 参数", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char path[256];
    if (!safe_path(name, path, sizeof(path))) {
        httpd_resp_send(req, "非法文件名", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    FILE *f = fopen(path, "wb");
    if (!f) {
        httpd_resp_send(req, "无法创建文件(可能 SD 卡只读或损坏)", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char buf[FS_BUF];
    int total = 0;
    int ret;
    while ((ret = httpd_req_recv(req, buf, sizeof(buf))) > 0) {
        if (fwrite(buf, 1, ret, f) != (size_t)ret) break;
        total += ret;
    }
    fclose(f);

    char msg[64];
    snprintf(msg, sizeof(msg), "已写入 %d 字节", total);
    httpd_resp_send(req, msg, HTTPD_RESP_USE_STRLEN);
    ESP_LOGI(TAG, "upload '%s' -> %d bytes", path, total);
    return ESP_OK;
}

/* ---------------- captive portal (端口 80 重定向) ----------------
 * 手机连上开放 AP 后会做联网探测; 在 80 端口返回 302 重定向到文件服务器,
 * 触发 Android/iOS 自动弹出浏览器并跳转到文件服务器页面, 实现
 * "扫码连 WiFi -> 自动打开文件服务器" 的无缝体验。 */

#define FS_REDIR_URL  "http://192.168.4.1:8080/"

static esp_err_t captive_get(httpd_req_t *req)
{
    httpd_resp_set_status(req, "302 Found");
    httpd_resp_set_hdr(req, "Location", FS_REDIR_URL);
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_send(req,
        "<meta http-equiv=\"refresh\" content=\"0;url=" FS_REDIR_URL "\">"
        "<p>Redirecting to file server...</p>", HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void captive_start(void)
{
    if (g_cap_srv) return;   /* 已启动 */
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port = 80;
    cfg.stack_size  = 2048;
    cfg.max_uri_handlers = 4;

    httpd_uri_t uri = {
        .uri = "/*", .method = HTTP_GET, .handler = captive_get, .user_ctx = NULL,
    };
    if (httpd_start(&g_cap_srv, &cfg) == ESP_OK) {
        httpd_register_uri_handler(g_cap_srv, &uri);
        ESP_LOGI(TAG, "captive portal 已启动 (端口 80 -> %s)", FS_REDIR_URL);
    } else {
        /* 端口 80 可能已被配网服务占用(配网模式), 忽略: 二维码仍可连 WiFi, 手动开地址 */
        ESP_LOGW(TAG, "captive portal 启动失败(端口 80 被占用?), 跳过");
        g_cap_srv = NULL;
    }
}

static void captive_stop(void)
{
    if (g_cap_srv) {
        httpd_stop(g_cap_srv);
        g_cap_srv = NULL;
        ESP_LOGI(TAG, "captive portal 已停止");
    }
}

/* ---------------- 启停 ---------------- */

bool file_server_sd_missing(void)
{
    return !sd_card_is_mounted();
}

void file_server_set_enabled(bool on)
{
    if (on) {
        /* 挂载 SD (无卡不致命但服务器无意义) */
        sd_card_mount();
        if (!sd_card_is_mounted()) {
            ESP_LOGE(TAG, "SD 卡未挂载(%s), 文件服务器无法启动",
                     sd_card_last_error() ? sd_card_last_error() : "未知原因");
            g_fs_on = false;
            return;
        }
        /* 确保设备 AP 已启动, 手机才能连上 192.168.4.1 */
        app_wifi_ensure_ap();

        if (!g_fs_srv) {
            httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
            cfg.server_port = FS_PORT;
            cfg.stack_size  = 8192;
            cfg.max_uri_handlers = 8;

            httpd_uri_t uris[] = {
                { .uri = "/",          .method = HTTP_GET,  .handler = fs_root_get,    .user_ctx = NULL },
                { .uri = "/download",  .method = HTTP_GET,  .handler = fs_download_get,.user_ctx = NULL },
                { .uri = "/upload",    .method = HTTP_POST, .handler = fs_upload_post, .user_ctx = NULL },
            };
            if (httpd_start(&g_fs_srv, &cfg) == ESP_OK) {
                for (int i = 0; i < 3; i++) httpd_register_uri_handler(g_fs_srv, &uris[i]);
                ESP_LOGI(TAG, "文件服务器已启动: http://192.168.4.1:%d/", FS_PORT);
            } else {
                ESP_LOGE(TAG, "httpd_start 失败");
                g_fs_srv = NULL;
            }
        }
        g_fs_on = (g_fs_srv != NULL);
        if (g_fs_on) captive_start();   /* 启动重定向, 使扫码连 WiFi 后自动跳转 */
    } else {
        captive_stop();
        if (g_fs_srv) {
            httpd_stop(g_fs_srv);
            g_fs_srv = NULL;
        }
        g_fs_on = false;
    }
}

bool file_server_is_enabled(void)
{
    return g_fs_on;
}
