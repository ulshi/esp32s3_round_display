#include "wifi_prov.h"

#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "apps/esp_sntp.h"

#include "nvs_config.h"

static const char *TAG = "wifi_prov";

static void sntp_start_once(void);

#define PROV_SSID_PREFIX "ROUND_DISP_"
#define NVS_WIFI_SSID    "wifi_ssid"
#define NVS_WIFI_PASS    "wifi_pass"
#define NVS_PROV_DONE    "wifi_provisioned"

/* ---- 配网网页(手机连上 SoftAP 后浏览器打开) ---- */
static const char *HTML_PAGE =
    "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
    "<title>圆屏配网</title></head><body style=\"font-family:sans-serif;text-align:center;padding:18px\">"
    "<h2>圆屏 WiFi 配网</h2>"
    "<p>请填写家里 WiFi 的名称和密码:</p>"
    "<form method=\"post\" action=\"/set\">"
    "<p>WiFi 名称 (SSID):<br><input name=\"ssid\" style=\"width:80%;padding:8px\"></p>"
    "<p>密码:<br><input name=\"pass\" type=\"password\" style=\"width:80%;padding:8px\"></p>"
    "<p><button type=\"submit\" style=\"padding:10px 20px\">保存并连接</button></p>"
    "</form></body></html>";

static wifi_state_t  g_state = WIFI_STATE_IDLE;
static char          g_ip[16] = "";
static char          g_prov_ssid[33] = "";
static httpd_handle_t g_server = NULL;
static void (*g_cb)(wifi_state_t) = NULL;

static void set_state(wifi_state_t s)
{
    g_state = s;
    if (g_cb) g_cb(s);
}

/* ---------------- 事件处理 ---------------- */
static void event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        wifi_event_sta_disconnected_t *e = (wifi_event_sta_disconnected_t *)data;
        ESP_LOGW(TAG, "STA disconnected, reason=%d", e->reason);
        if (g_state == WIFI_STATE_CONNECTED || g_state == WIFI_STATE_CONNECTING) {
            bool auth_fail =
                (e->reason == WIFI_REASON_AUTH_EXPIRE ||
                 e->reason == WIFI_REASON_HANDSHAKE_TIMEOUT ||
                 e->reason == WIFI_REASON_AUTH_FAIL ||
                 e->reason == WIFI_REASON_ASSOC_FAIL);
            if (auth_fail) {
                ESP_LOGW(TAG, "认证失败 -> 清除配网标记, 重启进入配网");
                nvs_config_set_int(NVS_PROV_DONE, 0);
                set_state(WIFI_STATE_FAILED);
                vTaskDelay(pdMS_TO_TICKS(300));
                esp_restart();
            } else {
                esp_wifi_connect();   /* 其它原因直接重试 */
            }
        }
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        uint32_t ip = e->ip_info.ip.addr;
        snprintf(g_ip, sizeof(g_ip), "%u.%u.%u.%u",
                 (ip >> 0) & 0xFF, (ip >> 8) & 0xFF, (ip >> 16) & 0xFF, (ip >> 24) & 0xFF);
        ESP_LOGI(TAG, "got IP %s", g_ip);
        nvs_config_set_int(NVS_PROV_DONE, 1);
        set_state(WIFI_STATE_CONNECTED);
        sntp_start_once();
    }
}

/* ---------------- SNTP 校时 ---------------- */
/* WiFi 拿到 IP 后启动一次 SNTP, 让 time(NULL) 返回真实本地时间(时钟才准确)。
 * sdkconfig 已开启 CONFIG_LWIP_SNTP_*, 默认每小时自动重校。
 * 若用户手工设过时间(NVS_TIME_MANUAL=1), 则跳过 SNTP, 不覆盖手工值。 */
static bool s_sntp_started = false;

/* SNTP 同步成功后把真实时间写回 NVS, 作为下次离线启动的时间基线。 */
static void sntp_sync_cb(struct timeval *tv)
{
    (void)tv;
    if (app_time_is_manual()) return;
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    if (!t) return;
    nvs_config_set_int(NVS_TIME_YEAR, t->tm_year + 1900);
    nvs_config_set_int(NVS_TIME_MON,  t->tm_mon + 1);
    nvs_config_set_int(NVS_TIME_DAY,  t->tm_mday);
    nvs_config_set_int(NVS_TIME_HOUR, t->tm_hour);
    nvs_config_set_int(NVS_TIME_MIN,  t->tm_min);
    ESP_LOGI(TAG, "SNTP synced, persisted %04d-%02d-%02d %02d:%02d",
             t->tm_year + 1900, t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min);
}

static void sntp_start_once(void)
{
    if (s_sntp_started) return;
    if (app_time_is_manual()) {
        ESP_LOGI(TAG, "用户已手工设时间, 跳过 SNTP 校时");
        return;
    }
    s_sntp_started = true;
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, "pool.ntp.org");
    sntp_set_time_sync_notification_cb(sntp_sync_cb);
    sntp_init();
    ESP_LOGI(TAG, "SNTP started, waiting for time sync");
}

/* ---------------- 配网 HTTP 服务 ---------------- */
/* 极简 url-decode(处理 + 与 %XX)。 */
static void url_decode(const char *in, char *out, size_t outlen)
{
    size_t i = 0, o = 0;
    while (in[i] && o < outlen - 1) {
        if (in[i] == '+') {
            out[o++] = ' ';
        } else if (in[i] == '%' && in[i + 1] && in[i + 2]) {
            unsigned v;
            if (sscanf(in + i + 1, "%2x", &v) == 1) {
                out[o++] = (char)v;
                i += 2;
            } else {
                out[o++] = in[i];
            }
        } else {
            out[o++] = in[i];
        }
        i++;
    }
    out[o] = '\0';
}

/* 从 "key=value&key2=val2" 中提取指定 key 的值(已 url-decode)。 */
static void parse_kv(const char *body, const char *key, char *out, size_t outlen)
{
    size_t kl = strlen(key);
    const char *p = body;
    while ((p = strstr(p, key)) != NULL) {
        if (p > body && p[-1] != '&' && p[-1] != '?') { p += kl; continue; }
        const char *q = p + kl;
        if (*q != '=') { p += kl; continue; }
        q++;
        const char *end = q;
        while (*end && *end != '&') end++;
        size_t len = (size_t)(end - q);
        char tmp[128];
        if (len >= sizeof(tmp)) len = sizeof(tmp) - 1;
        memcpy(tmp, q, len);
        tmp[len] = '\0';
        url_decode(tmp, out, outlen);
        return;
    }
}

static esp_err_t root_get(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_send(req, HTML_PAGE, strlen(HTML_PAGE));
    return ESP_OK;
}

static esp_err_t set_post(httpd_req_t *req)
{
    char buf[256];
    int len = httpd_req_recv(req, buf, sizeof(buf) - 1);
    if (len <= 0) return ESP_FAIL;
    buf[len] = '\0';

    char ssid[65] = "", pass[65] = "";
    parse_kv(buf, "ssid", ssid, sizeof(ssid));
    parse_kv(buf, "pass", pass, sizeof(pass));

    if (ssid[0]) {
        nvs_config_set_str(NVS_WIFI_SSID, ssid);
        nvs_config_set_str(NVS_WIFI_PASS, pass);
        nvs_config_set_int(NVS_PROV_DONE, 1);
        ESP_LOGI(TAG, "saved ssid='%s', restarting into STA", ssid);
        httpd_resp_send(req, "OK, 正在重启连接...", HTTPD_RESP_USE_STRLEN);
        vTaskDelay(pdMS_TO_TICKS(400));
        esp_restart();
    }
    httpd_resp_send(req, "缺少 SSID", HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t not_found(httpd_req_t *req)
{
    httpd_resp_send(req, "404", HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void start_http_server(void)
{
    if (g_server) return;
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port = 80;
    cfg.stack_size = 4096;

    httpd_uri_t uris[] = {
        { .uri = "/",        .method = HTTP_GET,  .handler = root_get,  .user_ctx = NULL },
        { .uri = "/set",     .method = HTTP_POST, .handler = set_post,  .user_ctx = NULL },
        { .uri = "/*",       .method = HTTP_GET,  .handler = not_found, .user_ctx = NULL },
    };

    if (httpd_start(&g_server, &cfg) == ESP_OK) {
        for (int i = 0; i < 3; i++) httpd_register_uri_handler(g_server, &uris[i]);
        ESP_LOGI(TAG, "HTTP 配网服务已启动 (192.168.4.1)");
    } else {
        ESP_LOGE(TAG, "httpd_start 失败");
    }
}

/* ---------------- 对外 API ---------------- */
void app_wifi_init(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT, ESP_EVENT_ANY_ID, event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        IP_EVENT, IP_EVENT_STA_GOT_IP, event_handler, NULL, NULL));
}

static void start_provisioning(void)
{
    set_state(WIFI_STATE_PROVISIONING);

    uint8_t mac[6];
    if (esp_wifi_get_mac(WIFI_IF_STA, mac) != ESP_OK) memset(mac, 0, 6);
    snprintf(g_prov_ssid, sizeof(g_prov_ssid), "%s%02X%02X",
             PROV_SSID_PREFIX, mac[4], mac[5]);

    wifi_config_t cfg = {0};
    snprintf((char *)cfg.ap.ssid, sizeof(cfg.ap.ssid), "%s", g_prov_ssid);
    cfg.ap.ssid_len = (uint8_t)strlen(g_prov_ssid);
    cfg.ap.channel = 1;
    cfg.ap.authmode = WIFI_AUTH_OPEN;
    cfg.ap.max_connection = 4;
    cfg.ap.beacon_interval = 100;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    start_http_server();
    ESP_LOGI(TAG, "SoftAP '%s' 已启动, 手机连上后浏览器打开 192.168.4.1", g_prov_ssid);
}

void app_wifi_start(void)
{
    char ssid[65] = "", pass[65] = "";
    nvs_config_get_str(NVS_WIFI_SSID, ssid, sizeof(ssid));
    nvs_config_get_str(NVS_WIFI_PASS, pass, sizeof(pass));
    int prov = nvs_config_get_int(NVS_PROV_DONE, 0);

    if (prov == 1 && ssid[0]) {
        ESP_LOGI(TAG, "已配网, 连接 STA: %s", ssid);
        set_state(WIFI_STATE_CONNECTING);
        wifi_config_t cfg = {0};
        snprintf((char *)cfg.sta.ssid, sizeof(cfg.sta.ssid), "%s", ssid);
        snprintf((char *)cfg.sta.password, sizeof(cfg.sta.password), "%s", pass);
        cfg.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &cfg));
        ESP_ERROR_CHECK(esp_wifi_start());
        ESP_ERROR_CHECK(esp_wifi_connect());
    } else {
        ESP_LOGI(TAG, "未配网, 进入 SoftAP 配网模式");
        start_provisioning();
    }
}

wifi_state_t app_wifi_state(void)        { return g_state; }
bool        app_wifi_is_connected(void)  { return g_state == WIFI_STATE_CONNECTED; }
const char *app_wifi_ip_str(void)        { return g_ip; }
const char *app_wifi_prov_ssid(void)     { return g_prov_ssid; }
void        app_wifi_set_notify_cb(void (*cb)(wifi_state_t)) { g_cb = cb; }

#define FILE_AP_SSID "ROUND_DISP_FS"

void app_wifi_ensure_ap(void)
{
    wifi_mode_t mode;
    if (esp_wifi_get_mode(&mode) == ESP_OK &&
        (mode == WIFI_MODE_AP || mode == WIFI_MODE_APSTA)) {
        ESP_LOGI(TAG, "SoftAP 已在运行, 文件服务器可直接使用");
        return;
    }

    /* 当前仅 STA: 切换为 APSTA 并拉起开放 AP, 不中断已有 STA 连接 */
    wifi_config_t cfg = {0};
    snprintf((char *)cfg.ap.ssid, sizeof(cfg.ap.ssid), "%s", FILE_AP_SSID);
    cfg.ap.ssid_len = (uint8_t)strlen(FILE_AP_SSID);
    cfg.ap.channel = 1;
    cfg.ap.authmode = WIFI_AUTH_OPEN;
    cfg.ap.max_connection = 4;
    cfg.ap.beacon_interval = 100;

    /* 非致命: 即便切换失败也不要 abort/重启, 否则会让设备陷入重启循环 */
    esp_err_t r = esp_wifi_set_mode(WIFI_MODE_APSTA);
    if (r != ESP_OK) {
        ESP_LOGE(TAG, "app_wifi_ensure_ap set_mode 失败: %s", esp_err_to_name(r));
        return;
    }
    r = esp_wifi_set_config(WIFI_IF_AP, &cfg);
    if (r != ESP_OK) {
        ESP_LOGE(TAG, "app_wifi_ensure_ap set AP config 失败: %s", esp_err_to_name(r));
        return;
    }
    ESP_LOGI(TAG, "已拉起文件服务器 AP: %s (192.168.4.1)", FILE_AP_SSID);
}

const char *app_wifi_ap_ssid(void)
{
    static char ssid[33] = "";
    wifi_config_t cfg;
    if (esp_wifi_get_config(WIFI_IF_AP, &cfg) == ESP_OK && cfg.ap.ssid[0]) {
        strncpy(ssid, (char *)cfg.ap.ssid, sizeof(ssid) - 1);
        ssid[sizeof(ssid) - 1] = '\0';
    } else {
        ssid[0] = '\0';
    }
    return ssid;
}
