#include "net_http.h"

#include <string.h>

#include "esp_http_client.h"
#include "esp_crt_bundle.h"
#include "esp_log.h"

static const char *TAG = "net_http";

typedef struct {
    char  *buf;
    size_t buflen;
    size_t filled;
    int    status;
} http_acc_t;

static esp_err_t on_data(esp_http_client_event_t *evt)
{
    http_acc_t *a = (http_acc_t *)evt->user_data;
    if (evt->event_id == HTTP_EVENT_ON_DATA && evt->data && evt->data_len > 0) {
        if (a->filled + evt->data_len < a->buflen) {
            memcpy(a->buf + a->filled, evt->data, evt->data_len);
            a->filled += evt->data_len;
        } else {
            size_t rem = a->buflen - a->filled - 1;
            if (rem > 0) {
                memcpy(a->buf + a->filled, evt->data, rem);
                a->filled += rem;
            }
        }
    }
    return ESP_OK;
}

static void common_cfg(esp_http_client_config_t *cfg, const char *url, http_acc_t *a, int timeout_ms)
{
    memset(cfg, 0, sizeof(*cfg));
    cfg->url = url;
    cfg->event_handler = on_data;
    cfg->user_data = a;
    cfg->crt_bundle_attach = esp_crt_bundle_attach;   /* 用默认 CA 包校验证书 */
    cfg->timeout_ms = timeout_ms;
}

static esp_err_t do_perform(esp_http_client_handle_t c, http_acc_t *a, int *out_status)
{
    esp_err_t r = esp_http_client_perform(c);
    if (r == ESP_OK) {
        a->status = esp_http_client_get_status_code(c);
        if (out_status) *out_status = a->status;
        if (a->buf && a->buflen) a->buf[a->filled] = '\0';
    }
    return r;
}

esp_err_t http_get(const char *url, char *buf, size_t buflen, int *out_status)
{
    http_acc_t a = { buf, buflen, 0, 0 };
    if (buf && buflen) buf[0] = '\0';

    esp_http_client_config_t cfg;
    common_cfg(&cfg, url, &a, 15000);
    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    if (!c) return ESP_FAIL;
    esp_err_t r = do_perform(c, &a, out_status);
    if (r != ESP_OK) ESP_LOGE(TAG, "GET %s failed: %s", url, esp_err_to_name(r));
    esp_http_client_cleanup(c);
    return r;
}

esp_err_t http_post(const char *url, const char *bearer, const char *body,
                    char *buf, size_t buflen, int *out_status)
{
    http_acc_t a = { buf, buflen, 0, 0 };
    if (buf && buflen) buf[0] = '\0';

    esp_http_client_config_t cfg;
    common_cfg(&cfg, url, &a, 30000);
    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    if (!c) return ESP_FAIL;

    esp_http_client_set_method(c, HTTP_METHOD_POST);
    esp_http_client_set_header(c, "Content-Type", "application/json");
    if (bearer && *bearer) {
        char auth[160];
        snprintf(auth, sizeof(auth), "Bearer %s", bearer);
        esp_http_client_set_header(c, "Authorization", auth);
    }
    if (body) esp_http_client_set_post_field(c, body, (int)strlen(body));

    esp_err_t r = do_perform(c, &a, out_status);
    if (r != ESP_OK) ESP_LOGE(TAG, "POST %s failed: %s", url, esp_err_to_name(r));
    esp_http_client_cleanup(c);
    return r;
}
