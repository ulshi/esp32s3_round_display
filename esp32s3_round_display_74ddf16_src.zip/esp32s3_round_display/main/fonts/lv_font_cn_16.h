#pragma once

/* 中文字库: 黑体 16px, 4bpp 抗锯齿
 * 字集: GB2312 一级汉字 3755 个 + ASCII + 中文标点
 * 由 tools/gen_font.py 调用 lv_font_conv 生成, 请勿手改 .c
 */
#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const lv_font_t lv_font_cn_16;

#ifdef __cplusplus
}
#endif
