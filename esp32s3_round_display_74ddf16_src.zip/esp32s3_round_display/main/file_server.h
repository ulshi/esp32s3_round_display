#pragma once

#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 文件服务器: 把 SD 卡 /sdcard 目录映射到 HTTP 服务 (端口 8080)。
 * 设备作为 SoftAP(192.168.4.1)时, 手机连上即可下载/上传文件。
 * 默认关闭, 由设置页开关控制。 */
void file_server_set_enabled(bool on);
bool file_server_is_enabled(void);

/* SD 卡是否缺失 (缺失则无法启动, 供 UI 给出提示)。 */
bool file_server_sd_missing(void);

#ifdef __cplusplus
}
#endif
