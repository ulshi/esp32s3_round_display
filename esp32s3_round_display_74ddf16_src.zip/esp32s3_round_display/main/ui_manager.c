#include "ui_manager.h"

#include <string.h>

#include "board_config.h"
#include "lvgl_helper.h"
#include "fonts/lv_font_cn_16.h"

/* 各页面创建函数声明 (由各 page_*.c 实现) */
#include "pages/page_clock.h"
#include "pages/page_ebook.h"
#include "pages/page_settings.h"
#include "pages/page_liuren.h"

static ui_page_t g_current = UI_PAGE_CLOCK;

static void (*const g_create_fn[UI_PAGE_COUNT])(void) = {
    [UI_PAGE_CLOCK]         = page_clock_create,
    [UI_PAGE_EBOOK]         = page_ebook_create,
    [UI_PAGE_SETTINGS]      = page_settings_create,
    [UI_PAGE_LIUREN]        = page_liuren_create,
};

lv_obj_t *ui_page_root_create(void)
{
    if (!lvgl_lock(-1)) return NULL;   /* 与 lvgl_task 串行化, 防止删除/创建控件时竞态 */
    lv_obj_t *scr = lv_scr_act();
    lv_obj_clean(scr);

    lv_obj_t *root = lv_obj_create(scr);
    lv_obj_set_size(root, BOARD_LCD_H_RES, BOARD_LCD_V_RES);
    lv_obj_center(root);
    lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_opa(root, LV_OPA_TRANSP, 0);
    lv_obj_set_style_radius(root, BOARD_SCREEN_RADIUS, 0);   /* 圆形裁剪 */
    lv_obj_set_style_clip_corner(root, true, 0);
    lv_obj_clear_flag(root, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(root, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(root, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_all(root, 0, 0);
    lvgl_unlock();
    return root;
}

/* RAM 中的字体副本。
 * 注意: lv_font_montserrat_* 是 const, 存放在 flash 的 .rodata,
 * 直接写它的 fallback 字段会触发 "Dbus write to cache rejected" panic。
 * 因此这里复制一份到 RAM 再挂载 fallback, ui_font() 返回副本。 */
extern lv_font_t lv_font_clock_64;   /* 由 fonts/lv_font_clock_64.c 生成(本机 Arial 64px) */
static lv_font_t g_font_12, g_font_14, g_font_16, g_font_20, g_font_24, g_font_32, g_font_48, g_font_64;

const lv_font_t *ui_font(int px)
{
    if (px >= 64) return &g_font_64;
    if (px >= 48) return &g_font_48;
    if (px >= 32) return &g_font_32;
    if (px >= 24) return &g_font_24;
    if (px >= 20) return &g_font_20;
    if (px >= 16) return &g_font_16;
    if (px >= 14) return &g_font_14;
    return &g_font_12;
}

lv_obj_t *ui_label_create(lv_obj_t *parent, const char *text, const lv_font_t *font, lv_color_t color)
{
    lv_obj_t *l = lv_label_create(parent);
    lv_label_set_text(l, text);
    if (font) lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, color, 0);
    return l;
}

lv_obj_t *ui_page_title(lv_obj_t *root, const char *text)
{
    lv_obj_t *l = ui_label_create(root, text, ui_font(20), lv_color_white());
    lv_obj_set_style_text_color(l, lv_color_make(0xCF, 0xD3, 0xDC), 0);
    lv_obj_set_style_pad_top(l, 14, 0);
    return l;
}

void ui_show_page(ui_page_t page)
{
    if (page < 0 || page >= UI_PAGE_COUNT) return;
    if (!lvgl_lock(-1)) return;        /* 递归锁: 从 lvgl_task 输入回调内触发时不会死锁 */
    lvgl_set_brightness_obj(NULL);     /* 切换页面: 清空亮度控件登记, 避免跨页误用 */
    lvgl_set_gesture_blocked(false);   /* 切换页面: 解除可能的浮层手势屏蔽 */
    g_current = page;
    g_create_fn[page]();
    lvgl_unlock();
}

ui_page_t ui_current_page(void)
{
    return g_current;
}

/* 安全地重建设置页: 在 LVGL 事件回调里直接 ui_show_page 会删除正在执行的控件树,
 * 破坏 LVGL 内部状态(表现为开关点了没反应或重启)。改用 lv_async_call 把重建
 * 延迟到下一帧的 lv_timer_handler 中执行, 彻底避免该问题。 */
static void rebuild_settings_async(void *p)
{
    (void)p;
    ui_show_page(UI_PAGE_SETTINGS);
}

void ui_rebuild_settings(void)
{
    lv_async_call(rebuild_settings_async, NULL);
}

void ui_handle_gesture(ui_gesture_t g, int16_t x)
{
    switch (g) {
    case UI_GESTURE_UP:
        /* 上滑回时钟主页。
         * 例外: 设置页内容很长且可滚动, 上滑必须留给列表滚动, 不能兼作返回手势,
         * 否则每次向上滚动都会被弹回主页。设置页返回主页请用左滑或右滑。 */
        if (g_current != UI_PAGE_CLOCK && g_current != UI_PAGE_SETTINGS) {
            ui_show_page(UI_PAGE_CLOCK);
        }
        break;
    case UI_GESTURE_TAP:
        /* 电子书已屏蔽, 此处不再响应轻触翻页 */
        break;
    case UI_GESTURE_RIGHT:
        /* 应用环形(2 个): CLOCK→SETTINGS→CLOCK; 占卜页右滑切到下一模式 */
        switch (g_current) {
        case UI_PAGE_CLOCK:    ui_show_page(UI_PAGE_SETTINGS); break;
        case UI_PAGE_SETTINGS: ui_show_page(UI_PAGE_CLOCK);    break;
        case UI_PAGE_LIUREN:   page_liuren_cycle_mode(+1);     break;
        default: break;
        }
        break;
    case UI_GESTURE_LEFT:
        /* 设置左滑回主页; 时钟左滑进设置; 占卜左滑切到上一模式 */
        switch (g_current) {
        case UI_PAGE_SETTINGS: ui_show_page(UI_PAGE_CLOCK);    break;
        case UI_PAGE_CLOCK:    ui_show_page(UI_PAGE_SETTINGS); break;
        case UI_PAGE_LIUREN:   page_liuren_cycle_mode(-1);     break;
        default: break;
        }
        break;
    default:
        break;
    }
}

/**
 * 把中文字库挂到每个 Montserrat 字号的 fallback 上。
 * 效果: 英文/数字仍用 Montserrat(各字号各自的美观),
 *       遇到 Montserrat 没有的字形(汉字/中文标点)自动回退到 16px 中文字库。
 * 这样只需一套中文字库即可覆盖全部字号, 省下大量 flash。
 */
static void ui_font_cn_fallback_setup(void)
{
    struct { lv_font_t *dst; const lv_font_t *src; } map[] = {
        { &g_font_12, &lv_font_montserrat_12 },
        { &g_font_14, &lv_font_montserrat_14 },
        { &g_font_16, &lv_font_montserrat_16 },
        { &g_font_20, &lv_font_montserrat_20 },
        { &g_font_24, &lv_font_montserrat_24 },
        { &g_font_32, &lv_font_montserrat_32 },
        { &g_font_48, &lv_font_montserrat_48 },
        { &g_font_64, &lv_font_clock_64 },
    };
    for (unsigned i = 0; i < sizeof(map) / sizeof(map[0]); i++) {
        memcpy(map[i].dst, map[i].src, sizeof(lv_font_t));   /* 拷到 RAM */
        map[i].dst->fallback = &lv_font_cn_16;               /* 再挂中文回退 */
    }
}

void ui_manager_init(void)
{
    ui_font_cn_fallback_setup();   /* 必须在建任何控件之前 */
    g_current = UI_PAGE_CLOCK;
    ui_show_page(UI_PAGE_CLOCK);
}
