#include "nvs_config.h"

#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"

static const char *TAG = "nvs_cfg";
static nvs_handle_t g_h = 0;

esp_err_t nvs_config_init(void)
{
    esp_err_t r = nvs_flash_init();
    if (r == ESP_ERR_NVS_NO_FREE_PAGES || r == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        r = nvs_flash_init();
    }
    if (r != ESP_OK) return r;
    return nvs_open("app_cfg", NVS_READWRITE, &g_h);
}

int nvs_config_get_int(const char *key, int def)
{
    int32_t v = (int32_t)def;   /* nvs_get_i32 要求 int32_t* */
    if (g_h) nvs_get_i32(g_h, key, &v);
    return (int)v;
}

void nvs_config_set_int(const char *key, int v)
{
    if (!g_h) return;
    nvs_set_i32(g_h, key, v);
    nvs_commit(g_h);
}

esp_err_t nvs_config_get_str(const char *key, char *buf, size_t n)
{
    if (!g_h) return ESP_FAIL;
    return nvs_get_str(g_h, key, buf, &n);
}

void nvs_config_set_str(const char *key, const char *v)
{
    if (!g_h) return;
    nvs_set_str(g_h, key, v);
    nvs_commit(g_h);
}

void app_set_timezone(void)
{
    int off = nvs_config_get_int("tz_offset", 480);   /* 默认 +8 (480 分钟) */
    int oh = off / 60;
    char tz[16];
    /* POSIX TZ 符号与 UTC 偏移相反: +8 => "UTC-8" */
    snprintf(tz, sizeof(tz), "UTC%c%d", (oh >= 0 ? '-' : '+'), abs(oh));
    setenv("TZ", tz, 1);
    tzset();
    ESP_LOGI(TAG, "Timezone set: %s", tz);
}

/* 把本地时间分量写进系统时钟(供默认/手工/SNTP 复用)。 */
static void apply_components(int yr, int mon, int day, int hr, int mi)
{
    struct tm t = {0};
    t.tm_year = yr - 1900;
    t.tm_mon  = mon - 1;
    t.tm_mday = day;
    t.tm_hour = hr;
    t.tm_min  = mi;
    t.tm_sec  = 0;
    time_t e = mktime(&t);          /* 本地时间 -> UTC 秒, 与时钟页 localtime 互逆 */
    if (e < 0) return;
    struct timeval tv = { e, 0 };
    settimeofday(&tv, NULL);
}

void app_apply_clock_time(void)
{
    int yr  = nvs_config_get_int(NVS_TIME_YEAR, 2026);
    int mon = nvs_config_get_int(NVS_TIME_MON, 10);
    int day = nvs_config_get_int(NVS_TIME_DAY, 1);
    int hr  = nvs_config_get_int(NVS_TIME_HOUR, 12);
    int mi  = nvs_config_get_int(NVS_TIME_MIN, 0);

    if (nvs_config_get_int(NVS_TIME_MANUAL, 0) != 1) {
        /* 未手工设定: 仅当分量明显无效(从未同步)时回落默认 2026-10-01 12:00 */
        if (yr < 2000 || yr > 2099) {
            yr = 2026; mon = 10; day = 1; hr = 12; mi = 0;
        }
    }
    apply_components(yr, mon, day, hr, mi);
    ESP_LOGI(TAG, "Clock time applied: %04d-%02d-%02d %02d:%02d (manual=%d)",
             yr, mon, day, hr, mi, nvs_config_get_int(NVS_TIME_MANUAL, 0));
}

void app_set_manual_time(int yr, int mon, int day, int hr, int mi)
{
    nvs_config_set_int(NVS_TIME_YEAR, yr);
    nvs_config_set_int(NVS_TIME_MON,  mon);
    nvs_config_set_int(NVS_TIME_DAY,  day);
    nvs_config_set_int(NVS_TIME_HOUR, hr);
    nvs_config_set_int(NVS_TIME_MIN,  mi);
    nvs_config_set_int(NVS_TIME_MANUAL, 1);   /* 标记手工, 禁用 SNTP */
    apply_components(yr, mon, day, hr, mi);
    ESP_LOGI(TAG, "Manual time set: %04d-%02d-%02d %02d:%02d", yr, mon, day, hr, mi);
}

bool app_time_is_manual(void)
{
    return nvs_config_get_int(NVS_TIME_MANUAL, 0) == 1;
}
