#pragma once

#include "esp_lcd_types.h"        /* esp_lcd_panel_handle_t / esp_lcd_panel_io_color_trans_done_cb_t */
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_touch.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 初始化 SPI 总线 + ST77916 屏 + CST816S 触摸 + 背光(LEDC)。
 * trans_done_cb: QSPI 颜色传输完成回调 (用于通知 LVGL 刷新结束)。
 * 必须在 lvgl_init() 之前调用。
 */
esp_err_t board_display_init(esp_lcd_panel_io_color_trans_done_cb_t trans_done_cb, void *user_ctx);

/** 设置背光亮度 0~100 (LEDC PWM)。 */
void board_backlight_set(int percent);

esp_lcd_panel_handle_t board_panel_get(void);
esp_lcd_touch_handle_t board_touch_get(void);

#ifdef __cplusplus
}
#endif
