#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** 界面语言。存 NVS 的 "lang" 字段。 */
typedef enum {
    UI_LANG_EN = 0,   /* 英文 (缺省, 当前 Montserrat 字库即可渲染) */
    UI_LANG_ZH = 1,   /* 中文 (需 CJK 字库, 否则显示方块) */
} ui_lang_t;

/** 所有可本地化的 UI 文本键。 */
typedef enum {
    UI_STR_HOME,
    UI_STR_CLOCK,
    UI_STR_BOOK,
    UI_STR_SETTINGS,
    UI_STR_LANGUAGE,
    UI_STR_BACK_HOME_HINT,
    UI_STR_LANG_SWITCH,   /* "Language: English" / "语言: 中文" */
    UI_STR_FIRMWARE,      /* "Firmware" / "固件版本" */

    /* 时钟 */
    UI_STR_SOLAR,         /* "Solar (24h)" / "阳历" */
    UI_STR_GANZHI,        /* "Ganzhi" / "干支" */
    UI_STR_LIUREN,        /* "Xiao Liu Ren" / "小六壬" */
    UI_STR_TAP_CAST,      /* "Tap to cast" / "点击起课" */
    UI_STR_BRIGHTNESS,    /* "Brightness" / "亮度" */
    UI_STR_MODE,          /* "Mode" / "模式" */
    UI_STR_LR_TIME,       /* "Time" / "时间" (小六壬: 取当前时间起课) */
    UI_STR_LR_RANDOM,     /* "Random" / "随机" */
    UI_STR_LR_MANUAL,     /* "Manual" / "手工" */
    UI_STR_TAP_MODE,      /* "Tap mode to switch" / "点击模式切换" */
    UI_STR_EBOOK_TURN,    /* "Tap sides to turn page" / "轻触左右翻页" */
    UI_STR_HOLD_DIVINE,   /* "Hold to divine" / "长按进入占卜" */
    UI_STR_HOLD_BACK,     /* "Hold to return" / "左滑返回时钟" */
    UI_STR_LR_STEPS,      /* "3 derivations" / "三次推导" */
    UI_STR_LR_TRIPLE,     /* "Casting numbers" / "起课三数" */
    UI_STR_LR_M_PUSH,     /* "Month step" / "月推" */
    UI_STR_LR_D_PUSH,     /* "Day step" / "日推" */
    UI_STR_LR_H_PUSH,     /* "Hour step" / "时推" */

    /* 时间手工设定 */
    UI_STR_TIME_TITLE,      /* "Time" / "时间" */
    UI_STR_TIME_HINT,       /* "Manual set disables NTP" / "手工设定后禁用网络校时" */

    /* 网络 / 配网 */
    UI_STR_WIFI,              /* "WiFi" / "WiFi" */
    UI_STR_WIFI_CONNECTED,    /* "Connected" / "已连接" */
    UI_STR_WIFI_PROVISIONING, /* "Provisioning" / "配网中" */
    UI_STR_WIFI_NOT_CONNECTED,/* "Not connected" / "未连接" */
    UI_STR_PROV_HINT,         /* "Connect phone to WiFi then open browser" / "手机连此WiFi后开浏览器" */
    UI_STR_PROV_ADDR,         /* "Open: 192.168.4.1" / "打开: 192.168.4.1" */

    /* 文件服务器 */
    UI_STR_FS_TITLE,          /* "File Server" / "文件服务器" */
    UI_STR_FS_OFF,            /* "Off" / "关闭" */
    UI_STR_FS_ON,             /* "On" / "开启" */
    UI_STR_FS_AP,             /* "WiFi: ROUND_DISP_FS" / "WiFi: ROUND_DISP_FS" */
    UI_STR_FS_ADDR,           /* "Open: 192.168.4.1:8080" / "打开: 192.168.4.1:8080" */
    UI_STR_FS_NO_SD,          /* "No SD card detected" / "未检测到 SD 卡" */
    UI_STR_FS_HINT,           /* "Connect WiFi then visit the address above" / "连上WiFi后访问上方地址" */
    UI_STR_FS_QR,             /* "File Server QR" / "文件服务器二维码" */
    UI_STR_FS_QR_BTN,         /* "Scan" / "扫码" */
    UI_STR_FS_SCAN_HINT,      /* "Scan to connect WiFi & open server" / "扫码连接WiFi并打开文件服务器" */
    UI_STR_FS_URL_HINT,       /* "Or open in browser:" / "或浏览器打开:" */
    UI_STR_FS_TAP_CLOSE,      /* "Tap anywhere to close" / "点击空白处关闭" */

    /* 通用 */
    UI_STR_SAVE,              /* "Save" / "保存" */
    UI_STR_BACK,              /* "Back" / "返回" */

    UI_STR_COUNT
} ui_str_key_t;

/** 启动时读取 NVS 的 lang 字段。必须在 ui_manager_init() 之前调用。 */
void ui_i18n_init(void);

ui_lang_t ui_lang_get(void);

/** 切换语言并持久化到 NVS。 */
void ui_lang_set(ui_lang_t lang);

/** 取当前语言下的字符串。返回指向静态表的指针, 勿修改。 */
const char *ui_str(ui_str_key_t key);

#ifdef __cplusplus
}
#endif
