#pragma once

#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 简易 HTTP 助手: 基于 esp_http_client, 把响应整体收进调用方提供的缓冲。
 * 联网功能(天气/对话)共用, 避免重复造轮子。
 */

/* GET url, 把响应体写入 buf(最多 buflen-1), 返回 ESP_OK 且 *out_status 填 HTTP 状态码。
 * buf 可为 NULL(仅取状态码)。 */
esp_err_t http_get(const char *url, char *buf, size_t buflen, int *out_status);

/* POST url, 带可选 Bearer 鉴权与 JSON body, 响应写入 buf。 */
esp_err_t http_post(const char *url, const char *bearer, const char *body,
                    char *buf, size_t buflen, int *out_status);

#ifdef __cplusplus
}
#endif
