#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    UI_PAGE_CLOCK = 0,
    UI_PAGE_EBOOK,
    UI_PAGE_SETTINGS,
    UI_PAGE_LIUREN,
    UI_PAGE_COUNT
} ui_page_t;

typedef enum {
    UI_GESTURE_UP,
    UI_GESTURE_DOWN,
    UI_GESTURE_LEFT,
    UI_GESTURE_RIGHT,
    UI_GESTURE_TAP,        /* 轻触(位移很小) */
} ui_gesture_t;

/** 初始化 UI 管理器并进入主菜单。 */
void ui_manager_init(void);

/** 切换到指定页面 (页创建函数内会自建圆形根容器)。 */
void ui_show_page(ui_page_t page);

/** 返回当前页面 (供定时器判断是否仍在当前页, 避免刷新已销毁对象)。 */
ui_page_t ui_current_page(void);

/** 安全重建设置页(延迟到下一帧, 避免在事件回调里删除自身控件树)。 */
void ui_rebuild_settings(void);

/** 全局手势处理: 应用环形导航(右滑 CLOCK→SETTINGS→CLOCK, 左滑反之,
 *  上滑回时钟主页); 占卜页(LIUREN)上滑回主页、左右滑切换占卜模式; 电子书已屏蔽。
 *  x 为抬起点的横向坐标。 */
void ui_handle_gesture(ui_gesture_t g, int16_t x);

/**
 * 创建一个铺满屏幕、按圆形裁剪的根容器 (圆角半径=屏幕半径)。
 * 所有页面内容都应放在这个容器内, 四角死区自动被裁掉。
 * 调用会先清空当前活动屏幕上的旧内容。
 */
lv_obj_t *ui_page_root_create(void);

/** 取内置 Montserrat 字体 (取不大于 px 的最大可用字号)。 */
const lv_font_t *ui_font(int px);

/** 在 parent 上创建居中文本标签。 */
lv_obj_t *ui_label_create(lv_obj_t *parent, const char *text, const lv_font_t *font,
                          lv_color_t color);

/** 页面标题 (顶部居中)。 */
lv_obj_t *ui_page_title(lv_obj_t *root, const char *text);

#ifdef __cplusplus
}
#endif
