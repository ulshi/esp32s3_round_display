#pragma once

#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    WIFI_STATE_IDLE = 0,
    WIFI_STATE_PROVISIONING,   /* SoftAP 已起, 等待手机配网 */
    WIFI_STATE_CONNECTING,     /* 已用保存凭据发起 STA 连接 */
    WIFI_STATE_CONNECTED,      /* 已拿到 IP */
    WIFI_STATE_FAILED,         /* 连接失败 */
} wifi_state_t;

/* 初始化 netif + 事件循环 + 默认 STA/AP 接口(应在 app_main 早期调用一次)。 */
void app_wifi_init(void);

/* 启动联网: 已配网则 STA 连接; 否则进入 SoftAP 配网模式。 */
void app_wifi_start(void);

wifi_state_t app_wifi_state(void);
bool        app_wifi_is_connected(void);
const char *app_wifi_ip_str(void);
/* 配网模式下暴露的 SoftAP SSID(手机连这个 WiFi 后开浏览器配网)。 */
const char *app_wifi_prov_ssid(void);

/* 确保 SoftAP 已启动(供文件服务器使用): 当前已是 AP/APSTA 则不动;
 * 若仅 STA 则切换为 APSTA 并拉起一个开放 AP(SSID=ROUND_DISP_FS),
 * 使手机能连上 192.168.4.1 访问文件服务器。 */
void app_wifi_ensure_ap(void);

/* 当前 SoftAP 的 SSID(供文件服务器 UI 显示; 未启用 AP 时返回 "")。 */
const char *app_wifi_ap_ssid(void);

/* 状态变化回调(供 UI 刷新)。 */
void app_wifi_set_notify_cb(void (*cb)(wifi_state_t));

#ifdef __cplusplus
}
#endif
