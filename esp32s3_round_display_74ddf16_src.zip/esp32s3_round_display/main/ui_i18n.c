#include "ui_i18n.h"
#include "nvs_config.h"

static ui_lang_t g_lang = UI_LANG_EN;

/* 键 -> {英文, 中文} 对照表。新增 UI 文本一律走这里, 不要硬编码字符串。 */
static const char *const TABLE[UI_STR_COUNT][2] = {
    [UI_STR_HOME]          = {"Home",            "主页"},
    [UI_STR_CLOCK]         = {"Clock",           "时钟"},
    [UI_STR_BOOK]          = {"Book",            "电子书"},
    [UI_STR_SETTINGS]      = {"Settings",        "设置"},
    [UI_STR_LANGUAGE]      = {"Language",        "语言"},
    [UI_STR_BACK_HOME_HINT]= {"swipe up -> home","上滑返回主页"},
    [UI_STR_LANG_SWITCH]   = {"Language: English","语言: 中文"},
    [UI_STR_FIRMWARE]      = {"Firmware",         "固件版本"},

    /* 时钟 */
    [UI_STR_SOLAR]         = {"Solar (24h)",      "阳历"},
    [UI_STR_GANZHI]        = {"Ganzhi",           "干支"},
    [UI_STR_LIUREN]        = {"Xiao Liu Ren",     "小六壬"},
    [UI_STR_TAP_CAST]      = {"Tap to cast",      "点击起课"},
    [UI_STR_BRIGHTNESS]    = {"Brightness",       "亮度"},
    [UI_STR_MODE]          = {"Mode",             "模式"},
    [UI_STR_LR_TIME]       = {"Time",             "时间"},
    [UI_STR_LR_RANDOM]     = {"Random",           "随机"},
    [UI_STR_LR_MANUAL]     = {"Manual",           "手工"},
    [UI_STR_TAP_MODE]      = {"Tap mode to switch","点击模式切换"},
    [UI_STR_EBOOK_TURN]    = {"Tap sides to turn page", "轻触左右翻页"},
    [UI_STR_HOLD_DIVINE]   = {"Hold to divine",   "长按进入占卜"},
    [UI_STR_HOLD_BACK]     = {"Swipe left to return", "左滑返回时钟"},
    [UI_STR_LR_STEPS]      = {"3 derivations",        "三次推导"},
    [UI_STR_LR_TRIPLE]     = {"Casting numbers",      "起课三数"},
    [UI_STR_LR_M_PUSH]     = {"Month",                "月推"},
    [UI_STR_LR_D_PUSH]     = {"Day",                  "日推"},
    [UI_STR_LR_H_PUSH]     = {"Hour",                 "时推"},

    /* 时间手工设定 */
    [UI_STR_TIME_TITLE]     = {"Time",                 "时间"},
    [UI_STR_TIME_HINT]      = {"Manual set disables NTP sync", "手工设定后禁用网络校时"},

    /* 网络 / 配网 */
    [UI_STR_WIFI]              = {"WiFi",               "WiFi"},
    [UI_STR_WIFI_CONNECTED]    = {"Connected",          "已连接"},
    [UI_STR_WIFI_PROVISIONING] = {"Provisioning",       "配网中"},
    [UI_STR_WIFI_NOT_CONNECTED]= {"Not connected",      "未连接"},
    [UI_STR_PROV_HINT]         = {"Connect phone to this WiFi, then open browser", "手机连此WiFi后打开浏览器"},
    [UI_STR_PROV_ADDR]         = {"Open: 192.168.4.1", "打开: 192.168.4.1"},

    /* 文件服务器 */
    [UI_STR_FS_TITLE]          = {"File Server",          "文件服务器"},
    [UI_STR_FS_OFF]            = {"Off",                  "关闭"},
    [UI_STR_FS_ON]             = {"On",                   "开启"},
    [UI_STR_FS_AP]             = {"WiFi: ROUND_DISP_FS",  "WiFi: ROUND_DISP_FS"},
    [UI_STR_FS_ADDR]           = {"Open: 192.168.4.1:8080", "打开: 192.168.4.1:8080"},
    [UI_STR_FS_NO_SD]          = {"No SD card detected",  "未检测到 SD 卡"},
    [UI_STR_FS_HINT]           = {"Connect WiFi then visit the address above", "连上WiFi后访问上方地址"},
    [UI_STR_FS_QR]             = {"File Server QR",       "文件服务器二维码"},
    [UI_STR_FS_QR_BTN]         = {"Scan",                 "扫码"},
    [UI_STR_FS_SCAN_HINT]      = {"Scan to connect WiFi & open server", "扫码连接WiFi并打开文件服务器"},
    [UI_STR_FS_URL_HINT]       = {"Or open in browser:",  "或浏览器打开:"},
    [UI_STR_FS_TAP_CLOSE]      = {"Tap anywhere to close","点击空白处关闭"},

    /* 通用 */
    [UI_STR_SAVE]              = {"Save",               "保存"},
    [UI_STR_BACK]              = {"Back",               "返回"},
};

void ui_i18n_init(void)
{
    /* CJK 字库已接入, 默认改用中文; NVS 中仍可切回英文 */
    int v = nvs_config_get_int("lang", UI_LANG_ZH);
    g_lang = (v == UI_LANG_ZH) ? UI_LANG_ZH : UI_LANG_EN;
}

ui_lang_t ui_lang_get(void)
{
    return g_lang;
}

void ui_lang_set(ui_lang_t lang)
{
    if (lang != UI_LANG_EN && lang != UI_LANG_ZH) return;
    g_lang = lang;
    nvs_config_set_int("lang", lang);
}

const char *ui_str(ui_str_key_t key)
{
    if (key < 0 || key >= UI_STR_COUNT) return "";
    return TABLE[key][g_lang];
}
