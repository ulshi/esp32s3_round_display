# gen_version.cmake
#
# 构建时从 git 生成固件版本头文件 fw_version.h。
# 由 main/CMakeLists.txt 在每次构建时通过 `cmake -P` 调用。
#
# 入参 (通过 -D 传入):
#   SRC_DIR  : 工程根目录 (含 .git), 例如 esp32s3_round_display
#   TPL_FILE : 模板文件 fw_version.h.in 的完整路径
#   OUT_FILE : 生成的头文件路径, 例如 <build>/esp-idf/main/fw_version.h
#
# 输出宏:
#   FW_GIT_HASH    短哈希, 例如 "a1b2c3d"; 无提交时为 "no-commit"
#   FW_DIRTY_SUFFIX 工作区有未提交改动时为 "-dirty", 否则 ""
#   FW_VERSION_STR 组合字符串, 例如 "a1b2c3d-dirty"

set(_hash "no-commit")
set(_dirty "")
set(_ok 0)

# 优先用 find_package 找到的 git, 找不到则回退到 PATH 中的 "git"
set(_git_cmd "")
find_package(Git QUIET)
if(GIT_FOUND AND GIT_EXECUTABLE)
    set(_git_cmd "${GIT_EXECUTABLE}")
else()
    set(_git_cmd "git")
endif()

# 取当前 HEAD 的短哈希; 仓库尚无任何提交或 git 不可用时失败
execute_process(
    COMMAND "${_git_cmd}" -C "${SRC_DIR}" rev-parse --short HEAD
    OUTPUT_VARIABLE _out
    OUTPUT_STRIP_TRAILING_WHITESPACE
    ERROR_QUIET
    RESULT_VARIABLE _rc)
if(_rc EQUAL 0 AND _out)
    set(_hash "${_out}")
    set(_ok 1)
    # 工作区是否脏 (存在未提交改动)
    execute_process(
        COMMAND "${_git_cmd}" -C "${SRC_DIR}" status --porcelain
        OUTPUT_VARIABLE _st
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET)
    if(_st)
        set(_dirty "-dirty")
    endif()
endif()

if(NOT _ok)
    # 尚无提交: 给出明确标识, 避免与某个真实哈希混淆
    set(_hash "no-commit")
endif()

set(FW_GIT_HASH "${_hash}")
set(FW_DIRTY_SUFFIX "${_dirty}")
set(FW_VERSION_STR "${_hash}${_dirty}")

# 用模板生成到临时文件, 仅当内容变化时才覆盖正式文件,
# 避免每次构建都触发整个组件重编。
set(_tmp "${OUT_FILE}.tmp")
configure_file("${TPL_FILE}" "${_tmp}" @ONLY)

set(_changed 1)
if(EXISTS "${OUT_FILE}")
    file(READ "${OUT_FILE}" _old)
    file(READ "${_tmp}" _new)
    if(_old STREQUAL _new)
        set(_changed 0)
    endif()
endif()

if(_changed)
    file(RENAME "${_tmp}" "${OUT_FILE}")
    message(STATUS "fw_version.h generated: ${FW_VERSION_STR}")
else()
    file(REMOVE "${_tmp}")
    message(STATUS "fw_version.h unchanged (${FW_VERSION_STR})")
endif()
