#include "jpg_decode.h"

/* 复用 LVGL 自带的 tjpgd(位于 src/extra/libs/sjpg/, 由 CONFIG_LV_USE_SJPG 编译)。
 * tjpgd 默认 JD_FORMAT=0(RGB888 输出), 我们在输出回调里转成 RGB565。 */
#include "extra/libs/sjpg/tjpgd.h"

#include <stdio.h>
#include <string.h>

#include "esp_heap_caps.h"
#include "esp_log.h"

static const char *TAG = "jpgdec";

#define JPEG_WORK_SIZE 8192   /* tjpgd 工作池(表 + MCU 缓冲) */
#define IMG_FIT_MAX   360    /* 解码后最大边长(显示屏尺寸), 仅用于限制内存 */

typedef struct {
    const uint8_t *data;   /* 整个 jpg 文件(读入内存) */
    uint32_t size;
    uint32_t pos;
    uint8_t *out;          /* RGB565 输出缓冲 */
    int out_w;             /* 输出宽(已缩放) */
    int out_stride;        /* 每行字节数 = out_w * 2 */
} jpg_ctx_t;

/* 输入回调: 从内存缓冲喂给 tjpgd */
static size_t jpg_in(JDEC *jd, uint8_t *buf, size_t n)
{
    jpg_ctx_t *c = (jpg_ctx_t *)jd->device;
    uint32_t remain = c->size - c->pos;
    size_t r = (n <= remain) ? n : (size_t)remain;
    if (r) memcpy(buf, c->data + c->pos, r);
    c->pos += (uint32_t)r;
    return r;
}

/* 输出回调: RGB888 -> RGB565, 写入输出缓冲对应矩形区域 */
static int jpg_out(JDEC *jd, void *bitmap, JRECT *rect)
{
    jpg_ctx_t *c = (jpg_ctx_t *)jd->device;
    const uint8_t *p = (const uint8_t *)bitmap;
    for (uint16_t y = rect->top; y <= rect->bottom; y++) {
        uint8_t *dst_row = c->out + (size_t)y * c->out_stride;
        for (uint16_t x = rect->left; x <= rect->right; x++) {
            uint8_t r = *p++;
            uint8_t g = *p++;
            uint8_t b = *p++;
            uint16_t rgb565 = (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
            *((uint16_t *)(dst_row + (size_t)x * 2)) = rgb565;
        }
    }
    return 1;
}

lv_img_dsc_t *jpg_decode_file(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) {
        ESP_LOGE(TAG, "open %s failed", path);
        return NULL;
    }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0) {
        fclose(f);
        return NULL;
    }

    uint8_t *file_buf = heap_caps_malloc((size_t)sz, MALLOC_CAP_SPIRAM);
    if (!file_buf) {
        fclose(f);
        return NULL;
    }
    if (fread(file_buf, 1, (size_t)sz, f) != (size_t)sz) {
        fclose(f);
        heap_caps_free(file_buf);
        return NULL;
    }
    fclose(f);

    void *work = heap_caps_malloc(JPEG_WORK_SIZE, MALLOC_CAP_SPIRAM);
    if (!work) {
        heap_caps_free(file_buf);
        return NULL;
    }

    jpg_ctx_t ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.data = file_buf;
    ctx.size = (uint32_t)sz;

    JDEC jd;
    JRESULT rc = jd_prepare(&jd, jpg_in, work, JPEG_WORK_SIZE, &ctx);
    if (rc != JDR_OK) {
        ESP_LOGE(TAG, "jd_prepare failed (%d)", rc);
        heap_caps_free(work);
        heap_caps_free(file_buf);
        return NULL;
    }

    int iw = (int)jd.width;
    int ih = (int)jd.height;

    /* 选最小缩放档(0=1/1,1=1/2,2=1/4,3=1/8), 使边长不超过 IMG_FIT_MAX */
    uint8_t scale = 0;
    while (scale < 3 && ((iw >> (scale + 1)) > IMG_FIT_MAX || (ih >> (scale + 1)) > IMG_FIT_MAX)) {
        scale++;
    }
    int dw = iw >> scale;
    int dh = ih >> scale;

    uint8_t *out = heap_caps_malloc((size_t)dw * dh * 2, MALLOC_CAP_SPIRAM);
    if (!out) {
        heap_caps_free(work);
        heap_caps_free(file_buf);
        return NULL;
    }
    ctx.out = out;
    ctx.out_w = dw;
    ctx.out_stride = dw * 2;

    rc = jd_decomp(&jd, jpg_out, scale);
    heap_caps_free(work);
    heap_caps_free(file_buf);
    if (rc != JDR_OK) {
        ESP_LOGE(TAG, "jd_decomp failed (%d)", rc);
        heap_caps_free(out);
        return NULL;
    }

    lv_img_dsc_t *dsc = malloc(sizeof(lv_img_dsc_t));
    if (!dsc) {
        heap_caps_free(out);
        return NULL;
    }
    memset(dsc, 0, sizeof(*dsc));
    dsc->header.cf = LV_IMG_CF_TRUE_COLOR;
    dsc->header.w = (uint16_t)dw;
    dsc->header.h = (uint16_t)dh;
    dsc->header.always_zero = 0;
    dsc->data = out;
    dsc->data_size = (uint32_t)dw * dh * 2;
    ESP_LOGI(TAG, "decoded %s -> %dx%d (scale %d)", path, dw, dh, scale);
    return dsc;
}

void jpg_decode_free_dsc(lv_img_dsc_t *dsc)
{
    if (!dsc) return;
    if (dsc->data) heap_caps_free((void *)dsc->data);
    free(dsc);
}
