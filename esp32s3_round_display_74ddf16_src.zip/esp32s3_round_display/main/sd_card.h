#pragma once
#include "esp_err.h"
#ifdef __cplusplus
extern "C" {
#endif

/** 挂载 SD 卡 (SDMMC 4-bit) 并创建资源目录结构。失败不致命。 */
esp_err_t sd_card_mount(void);

/** SD 卡是否已挂载成功 (/sdcard 可访问)。 */
bool sd_card_is_mounted(void);

/** 最近一次挂载失败的原因(人话描述, 供设置页显示)。
 *  已成功挂载则返回 NULL。
 *  注意: 本工程 FatFs 编译时 FF_FS_EXFAT=0 / FF_LBA64=0, 不支持 exFAT,
 *        卡片必须预先格式化为 FAT32(或 FAT16)。 */
const char *sd_card_last_error(void);

#ifdef __cplusplus
}
#endif
