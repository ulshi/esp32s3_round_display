﻿# 串口监视器 (看启动日志 / panic 堆栈)
#
# 用法:
#   .\monitor.ps1               # 自动探测串口
#   .\monitor.ps1 -Port COM6
#   退出: Ctrl+]
#
# 传了 .elf 给 idf_monitor, 因此 panic 时会自动把地址翻译成
# "函数名 + 源文件:行号", 比裸串口工具好用得多。

param(
    [string]$Port = '',
    [int]$Baud = 115200
)

$ErrorActionPreference = 'Continue'
$proj  = Split-Path -Parent $MyInvocation.MyCommand.Path
$esp   = 'C:\Espressif\tools\python\v6.1\venv\Scripts\esptool.exe'
$venvPy= 'C:\Espressif\tools\python\v6.1\venv\Scripts\python.exe'
$monitor = 'C:\esp\v6.1\esp-idf\tools\idf_monitor.py'
$elf   = 'build\esp32s3_round_display.elf'

Set-Location $proj

if (-not (Test-Path $elf)) { Write-Host "缺少 $elf, 请先编译" -ForegroundColor Red; exit 1 }

if (-not $Port) {
    $existing = Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty DeviceID | Sort-Object
    if (-not $existing) { $existing = 1..20 | ForEach-Object { "COM$_" } }
    Write-Host ("未指定串口, 探测候选: " + ($existing -join ', '))
    foreach ($p in $existing) {
        $r = & $esp -p $p chip-id 2>&1 | Out-String
        if ($r -match 'Chip is|Detected|Chip ID') { $Port = $p; Write-Host "  使用 $p" -ForegroundColor Green; break }
    }
    if (-not $Port) { Write-Host "未探测到芯片, 请用 -Port COMx 指定" -ForegroundColor Yellow; exit 1 }
}

Write-Host "监视 $Port @ $Baud (Ctrl+] 退出)"
& $venvPy $monitor -p $Port -b $Baud $elf
