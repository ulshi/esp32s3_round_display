﻿# ESP32-S3 round display - 一键构建脚本 (Windows / ESP-IDF v6.1)
#
# 为什么不用 idf.py:
#   本机 idf.py 启动 cmake 时环境传递有缺陷, cmake 报
#   "Unable to find a build program corresponding to Ninja".
#   直接调用 cmake + ninja (环境变量手工设置) 可稳定构建。
#
# 用法 (在 PowerShell 中):
#   .\build.ps1              # 增量编译
#   .\build.ps1 -Clean       # 清掉 build 目录后全量编译
#   .\build.ps1 -Size        # 编译后打印固件体积

param(
    [switch]$Clean,
    [switch]$Size
)

$ErrorActionPreference = 'Continue'
$proj = Split-Path -Parent $MyInvocation.MyCommand.Path
$venvPy = 'C:\Espressif\tools\python\v6.1\venv\Scripts\python.exe'

# ---- ESP-IDF 环境 (本机实际路径) ----
$env:MSYSTEM = $null                                  # 防止 Git Bash 注入导致 IDF 报错
$env:IDF_PATH = 'C:\esp\v6.1\esp-idf'
$env:IDF_TOOLS_PATH = 'C:\Espressif'
$env:IDF_PYTHON_ENV_PATH = 'C:\Espressif\tools\python\v6.1\venv'
$env:IDF_PYTHON_CHECK_CONSTRAINTS = '0'               # 跳过 python 包版本核对
$env:ESP_IDF_VERSION = '6.1.0'
$env:IDF_VERSION = '6.1.0'
$env:IDF_TARGET = 'esp32s3'
$env:PYTHONUTF8 = '1'
$env:ESP_ROM_ELF_DIR = 'C:\Espressif\tools\esp-rom-elfs\20241011'
$env:OPENOCD_SCRIPTS = 'C:\Espressif\tools\openocd-esp32\v0.12.0-esp32-20260703\openocd-esp32\share\openocd\scripts'

# ---- 工具链 PATH ----
$env:PATH = (@(
    'C:\Espressif\tools\cmake\4.0.3\bin',
    'C:\Espressif\tools\ninja\1.12.1',
    'C:\Espressif\tools\xtensa-esp-elf\esp-15.2.0_20251204\xtensa-esp-elf\bin',
    'C:\Espressif\tools\ccache\4.12.1\ccache-4.12.1-windows-x86_64',
    'C:\Espressif\tools\python\v6.1\venv\Scripts',
    'C:\esp\v6.1\esp-idf\tools'
) -join ';') + ';' + $env:PATH

Set-Location $proj

if ($Clean -and (Test-Path build)) {
    Write-Host "Cleaning build dir..."
    Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue
}

# ---- 1) CMake 配置 (首次或 sdkconfig 变化时需要) ----
if (-not (Test-Path build\build.ninja)) {
    Write-Host "Configuring (cmake -G Ninja)..."
    & cmake -G Ninja -B build -DPYTHON_DEPS_CHECKED=1 -DPYTHON="$venvPy" -DESP_PLATFORM=1 -DCCACHE_ENABLE=False .
    if ($LASTEXITCODE -ne 0) { Write-Host "CMAKE FAILED"; exit 1 }
}

# ---- 2) 编译 ----
Write-Host "Building (ninja)..."
& ninja -C build
$code = $LASTEXITCODE

if ($code -eq 0) {
    Write-Host ""
    Write-Host "BUILD OK - binaries:" -ForegroundColor Green
    Write-Host "  app      : build\esp32s3_round_display.bin"
    Write-Host "  bootloader: build\bootloader\bootloader.bin"
    Write-Host "  partition : build\partition_table\partition-table.bin"
    if ($Size) { & ninja -C build size }
} else {
    Write-Host "BUILD FAILED (exit=$code)" -ForegroundColor Red
}
exit $code
