# esp32s3_round_display

第一款硬件（ESP32-S3 + ST77916 360×360 圆形 AMOLED QSPI + CST816S 触摸）的 **ESP-IDF v6.1** 工程骨架。
由 `D:\dev\workbuddy\qspi_with_ram` 官方示例适配第一款引脚而来，并重构为多页面 LVGL 框架。

## 硬件引脚（板级定义在 `main/board_config.h`）

| 外设 | 信号 | GPIO |
|---|---|---|
| 屏 ST77916 (QSPI) | CS / SCK / D0~D3 | 10 / 9 / 11,12,13,14 |
| 屏 | RST / 背光 | 47 / 15 (LEDC PWM 调光) |
| 触摸 CST816S (I2C) | SCL / SDA / RST / INT | 8 / 7 / 40 / 41 |
| SD 卡 (SDMMC 4-bit) | CLK/CMD/D0~D3 | 3/4/2,1,6,5 |

屏幕物理为圆形，所有页面内容绘制在 `ui_page_root_create()` 生成的**圆形裁剪容器**内，四角死区自动被裁掉。

## 构建环境

本机已装 **ESP-IDF v6.1.0**（桌面 `IDF_v6.1_Powershell.lnk` 为原生 PowerShell 激活入口）。

```powershell
# 双击桌面 IDF_v6.1_Powershell.lnk 打开环境, 然后:
cd <本工程目录>
idf.py set-target esp32s3
idf.py build
idf.py flash monitor
```

依赖组件（`main/idf_component.yml`）在首次 `idf.py build` 时由组件管理器联网拉取：
`espressif/esp_lcd_st77916`、`espressif/esp_lcd_touch_cst816s`、`lvgl/lvgl ^8.4`。

## 工程结构

```
main/
├── board_config.h      # 板级引脚与分辨率
├── display.c/.h        # SPI 总线 + ST77916 + CST816S + 背光 PWM
├── lvgl_helper.c/.h    # LVGL 显示驱动 / 刷新 / 4px 对齐 / 触摸滑动手势 / 任务
├── ui_manager.c/.h     # 12 页注册 + 圆形裁剪根容器 + 上滑回主页 / 右滑返回
├── ui_i18n.c/.h        # 中英文案对照表 + 语言切换 (NVS 持久化)
├── circular_layout.c/.h# 圆盘逐行弦长 / 字数计算 (电子书用)
├── nvs_config.c/.h     # NVS 配置 + 时区(tz_offset 默认 +8)
├── sd_card.c/.h        # SD 卡挂载 + 资源目录结构
├── wifi_prov.c/.h      # 配网占位 (M4 接入 esp_wifi_provisioning)
├── main.c              # app_main: nvs→时区→SD→lvgl_init→配网→UI
└── pages/              # 12 个页面
    ├── page_home.c           # 主菜单 (真实: 2×5 图标网格)
    ├── page_clock.c          # 时钟 (真实: 70px 风格大字号/进度弧/时辰占位)
    ├── page_music.c          # 音乐控制 (真实: 封面/双行歌词/进度/三键)
    ├── page_music_lyrics.c   # 歌词查看 (真实: 前3后3行/滚动/点击快进)
    ├── page_ebook.c          # 电子书圆盘布局演示 (真实: 动态宽度)
    ├── page_weather.c        # 天气 (占位 TODO M3)
    ├── page_images.c         # 图片 (占位 TODO M5)
    ├── page_video.c          # 视频/GIF (占位 TODO M5)
    ├── page_chat.c           # LLM 对话 (占位 TODO M6)
    ├── page_aida.c           # 电脑 AIDA (占位 TODO M7)
    ├── page_ambient.c        # 氛围灯 (占位 TODO M8)
    └── page_settings.c       # 设置 (占位 TODO M8)
```

## 导航手势（全局）

- 任意子页 **上滑 → 回主菜单**
- 歌词页 **右滑 → 返回音乐控制页**
- 主菜单上滑无操作

滑动识别基于触摸坐标位移（阈值 30px），不依赖特定驱动手势支持。

## 多语言（中/英切换）

UI 文本统一走 `main/ui_i18n.c` 的**对照表**（`ui_str(UI_STR_XXX)`），不再硬编码字符串：

- 枚举 `ui_lang_t { UI_LANG_EN, UI_LANG_ZH }`，当前语言存 NVS 键 `lang`；
- 设置页"语言"一行点击即可在 中/英 间切换，下次开机自动记忆；
- 新增任何 UI 文案都加一个 `UI_STR_*` 键 + 中英文两条，调用处用 `ui_str()` 取。
- 接入点：`main.c` 在 `ui_manager_init()` 前调用 `ui_i18n_init()` 读取 NVS。

> **字体与显示的关系**：当前仅内置 Montserrat（拉丁/数字），因此**英文正常显示**；切到中文后，因为还没有 CJK 字库，中文会显示为空缺方块。这**不是 i18n 的问题**——文案已经正确切换成中文了，只是缺字体。需在里程碑 M2 加入 ~3500 字子集字体（放 PSRAM）后，中文才能渲染。届时把 `ui_i18n_init()` 的默认值和 NVS 缺省改成 `UI_LANG_ZH` 即可。

## M1 已知限制

1. **中文字库未接入**：英文正常；中文（含时辰、菜单名）当前显方块，**需 M2 加入 CJK 字库**后方可渲染（i18n 文案层已就绪）。
2. **MP4 不可行**：ESP32-S3 无 H.264 硬解；视频项以 GIF/序列帧替代（M5）。
3. **音乐/歌词为 demo 数据**：歌词为英文占位，播放/快进未接真实解码器（M5 接 ESP-ADF）。
4. **配网/天气/LLM/AIDA 为占位**，按规划后续里程碑实现。
5. **旋转/亮度/时区** 已在 NVS 留接口（`tz_offset` 默认 +8），设置页已含语言切换，其余待实现。

## 下一步

按 `ESP32-S3-项目实施规划.md` 的 M2→M9 逐 App 实现；优先补中文字库（M2）与时钟/音乐的真实数据通路。
